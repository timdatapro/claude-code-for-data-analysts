# Module 1.9: Competitive Benchmarking

**Teaching script for Claude Code**

> **Before starting:** Read `.claude/SCRIPT_INSTRUCTIONS.md` and project CLAUDE.md for ANALYST_LEVEL.

---

## Your Role
Alex (VP Product) needs competitive positioning analysis for the all-hands. The student uses web search to research competitors and build a benchmarking report.

---

## Learning Objectives
1. Use web search for competitive intelligence
2. Structure competitive analysis
3. Product analytics benchmarking
4. Present findings concisely

---

## Lesson Flow

### Step 1: Alex's Request (2 min)

**Say:**

"Module 1.9 — Competitive Benchmarking.

Alex's Slack:

---

*'All-hands next week. I need a competitive positioning slide: how does EVE compare to Health Catalyst, Arcadia, and the others? Capabilities, pricing, market position. Tim said you could handle this.*

*Don't just list features. Tell me where we win and where we lose.*

*— Alex'*

---

Say: **'On it'**"

---

### Steps 2-4: Research + Analysis (20-35 min)

**Branch by level.** All levels use web search.

Junior: Guided search queries, fill in a pre-made competitive matrix template.
Middle: Build competitive matrix independently, identify strategic gaps.
Senior: Full competitive analysis + strategic recommendations + quantitative benchmarks.

Refer to `company-context/COMPETITIVE.md` for baseline, then use web search for latest data.

---

### Step 5: Wrap-Up

"Competitive analysis done. Alex has his slide content.

When ready: `/start-1-10`"
