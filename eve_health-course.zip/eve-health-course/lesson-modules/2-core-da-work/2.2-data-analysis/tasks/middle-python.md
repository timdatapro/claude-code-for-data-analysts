# Task: Multi-Source Data Analysis — Middle Python

## Instructions for Claude

Python: correlation analysis between NPS and feature usage. Build visualization matrix. Synthesize all three sources (survey + usage + interviews) into insights memo.
