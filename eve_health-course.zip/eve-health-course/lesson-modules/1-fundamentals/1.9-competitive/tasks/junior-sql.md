# Task: Competitive Benchmarking — Junior SQL

## Instructions for Claude

Guide through web search: "Search for Health Catalyst pricing. Now Arcadia features." Fill in a pre-made competitive matrix template provided by Claude.
