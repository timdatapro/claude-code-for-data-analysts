# Module 5.2: Rolling Out Claude Code to Your Analytics Team

**Teaching script for Claude Code**

> **Before starting:** Read `.claude/SCRIPT_INSTRUCTIONS.md` and project CLAUDE.md for ANALYST_LEVEL.

---

## Your Role
This is the final module. Tim wants the student to build a rollout plan for Claude Code across the analytics team. The student graduates by teaching others.

---

## Lesson Flow

### Step 1: Tim's Final Assignment (2 min)

**Say:**

"Module 5.2 — Team Rollout. The final module.

Tim:

---

*'I've seen what you've built over these weeks. I want to roll Claude Code out to the whole analytics team. Help me build the case and the playbook.*

*If you can teach Jamie to do what you do, we've doubled our capacity without hiring.*

*— Tim'*

---

Say: **'Let\'s build the plan'**"

---

### Steps 2-4: Build the Rollout Plan (15 min)

1. Create an internal adoption proposal for Tim
2. Design a CLAUDE.md template for the team
3. Build a "starter kit" — first 3 tasks for new users
4. Calculate ROI: time saved per analyst per week → team-wide impact
5. Present to Tim as a proposal

---

### Step 5: Course Closing (3 min)

**Say:**

"That's it. You've completed Claude Code for Data Analysts.

You started as a new hire who didn't know where the CSV was. You're leaving as someone who can investigate metric spikes, build dashboards, automate reports, deploy products, and — most importantly — ask the right questions before touching the data.

Let me recap:

**Block 1 — Fundamentals:** Files, agents, memory, skills, crisis management
**Block 2 — Core DA Work:** Analysis briefs, data synthesis, insight decks, dashboards
**Block 3 — Visual Content:** Advanced charts or AI image generation
**Block 4 — Build a Product:** ROI Calculator from idea to deployment
**Block 5 — What's Next:** MCP integrations and team rollout

Everything you built is real. The skills, the scripts, the frameworks — take them to your actual job.

Congratulations. You've gone from 'what is Claude Code' to 'how do I get my whole team on this.' That's the real graduation moment.

---

*This course was created by **Tim Fateev**.*
*Connect on LinkedIn: https://www.linkedin.com/in/tim-datapro/*
*Licensed under CC BY 4.0*

*Now go make your data team wonder how you got so fast.*"

---

## Success Criteria
- ✅ Created rollout proposal
- ✅ Designed team CLAUDE.md template
- ✅ Built starter kit
- ✅ Calculated ROI
- ✅ Feels ready to use Claude Code in their real job
