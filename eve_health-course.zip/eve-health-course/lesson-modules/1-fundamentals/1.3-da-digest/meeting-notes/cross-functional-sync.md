# Cross-Functional Sync — Product + Engineering + Data
## January 14, 2026

**Attendees:** Alex (VP Product), David (CTO), Tim, Sarah (PM — Explorer), Mike (EM — Backend)

---

Alex opened — Q1 priorities reminder:
1. DAU/MAU from 34% to 50%
2. Explorer adoption from 41% to 65%  
3. Signals GA launch
4. Churn below 5%

"These aren't aspirational. The board expects progress by the March update."

### Explorer Discussion

Sarah presented explorer usage funnel:
- 1,200 licensed seats across all customers
- 492 have ever logged into explorer (41%)
- Of those 492, only 180 use it weekly (15% of total)
- Top 50 power users generate 60% of all explorer queries
- Natural language query success rate: 72% (users get what they expected)
- Main failure mode: complex multi-table queries that NL can't parse

Alex: "So we have an activation problem AND a retention problem. 59% never try it, and of those who do, most don't stick."

David asked about the NL query failure rate — 28% is high. Mike said the LLM integration needs more healthcare-specific training data. Current model doesn't understand clinical abbreviations well (LOS, DRG, ADT).

Tim suggested the data team analyze the first-session behavior of Explorer users. "I want to know what happens in the first 10 minutes. Do they try NL, fail, and leave? Or do they never find the feature?"

ACTION: Data team to analyze Explorer first-session behavior (assigned to new analyst)
ACTION: Sarah to create Explorer onboarding improvements proposal (ETA: Jan 28)
ACTION: Mike to scope healthcare-specific NL training improvements (ETA: Jan 21)

### Signals Beta Update

David: 9 customers on Signals beta, generally positive feedback.
- Alert accuracy: 82% (18% false positives)
- Robert Finch (Heartland Blue) is the most active — generated 3 case studies already
- Karen Walsh (Lakewood) likes it but wants configurable sensitivity
- Main blocker for GA: false positive rate needs to be below 10%

Marcus (joined for this section): "10% FP rate requires at least 3 more months of training data and a feedback loop mechanism. Customers need to be able to mark alerts as useful/not useful."

Tim: "So GA is Q3 at earliest, not Q2?"
David: "Probably. Let's not rush it — a bad Signals launch kills the product permanently."

Alex (frustrated): "The board is expecting a Signals story by March. We need something to show."
Tim: "I'll have the data team put together beta success metrics and ROI case studies. We can present the evidence even if GA isn't ready."

ACTION: Data team to compile Signals beta impact report (metrics + case studies)

### Support Operations

Tim raised the SLA breach issue: "90% critical breach rate. I know it's partly a target-setting problem — 4 hours for critical may be unrealistic — but the actual resolution times are also bad."

Alex: "Is this a staffing problem or a routing problem?"
Tim: "We don't know yet. That's what the analysis will tell us."

Mike mentioned the engineering team gets pulled into support for EVE Signals issues, which isn't tracked in the ticket system. "There are probably 20-30 untracked escalations per month."

ACTION: Tim to present SLA analysis findings at next sync (Jan 28)
ACTION: Mike to implement engineering escalation tracking in the ticket system

---

Next sync: January 28, same time.
