# Module 1.2: Workspace Setup

**Teaching script for Claude Code**

> **Before starting:** Read `.claude/SCRIPT_INSTRUCTIONS.md` for critical teaching rules.

---

## Your Role

You're leading Module 1.2. Tim gave the student a task: prepare for the data review with Alex by having proper workspace visibility. Setting up the workspace is a means to do real work, not a goal in itself.

**Teaching style:**
- Workspace setup is practical, not ceremonial
- Every step connects to "you'll need this for actual analysis"
- Keep it moving — this module should feel quick and productive

---

## Learning Objectives

By the end of this module, the student should:
1. Have a text editor open side-by-side with the terminal
2. Be able to navigate the project folder structure
3. See CSV data in the editor
4. Have the sqlite3 database created and ready for SQL queries
5. Understand slash commands and CLAUDE.md
6. Be ready for Module 1.3

---

## Step 0: Read Student Config (silent)

**Action:** Read project CLAUDE.md, get ANALYST_LEVEL. Adapt tone accordingly.

---

## Lesson Flow

### Step 1: Tim's Morning Message (1 minute)

**Say:**

"Morning — day two at EVE Health.

Tim sent you a Slack message:

---

*'Before the data review with Alex, set up your workspace properly. You'll want to see files and data side-by-side with the terminal. Everyone on the team works this way — it's the difference between guessing and knowing.*

*Once your workspace is set up, take a look at the support tickets CSV. Get a feel for the data shape. You'll be deep in that file starting tomorrow.*

*— Tim'*

---

Let's get your workspace set up. It'll take about 10 minutes, then you'll be ready for real work.

First: which code editor do you have? Say: **'VS Code'**, **'Cursor'**, or **'something else'**."

**Check:** Wait for the student's response

**Logic:**
- **VS Code or Cursor** → "Perfect — that's what most of the team uses."
- **Something else** → "That works too — as long as you can open a folder and see files in a sidebar, you're good."
- **None / don't know** → Recommend VS Code, provide download link, guide through installation

---

### Step 2: Side-by-Side Setup (3 minutes)

**Say:**

"Here's what your workspace should look like:

**Left side:** Your code editor with the project folder open
**Right side:** This terminal (Claude Code)

To set this up:

1. Open your editor
2. Go to File → Open Folder
3. Navigate to the folder where this course lives (the `eve-health-course` folder)
4. You should see the folder tree on the left: `company-context/`, `lesson-modules/`, `.claude/`

*(For Junior:)* If you're not sure where the folder is, look at the path shown at the top of this terminal window — that's where you are right now.

5. Resize your windows: editor on the left half of the screen, terminal on the right half

**Keyboard shortcut (Mac):** Hold the green maximize button to snap to left/right
**Keyboard shortcut (Windows):** Win + Left Arrow / Win + Right Arrow

Done? Can you see the files on the left and this terminal on the right? Say: **'I see both'**"

**Check:** Wait for confirmation

---

### Step 3: Exploring the File Structure (3 minutes)

**When the student confirms, say:**

"Nice. Let me show you what's in here."

**Action:**

Run: `find . -type f -name "*.md" | head -20`

**Present it like this:**

"Here's the project structure:

**company-context/** — Everything about EVE Health
- `COMPANY.md` — Company overview (you read this yesterday)
- `PRODUCT.md` — Product deep-dive
- `PERSONAS.md` — User personas
- `COMPETITIVE.md` — Competitive landscape
- `data/eve_health_support_tickets.csv` — Your main dataset

**.claude/** — Course mechanics
- `SCRIPT_INSTRUCTIONS.md` — Teaching rules
- `agents/` — Team member personas for sub-agent tasks
- `commands/` — Slash commands that launch modules

**lesson-modules/** — The actual work, organized by block

Click on `COMPANY.md` in your editor — see it on the left? That's the file I read yesterday when I briefed you on EVE Health.

Now click on `company-context/data/eve_health_support_tickets.csv` — open it in the editor.

Can you see the CSV data? Say: **'I see the data'**"

**Check:** Wait for confirmation

---

### Step 4: First Look at the Data (3 minutes)

**When the student confirms, say:**

"Good. That CSV is going to be your best friend and your biggest headache for the next few weeks.

Let me give you a quick overview."

**Action:**

```bash
cd company-context/data
head -3 eve_health_support_tickets.csv
echo "---"
wc -l eve_health_support_tickets.csv
```

**Present it like this:**

"**2,672 support tickets.** July 2025 through January 2026.

Columns: ticket_id, created_at, resolved_at, closed_at, hours, status, requester_name, customer_type, agent_name, category, priority, sla_target_hours, is_sla_breached, is_first_contact_resolution, original_ticket_id, implementation_project.

This is real operational data — every ticket a customer filed with EVE Health support. You'll use this to investigate SLA breaches, analyze agent performance, find patterns in categories, and build dashboards.

Now let's set up the database so you can query it with SQL."

---

### Step 5: Database Setup (3 minutes)

**Say:**

"Most modules let you choose between SQL and Python. For SQL, we need a database. Let me set one up from the CSV."

**Action:**

```bash
cd /path/to/eve-health-course
sqlite3 eve_health.db << 'SQL'
.mode csv
.import company-context/data/eve_health_support_tickets.csv support_tickets
.schema support_tickets
SELECT COUNT(*) as total_tickets FROM support_tickets;
SELECT priority, COUNT(*) as count FROM support_tickets GROUP BY priority ORDER BY count DESC;
SQL
```

**Present it like this:**

"Database created: `eve_health.db`

Quick test — ticket count by priority:
[show the results]

The database is ready. When modules offer SQL tasks, you'll query this database. When they offer Python tasks, you'll read the CSV directly with pandas.

*(For Junior:)* Don't worry if you've never used SQL or sqlite3 before — every module provides the exact commands. You'll pick it up naturally.

*(For Senior:)* The database is basic sqlite3 — no window functions like QUALIFY, but CTEs and standard window functions work. For anything complex, Python + pandas is usually faster."

---

### Step 6: CLAUDE.md and Slash Commands (2 minutes)

**Say:**

"Two more things about how the course works, then we're done.

**1. CLAUDE.md — Project Memory**

Open `CLAUDE.md` in your editor (it's in the project root). You'll see:

```
ANALYST_LEVEL: [your_level]
```

This is how I remember your preferences between modules. In Module 1.6, you'll learn how to use this file for much more — context handoff, project memory, team instructions. For now, just know it exists.

**2. Slash Commands**

Every module starts with a slash command:
- `/start-1-1` — launched Module 1.1 (yesterday)
- `/start-1-2` — launched this module
- `/start-1-3` — next module (the real work begins)

You can run any module at any time. They build on each other, but if you need to revisit something, just run the command.

Clear? Say: **'Clear'**"

**Check:** Wait for confirmation

---

### Step 7: Wrap Up (1 minute)

**Say:**

"Workspace is set up. You've got:
- ✅ Editor and terminal side-by-side
- ✅ Project files visible and navigable
- ✅ CSV data in view
- ✅ sqlite3 database ready for SQL queries
- ✅ CLAUDE.md saving your preferences
- ✅ Slash commands ready to go

**What's next: Module 1.3**

Tim pings you Monday morning at 9 AM: 'I need the weekly analytics digest by 5 PM today.' Five items, nine hours. Without Claude Code, that's a full work day. With it — about an hour.

When you're ready:
```
/start-1-3
```"

---

## Notes for Claude (you)

**Keep it practical:**
- Every setup step connects to "you'll need this for X"
- Don't make workspace setup feel ceremonial
- If the student struggles with editor setup, be patient but efficient

**Database creation:**
- If sqlite3 isn't available, install it: `sudo apt-get install sqlite3`
- If CSV import fails, debug the path — most common issue

**Editor flexibility:**
- Any editor works — VS Code, Cursor, Sublime, Vim, even TextEdit
- The point is side-by-side visibility, not a specific tool

---

## Success Criteria

Module 1.2 is complete if the student:
- ✅ Has editor + terminal side by side
- ✅ Can see project files in the editor sidebar
- ✅ Has opened the CSV in the editor
- ✅ Has a working sqlite3 database
- ✅ Understands slash commands and CLAUDE.md
- ✅ Knows what's next (Module 1.3)
