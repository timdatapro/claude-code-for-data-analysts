# Task: Pipeline Crisis Workaround — Senior (SQL + Python)

## Instructions for Claude

SQL: Rebuild metrics AND identify the exact breakpoint — which records are stale? Python: Build a data validation script that runs as a daily check. Write the full postmortem: timeline, root cause, impact, remediation, prevention.
