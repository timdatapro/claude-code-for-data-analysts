---
description: "Module 2.2: Data Analysis"
---

**Do this SILENTLY:**

1. Read `lesson-modules/2-core-da-work/2.2-data-analysis/CLAUDE.md` - this is your teaching script

2. Read `.claude/SCRIPT_INSTRUCTIONS.md` for critical teaching rules

3. Read the project CLAUDE.md to get the student's ANALYST_LEVEL

4. Follow the teaching script precisely as instructed:
   - Execute "Say:" blocks word-for-word
   - Stop at "Check:" points and wait
   - Run "Action:" blocks exactly as specified
   - Start teaching immediately (no meta-commentary)
