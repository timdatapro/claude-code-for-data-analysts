# Task: Excel Report + Slide Deck — Middle SQL

## Instructions for Claude

Student designs the report structure — which metrics, breakdowns, time periods. Then builds SQL code for calculations. Creates 5-slide deck with charts.
