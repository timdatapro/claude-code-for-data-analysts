# Module 1.7: Crisis — Pipeline Down Before Board Meeting

**Teaching script for Claude Code**

> **Before starting:** Read `.claude/SCRIPT_INSTRUCTIONS.md` and project CLAUDE.md for ANALYST_LEVEL.

---

## Your Role
You're leading Module 1.7. The data pipeline broke 36 hours before Rachel's board meeting. The student must triage, build a manual workaround, and write a postmortem. This module teaches working under pressure with incomplete data.

---

## Learning Objectives
1. Triage data issues quickly
2. Build manual workarounds when automated systems fail
3. Write professional postmortems
4. Communicate during crisis (clear, calm, factual)

---

## Lesson Flow

### Step 1: The Crisis (2 min)

**Say:**

"Module 1.7 — Crisis Mode.

Thursday, 4:47 PM. Tim's Slack (marked urgent):

---

*'Data pipeline broke. The board meeting dashboard is showing last week's numbers. Rachel presents in 36 hours.*

*I need you to:*
*1. Figure out what's wrong with the data*
*2. Build a manual workaround so Rachel has accurate numbers*
*3. Write a postmortem draft*

*Priya is debugging the pipeline itself. You handle the analytics side.*

*The pipeline broke 36 hours before the board meeting. If you're thinking 'that's not enough time' — congratulations, you now understand the job.*

*— Tim'*

---

Ready? Say: **'Let's fix this'**"

**Check:** Wait

---

### Step 2: Triage (5 min)

**Say:**

"First: understand what's broken. Let me check the crisis folder."

**Action:** Read files in `crisis/` directory:
- `dashboard-snapshot-broken.md` — what the dashboard shows (wrong)
- `last-known-good-data.md` — last reliable data points
- `board-deck-template.md` — what Rachel needs
- `priya-slack-thread.md` — Priya's debugging updates

**Present findings and say:**

"Here's the situation: [summarize what's broken vs what Rachel needs].

The dashboard shows stale numbers from last week. Rachel needs current numbers. Priya is fixing the pipe but it won't be ready in time. We need a manual workaround."

---

### Step 3: Manual Workaround (15 min)

**Branch by level and load task files.**

#### [JUNIOR]
AskUserQuestion "SQL or Python?" → Load task file.
Guided step-by-step to rebuild key metrics manually from the CSV.

#### [MIDDLE]
AskUserQuestion "SQL or Python?" → Load task file.
"Rebuild the 4 key board metrics from the raw data. Find discrepancies. Fix them."

#### [SENIOR]
Load `tasks/senior.md`.
Both SQL and Python. Rebuild metrics + build a data validation script for future prevention.

---

### Step 4: Postmortem (5 min)

**Say:**

"Numbers are fixed. Now: the postmortem. Every crisis at EVE Health gets a blameless postmortem. This is how good teams prevent the next crisis."

*(For Junior/Middle:)* Provide a postmortem template.
*(For Senior:)* "Write the full postmortem: timeline, root cause, impact, remediation, prevention. And make a recommendation: should we build automated data quality checks? If this doesn't make you want automated monitoring, nothing will."

---

### Step 5: Wrap-Up (2 min)

**Say:**

"Crisis handled. Rachel has her numbers. Postmortem is documented.

- ✅ Triaged the data issue
- ✅ Built manual workaround with accurate metrics
- ✅ Wrote professional postmortem

**Key lesson:** Data pipelines break. Dashboards go stale. Analysts who can rebuild from raw data in a crisis are worth their weight in gold.

When ready: `/start-1-8`"

---

## Supporting Files Needed in `crisis/` directory

Create these files:
- `dashboard-snapshot-broken.md` — shows stale metrics with dates from last week
- `last-known-good-data.md` — last verified metric values with timestamps
- `board-deck-template.md` — Rachel's deck with blank metric slots to fill
- `priya-slack-thread.md` — Priya's real-time updates as she debugs
