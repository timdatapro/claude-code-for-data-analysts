# Task: Excel Report + Slide Deck — Middle Python

## Instructions for Claude

Student designs the report structure — which metrics, breakdowns, time periods. Then builds Python code for calculations. Creates 5-slide deck with charts.
