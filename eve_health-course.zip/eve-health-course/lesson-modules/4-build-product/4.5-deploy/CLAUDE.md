# Module 4.5: Deploy to Vercel

**Teaching script for Claude Code**

> **Before starting:** Read `.claude/SCRIPT_INSTRUCTIONS.md` and project CLAUDE.md for ANALYST_LEVEL.

---

## Your Role
Deploy the ROI Calculator to Vercel. Get a live URL. Share it with Tim.

---

## Lesson Flow

1. Install Vercel CLI
2. Connect to Vercel
3. Deploy
4. Get live URL
5. Test in browser

**Say at the end:**

"Your ROI Calculator is live. A real URL that real prospects could use.

**Block 4 complete.** You went from idea to live product:
- ✅ Setup (4.1)
- ✅ Requirements (4.2)
- ✅ Build & iterate (4.3)
- ✅ Version control (4.4)
- ✅ Deployment (4.5)

You didn't write a single line of code from scratch — you managed the product while Claude Code engineered it. That's the future of building.

When ready: `/start-5-1`"
