# Task: Multi-Source Data Analysis — Senior (SQL + Python)

## Instructions for Claude

SQL + Python: user segmentation by behavior + satisfaction cross-reference. Statistical tests (is NPS difference significant?). Regression model of adoption drivers. Full synthesis report with quantitative + qualitative triangulation.
