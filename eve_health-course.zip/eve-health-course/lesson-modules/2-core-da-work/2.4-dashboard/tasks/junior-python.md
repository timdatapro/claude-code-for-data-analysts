# Task: Dashboard Spec + Prototype — Junior Python

## Instructions for Claude

Python: query top 5 metrics Bob needs. Build 3 matplotlib chart panels. Fill in dashboard spec template.
