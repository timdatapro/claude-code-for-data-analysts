# Task: SLA Breach Investigation — Junior SQL

## Instructions for Claude

**Provide guided queries step by step:**

**Step 1 — Trend:**
"Run this query to see the SLA breach rate by month:"
```sql
SELECT strftime('%Y-%m', created_at) as month,
       COUNT(*) as total,
       SUM(CASE WHEN is_sla_breached=1 THEN 1 ELSE 0 END) as breached,
       ROUND(AVG(CASE WHEN is_sla_breached=1 THEN 1.0 ELSE 0.0 END)*100, 1) as breach_pct
FROM support_tickets
WHERE status='Resolved' AND priority='Critical'
GROUP BY month ORDER BY month;
```
"What pattern do you see?"

**Step 2 — By category:**
"Now let's see which categories drive the breaches:"
```sql
SELECT category, COUNT(*) as total,
       ROUND(AVG(CASE WHEN is_sla_breached=1 THEN 1.0 ELSE 0.0 END)*100, 1) as breach_pct
FROM support_tickets
WHERE status='Resolved' AND priority='Critical'
GROUP BY category ORDER BY breach_pct DESC;
```

**Step 3 — By agent:**
"Are some agents more overloaded?"
```sql
SELECT agent_name, COUNT(*) as total,
       ROUND(AVG(hours), 1) as avg_hours
FROM support_tickets WHERE status='Resolved'
GROUP BY agent_name ORDER BY total DESC;
```

**After each query:** Help the student interpret results. Ask "What does this tell us?"
