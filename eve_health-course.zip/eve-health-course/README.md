# Claude Code for Data Analysts

A hands-on course: learn Claude Code through real analytics tasks inside the EVE Health simulator. No videos — just work in the tool.

**Author:** Tim Fateev | [LinkedIn](https://www.linkedin.com/in/tim-datapro/)
**License:** CC BY 4.0

---

## What You'll Learn

You're a new Product Analyst at EVE Health, a healthcare analytics company. You'll investigate metric spikes, build dashboards, automate reports, present to executives, and deploy a live product — all using Claude Code.

**Three difficulty levels:** Junior (0–1 yr), Middle (1–3 yr), Senior (3+ yr). Choose your level in Module 1.1. Every module adapts tasks, code complexity, and expectations to your level.

**Tools used:** SQL, Python (pandas, numpy, matplotlib, seaborn), dbt (Senior only).

---

## Course Structure

| Block | Module | Topic |
|---|---|---|
| **1 — Fundamentals** | 1.1 | First day at EVE Health |
| | 1.2 | Workspace setup |
| | 1.3 | Weekly analytics digest |
| | 1.4 | Parallel agents — batch processing |
| | 1.5 | Metric spike investigation |
| | 1.6 | Memory & handoff (CLAUDE.md) |
| | 1.7 | Crisis — pipeline broke before board meeting |
| | 1.8 | Skills — Excel reports & slide decks |
| | 1.9 | Competitive benchmarking |
| | 1.10 | Build your own analysis skill |
| **2 — Core DA Work** | 2.1 | Analysis brief — frame the question |
| | 2.2 | Data analysis — surveys + usage + interviews |
| | 2.3 | Insights deck — present to leadership |
| | 2.4 | Dashboard spec + prototype |
| **3 — Visual Content** | 3.1 | Advanced visualization (or AI image gen) |
| | 3.2 | DA visualization use cases |
| **4 — Build a Product** | 4.1 | Setup (Node.js, GitHub) |
| | 4.2 | Plan the ROI Calculator |
| | 4.3 | Build & iterate |
| | 4.4 | GitHub versioning |
| | 4.5 | Deploy to Vercel |
| **5 — What's Next** | 5.1 | MCP integrations |
| | 5.2 | Team rollout |

---

## Prerequisites

- Claude Pro or Max subscription
- Claude Code installed ([instructions](https://docs.anthropic.com))
- A code editor (VS Code recommended)
- Curiosity

**Not required:** Programming expertise, terminal knowledge, your own data.

---

## Getting Started

1. Download and unzip this course
2. Open the terminal in the course folder
3. Run `claude`
4. Type `/start-1-1`
5. Follow the instructions

---

## Important for Block 3 (Image Generation Track)

If you choose Track B (AI Image Generation), you'll need:
- Python 3
- Gemini API key (free tier — instructions in module 3.1)

Track A (Data Visualization) requires no additional setup.

---

## Estimated Time

| Level | Per Module | Full Course |
|---|---|---|
| Junior | 15–30 min | 12–18 hours |
| Middle | 20–40 min | 18–25 hours |
| Senior | 30–60 min | 25–35 hours |

---

## About EVE Health

EVE Health is a fictional healthcare analytics company created for this course. All data, characters, and scenarios are simulated. Any resemblance to real companies or individuals is coincidental.

---

**Let's make healthcare data work harder.**
