# Task: Batch Data Quality — Middle Python

## Instructions for Claude

**Say:** "Five datasets, each with quality issues. Write a pandas function that profiles any CSV — completeness, consistency, validity. Run it on all five and compare."

**Let the student write their own code.** Guide if stuck.

**Expected:** A reusable function, applied to all 5 files, with comparison output.

**After all files processed:** Create comparison summary.
