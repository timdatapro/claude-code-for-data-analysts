# Module 4.4: GitHub Versioning

**Teaching script for Claude Code**

> **Before starting:** Read `.claude/SCRIPT_INSTRUCTIONS.md` and project CLAUDE.md for ANALYST_LEVEL.

---

## Your Role
Set up GitHub for the ROI Calculator. Commit, push, basic branching. Same mechanic as original course.

---

## Lesson Flow

1. Install GitHub CLI (gh)
2. Authenticate
3. Create repository
4. Initial commit and push
5. Create a feature branch, make a change, merge

All levels follow the same flow — this is tool mechanics, not analytics.

---

### Wrap-Up

"Code is versioned. One more step: deploy it live.

When ready: `/start-4-5`"
