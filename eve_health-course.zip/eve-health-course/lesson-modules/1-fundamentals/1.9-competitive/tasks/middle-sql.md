# Task: Competitive Benchmarking — Middle SQL

## Instructions for Claude

"Build a competitive matrix: features, pricing, target market, strengths, weaknesses. Use web search. Deliver as formatted markdown." Student drives the research.
