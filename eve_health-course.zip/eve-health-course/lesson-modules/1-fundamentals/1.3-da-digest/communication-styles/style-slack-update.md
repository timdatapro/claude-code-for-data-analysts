# Communication Style: Slack Update

## When to use
Weekly team updates, quick wins, announcements, informal syncs

## Format rules
- Lead with the most important thing (above the fold)
- Use emoji for section headers (not in body text)
- Keep paragraphs to 2-3 sentences max
- Bold key numbers and names
- End with clear next steps or a question to drive engagement
- Total length: 150-250 words

## Tone
- Casual but professional
- First person ("we" not "the team")
- Direct — don't hedge
- Celebrate wins before raising problems
- Use "heads up" not "please be advised"

## Example

📊 **Weekly Data Digest — Jan 13-17**

Quick wins first: **Bob** shipped the CFO dashboard on time, and **Jamie** caught a data definition bug that would have skewed our Explorer metrics. Nice catches.

🔴 **The big number:** Critical SLA breach is still at **90%**. Tim is presenting root cause analysis at the Jan 28 sync. If you have theories, drop them in #data-team.

📈 **Ticket volume** was up 12% this week — mostly Connector issues from new customer onboarding. Emily flagged this as a pattern: we're promising 48-hour deployment but our connector library has gaps.

🎯 **This week's focus:**
- Marcus: churn risk model validation (due Jan 24)
- Priya: Snowflake migration completion
- New analyst: onboarding + first look at support ticket data

Questions? Ping Tim or drop them here.
