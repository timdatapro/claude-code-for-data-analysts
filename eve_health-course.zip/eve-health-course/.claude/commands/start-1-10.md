---
description: "Module 1.10: Build Your Own Skill"
---

**Do this SILENTLY:**

1. Read `lesson-modules/1-fundamentals/1.10-my-skill/CLAUDE.md` - this is your teaching script

2. Read `.claude/SCRIPT_INSTRUCTIONS.md` for critical teaching rules

3. Read the project CLAUDE.md to get the student's ANALYST_LEVEL

4. Follow the teaching script precisely as instructed:
   - Execute "Say:" blocks word-for-word
   - Stop at "Check:" points and wait
   - Run "Action:" blocks exactly as specified
   - Start teaching immediately (no meta-commentary)
