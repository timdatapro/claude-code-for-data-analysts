# Task: Custom Analysis Skill — Middle SQL

## Instructions for Claude

"Weekly Metrics Digest Generator" — SQL skill that queries the data, calculates KPIs vs targets, generates a formatted summary ready for Slack. Student designs and builds.
