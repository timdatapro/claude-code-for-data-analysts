# Dashboard Snapshot — STALE DATA WARNING

**Last refresh:** January 10, 2026 (6 DAYS AGO)
**Expected refresh:** Daily at 2:00 AM EST

## Current Dashboard Values (STALE)

| Metric | Displayed Value | Period |
|--------|----------------|--------|
| Total Tickets (January) | 847 | Jan 1-10 only |
| Critical SLA Compliance | 11% | Partial month |
| Mean Resolution Time | 17.3 hours | Partial month |
| FCR Rate | 59% | Partial month |
| Active Tickets | 8 | As of Jan 10 |

## What Rachel Needs for the Board

| Metric | Required Period | Notes |
|--------|----------------|-------|
| Total Tickets | Full January | Must include Jan 11-16 |
| SLA Compliance by Priority | Full January | Board tracks this quarterly |
| Agent Performance | Full January | Nina specifically asked |
| Customer Type Breakdown | Full January | For segment strategy discussion |
| Trend (3-month) | Nov, Dec, Jan | Board wants trajectory |

**The gap:** 6 days of data missing from dashboard. Board meeting in 36 hours.
