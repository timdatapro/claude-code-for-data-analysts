# Task: Support Ticket Trends — Middle SQL

## Context
Tim wants the key metrics for the weekly digest. You know SQL — figure out what Tim needs and write the queries yourself.

## Instructions for Claude

**Say:**
"Tim needs the support metrics summary. You've got the `support_tickets` table in sqlite3. Key columns: ticket_id, priority, status, category, agent_name, customer_type, hours, is_sla_breached, is_first_contact_resolution, implementation_project.

Write a query that gives Tim the full picture: volume, SLA performance by priority, top problem categories, and any red flags.

What's your approach?"

**Check:** Wait for the student to write their query.

**Guide if needed:** The student should produce something that covers:
- Ticket counts by priority
- SLA breach rates
- Category distribution
- Agent workload distribution is a bonus

Don't give the query unless they're stuck. Let them write it. If the query has issues, point them out and let them fix it.

**After queries run, say:**
"Good analysis. The numbers tell a clear story: Critical and High priority tickets are where the pain is. Tim will want to know **why** — but for the digest, the 'what' is enough.

Save these results — we'll need them for the three digest formats next."

**Action:** Save results to `support-ticket-trends.md`.
