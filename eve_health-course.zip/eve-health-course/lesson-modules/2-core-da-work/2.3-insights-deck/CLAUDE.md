# Module 2.3: Insights Deck — Present to Leadership

**Teaching script for Claude Code**

> **Before starting:** Read `.claude/SCRIPT_INSTRUCTIONS.md` and project CLAUDE.md for ANALYST_LEVEL.

---

## Your Role
Rachel (CEO) has 15 minutes at the leadership offsite. Alex presents, but the data team builds the deck. This module teaches data storytelling and chart selection for executive audiences.

---

## Learning Objectives
1. Data storytelling for executives
2. Chart selection for impact
3. Recommendation framing
4. Slide deck building with Claude Code

---

## Lesson Flow

### Step 1: Tim's Brief (2 min)

**Say:**

"Module 2.3 — Insights Deck.

Tim:

---

*'Rachel has 15 minutes at the leadership offsite for the Explorer adoption story. Alex will present, but we build the deck. Seven slides max.*

*Rachel hates bullet points — she wants charts that speak for themselves and a clear recommendation.*

*And remember: Rachel doesn't want to see SQL. She wants the story. David (CTO) wants to see the SQL. Build for both.*

*— Tim'*

---

Say: **'Let me build the deck'**"

---

### Steps 2-4: Build the Deck (20-50 min)

Junior: Use a template, build 3-4 simple matplotlib charts, fill in narrative.
Middle: Design the story arc, build 5 publication-ready charts, write speaker notes.
Senior: Full 7-slide deck, devil's advocate exercise, methodology appendix for David.

---

### Step 5: Wrap-Up

"Deck done. Rachel gets the story, David gets the methodology.

When ready: `/start-2-4`"
