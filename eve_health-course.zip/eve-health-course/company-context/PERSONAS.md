# EVE Health — User Personas & Stakeholders

**Deep dive: who uses EVE, why they bought it, and what keeps them up at night.**

---

## Overview

EVE serves four primary personas across our customer organizations. Understanding them is critical — every dashboard you build, every metric you investigate, and every insight you present affects real people making real healthcare decisions.

These aren't abstractions. They're composites of actual users. When Tim says "what would Karen think of this?" — he means this Karen.

---

## Persona 1: Dr. Karen Walsh (Hospital CMO)

### Quick Facts

**Name:** Dr. Karen Walsh
**Age:** 54
**Role:** Chief Medical Officer
**Organization:** Lakewood Regional Health (3,200 employees, 4 facilities, suburban Ohio)
**EVE Tier:** Enterprise
**EVE modules used:** Insights (daily), Signals (beta), Explorer (rarely)

### Background

Karen oversees clinical quality, patient safety, and medical staff affairs across four facilities. She reports directly to the CEO and presents quality metrics to the board quarterly. Her team includes 3 quality managers, 2 patient safety officers, and a clinical data analyst (who uses EVE Explorer daily).

**Career path:**
- Internal Medicine residency → Hospitalist → Medical Director → CMO
- 25 years in clinical practice, 8 years in executive leadership
- Board-certified in Internal Medicine and Healthcare Quality

**Education:**
- MD, Case Western Reserve
- MBA, Ohio State (part-time during CMO tenure)
- CPHQ (Certified Professional in Healthcare Quality)

### Goals and Motivations

**Primary goals:**
1. **Reduce readmission rates** — CMS penalties cost Lakewood $1.2M last year
2. **Board-ready reporting** — Monthly quality dashboard that tells a story, not just shows numbers
3. **Early warning system** — Know about problems before they become Joint Commission findings
4. **Justify investments** — Data-backed cases for new programs (sepsis bundle, fall prevention)

**Success metrics:**
- 30-day readmission rate (currently 14.2%, target <12%)
- HCAHPS overall score (currently 71st percentile, target 80th)
- Serious safety events per quarter (currently 2.1, target <1)
- Time from data to decision (currently 3 weeks, target <3 days)

### Pain Points

**1. Data arrives too late to act on**
- Monthly quality reports are 3 weeks old by the time they reach her desk
- "I found out about the readmission spike from a CMS letter, not from our own data"
- Wants real-time or at least daily visibility into key metrics

**2. Can't connect clinical and financial data**
- Quality metrics live in one system, financial impact in another
- Board asks "what did that readmission problem cost us?" — takes 2 weeks to answer
- Needs a single view that shows clinical outcomes AND financial impact

**3. Too many reports, not enough insights**
- Gets 14 different reports weekly from different departments
- None of them agree on the same numbers
- "I need someone to tell me the three things I should worry about this week"

**4. Regulatory reporting is a nightmare**
- CMS, Joint Commission, state health department — all want different cuts of similar data
- Her clinical data analyst spends 60% of their time on compliance reports
- EVE Insights helps, but custom regulatory views aren't available yet

### Jobs to Be Done

**When...**
- ...the board asks about quality → Open EVE Insights, show the CMO dashboard, explain trends in 90 seconds
- ...a safety event occurs → Check Signals alerts to see if there was an early warning
- ...CMS sends a penalty notice → Pull readmission data by DRG, payer, and attending physician
- ...budget season arrives → Show data on how quality programs reduced penalties and improved outcomes
- ...a new service line launches → Set up monitoring dashboards before day one

### Quotes (from user research)

> "I didn't become a doctor to read spreadsheets. But I became a CMO, so here we are."

> "If EVE could tell me the three things to worry about each morning — and the three things going well — I'd never log into anything else."

> "Health Catalyst wanted $600K and 9 months. EVE was live in 2 weeks. The dashboards aren't as pretty, but they're accurate and they're fast."

---

## Persona 2: Miguel Santos (Clinical Data Lead)

### Quick Facts

**Name:** Miguel Santos
**Age:** 36
**Role:** Clinical Data Lead
**Organization:** University Medical Center (8,500 employees, Level 1 Trauma Center, academic, Texas)
**EVE Tier:** Professional
**EVE modules used:** Explorer (daily power user), Insights (reference), Signals (beta tester)

### Background

Miguel runs a 4-person clinical analytics team embedded in the Quality department. He's the bridge between clinicians who have questions and the data warehouse that has answers. He writes SQL before breakfast and presents to the CMO before lunch.

**Career path:**
- Biostatistics degree → Research coordinator → Clinical data analyst → Team lead
- 12 years in healthcare data, 4 years managing a team
- Fluent in SQL, Python, R, Tableau, Power BI — and now EVE Explorer

**Education:**
- MS Biostatistics, UT Health Science Center
- Certified Health Data Analyst (CHDA)

### Goals and Motivations

**Primary goals:**
1. **Reduce ad-hoc request backlog** — Currently 47 open requests, average turnaround 12 days
2. **Enable self-serve analytics** — Get clinicians to answer their own questions using Explorer
3. **Advanced analytics** — Move beyond descriptive dashboards to predictive models
4. **Career growth** — Wants to build a true analytics center of excellence

**Success metrics:**
- Ad-hoc request backlog (currently 47, target <15)
- Self-serve rate: % of questions answered without his team (currently 20%, target 60%)
- Report turnaround time (currently 12 days, target 3 days)
- Predictive models in production (currently 1, target 5)

### Pain Points

**1. EVE Explorer is powerful but limited**
- Natural language queries work 70% of the time — the other 30% is frustrating
- Can't do window functions or complex joins in Explorer's visual builder
- "I end up exporting to Python and doing it there, which defeats the purpose"
- Wants an advanced mode with SQL access inside Explorer

**2. Bottleneck problem**
- He IS the bottleneck — every department comes to him for custom reports
- Clinicians won't learn Explorer because "it's easier to just ask Miguel"
- When he's on vacation, the backlog doubles

**3. Data quality issues**
- EHR data is messy — missing fields, inconsistent coding, duplicate records
- Spends 40% of his time cleaning data, 60% analyzing it
- EVE's data quality checks help but miss edge cases specific to academic medical centers

**4. Can't integrate all data sources**
- EVE handles EHR and claims data well
- But research data (clinical trials), HR data (staffing), and supply chain data live elsewhere
- Wants one platform for everything, not five

### Jobs to Be Done

**When...**
- ...a department head wants a custom report → Build it in Explorer, share the saved report so they can run it themselves next time
- ...data looks wrong → Trace it back through the pipeline, find the source issue, flag it for Priya's team
- ...the CMO needs a deep dive → Write SQL, build a statistical model, create publication-quality visualizations
- ...a new analyst joins the team → Train them on Explorer, set up their workspace, show them the data dictionary

### Quotes (from user research)

> "Explorer is great for 80% of questions. But the 20% that matter most — those still need SQL. Give me a SQL mode and I'll never leave."

> "I've been doing healthcare data for 12 years. EVE is the first tool where non-technical people actually use it without calling me every hour."

> "Your anomaly detection caught a billing code error that would have cost us $340K in denied claims. That single alert paid for our annual subscription."

---

## Persona 3: Lisa Chang (Digital Health PM)

### Quick Facts

**Name:** Lisa Chang
**Age:** 31
**Role:** VP of Product
**Organization:** Wellspring Digital Health (85 employees, Series B, remote-first, SF)
**EVE Tier:** Professional (evaluating Enterprise upgrade for Signals)
**EVE modules used:** Insights (weekly), Explorer (occasionally)

### Background

Lisa leads product at a digital health startup that builds remote patient monitoring tools. Her company collects massive amounts of patient-generated data (wearables, home devices) and needs analytics to show clinical outcomes to health system customers and FDA.

**Career path:**
- Software engineer → PM at Athenahealth → Lead PM at Oscar Health → VP Product at Wellspring
- 9 years in health tech, deep understanding of clinical workflows and data
- Comfortable with data but doesn't write SQL herself

**Education:**
- BS Computer Science, Stanford
- No MBA ("I learned everything I need from shipping products")

### Goals and Motivations

**Primary goals:**
1. **Prove clinical outcomes** — Wellspring needs to show their RPM tool improves patient outcomes. EVE helps analyze the data.
2. **FDA submission support** — Building evidence for a de novo 510(k) submission. Needs rigorous analytics with audit trails.
3. **Customer dashboards** — Wellspring's hospital customers want to see outcomes data. EVE could power those dashboards.
4. **Fundraising narrative** — Series C in 6 months. Needs data-backed impact story.

**Success metrics:**
- Clinical outcome improvement measurable through EVE (target: 15% reduction in hospital readmissions for RPM patients)
- FDA submission timeline (target: Q4 2026)
- Customer dashboard satisfaction (NPS target: +50)
- Time to generate outcome reports (currently 2 weeks, target same-day)

### Pain Points

**1. Needs enterprise features at startup prices**
- EVE Professional does 80% of what she needs
- The 20% gap: audit trails, data versioning, role-based access for FDA reviewers
- Enterprise tier is expensive for a Series B startup

**2. Integration complexity**
- Wellspring's data comes from wearables, not EHRs
- EVE's connectors are built for hospital data, not IoT device data
- Custom integration required, which Priya's team deprioritizes (small account)

**3. Regulatory analytics gap**
- FDA wants specific statistical analyses (intention-to-treat, per-protocol)
- EVE doesn't have pre-built regulatory report templates
- Miguel's team at UMC does this in R — Lisa doesn't have a Miguel

**4. Scaling problem**
- If Wellspring signs 10 hospital customers, each needs their own EVE instance
- Multi-tenant analytics isn't straightforward
- "We need EVE-as-a-service, not EVE-as-a-product"

### Quotes (from user research)

> "We're a startup trying to get FDA clearance. We need analytics that are rigorous enough for regulators but fast enough for a team that ships weekly."

> "I love EVE for internal analytics. But I can't show these dashboards to the FDA — I need audit trails, data lineage, and version control."

> "If you build an API that lets me embed EVE dashboards in our product, I'll triple my contract tomorrow."

---

## Persona 4: Robert Finch (Insurance Actuary)

### Quick Facts

**Name:** Robert Finch
**Age:** 48
**Role:** VP of Actuarial Analytics
**Organization:** Heartland Blue (regional health insurance, 2,800 employees, Des Moines, Iowa)
**EVE Tier:** Enterprise
**EVE modules used:** Signals (beta — primary use case), Explorer (weekly), Insights (rarely)

### Background

Robert leads a 12-person actuarial team at a regional health insurer covering 1.2M lives. His team prices risk, detects fraud, and forecasts medical costs. He needs tools that can process millions of claims records and surface anomalies before they become $10M problems.

**Career path:**
- Actuarial analyst → Pricing actuary → VP at major national insurer → VP at Heartland Blue (wanted to have more impact at a smaller org)
- FSA (Fellow of the Society of Actuaries), MAAA
- 22 years in insurance analytics

**Education:**
- BS Mathematics, Iowa State
- MS Applied Statistics, Iowa State

### Goals and Motivations

**Primary goals:**
1. **Claims anomaly detection** — Catch provider billing irregularities, upcoding, and fraud patterns before they compound
2. **Medical cost forecasting** — Predict next quarter's medical loss ratio with <3% error
3. **Network adequacy analysis** — Ensure provider networks meet state regulatory requirements
4. **Risk adjustment optimization** — Ensure Heartland captures all legitimate risk adjustment revenue

**Success metrics:**
- Fraud/waste/abuse savings (currently $4.2M/year, target $7M)
- Medical cost forecast accuracy (currently ±5.1%, target ±3%)
- Time to detect billing anomalies (currently 45 days, target 7 days)
- Risk adjustment revenue recovered (currently $12M, target $15M)

### Pain Points

**1. Signals is promising but not production-ready**
- False positive rate of 18% means his team investigates 1 in 5 alerts for nothing
- Needs configurable sensitivity thresholds by claim type
- "I can't hire people to chase false positives. Fix the precision."

**2. Scale limitations**
- Heartland processes 8M claims per year
- EVE Explorer slows down on queries over 2M rows
- Needs better performance for large-scale actuarial analyses

**3. Audit trail requirements**
- State insurance regulators require documentation of every analytical decision
- EVE doesn't log query history or version reports
- "If a regulator asks why we flagged this provider, I need to show the exact query and the exact data it ran on"

**4. Actuarial-specific needs**
- IBNR (Incurred But Not Reported) calculations
- Completion factors and development triangles
- These are industry-standard but not in EVE's pre-built library

### Quotes (from user research)

> "Your anomaly detection caught a dermatology practice billing for procedures they couldn't possibly have performed. That one alert saved us $2.3M."

> "I've been doing this for 22 years. I can tell you with certainty: the difference between a $10M problem and a $10K problem is how fast you catch it."

> "I don't need pretty dashboards. I need accurate numbers and a query engine that doesn't choke on 8 million rows."

---

## Customer Stakeholders Map

Beyond the four primary personas, these stakeholders appear across customer organizations and influence buying, adoption, and renewal decisions:

### Decision Makers (who signs the check)

| Role | Cares about | Interaction with EVE |
|---|---|---|
| CEO / President | ROI, competitive advantage, board narrative | Sees EVE data in board presentations (through CMO) |
| CFO | Cost justification, vendor consolidation | Reviews pricing, signs contract, demands financial dashboards |
| CIO / CTO | Security, HIPAA, integration, IT burden | Evaluates technical architecture, approves data access |

### Influencers (who drives adoption)

| Role | Cares about | Interaction with EVE |
|---|---|---|
| VP of Quality | Clinical metrics, regulatory compliance | Primary Insights user, defines KPI requirements |
| Director of Revenue Cycle | Denials, A/R, clean claim rate | Explorer user for financial deep-dives |
| Chief Nursing Officer | Staffing, patient safety, nurse satisfaction | Receives Insights reports, rarely logs in directly |
| Department Heads | Their unit's performance, benchmarking | Receive automated weekly reports from EVE |

### End Users (who logs in daily)

| Role | Cares about | Interaction with EVE |
|---|---|---|
| Clinical Data Analyst | SQL, custom reports, data quality | Explorer power user (like Miguel) |
| Quality Coordinator | Specific quality measures, chart abstraction | Insights viewer, occasional Explorer user |
| Financial Analyst | Revenue metrics, cost accounting | Explorer for ad-hoc financial queries |
| IT/Integration Specialist | Connectors, data pipeline, uptime | Works with Priya's team during implementation |

---

## External Stakeholders

### Insurance & Payer Context

EVE's insurance customers (like Heartland Blue) operate under specific regulatory and business constraints that affect how they use the platform:

**State Insurance Regulators:**
- Require network adequacy reporting, rate filing documentation, and fraud investigation records
- Audit trails and data lineage are not optional — they're legally mandated
- Different states have different requirements (California vs Iowa vs New York)

**CMS (Centers for Medicare & Medicaid Services):**
- Manages Medicare Advantage risk adjustment — worth billions across the industry
- HCC (Hierarchical Condition Category) coding accuracy directly impacts revenue
- Annual CMS audits can recoup millions from insurers with coding errors

**NCQA (National Committee for Quality Assurance):**
- HEDIS measures are the industry standard for health plan quality
- EVE Insights includes 12 pre-built HEDIS dashboards
- NCQA accreditation affects payer reputation and employer contracts

### FDA Context

For digital health customers like Wellspring, FDA is a critical stakeholder:

**Regulatory pathway:**
- 510(k) or de novo classification for SaMD (Software as a Medical Device)
- Requires clinical evidence of safety and effectiveness
- Analytics platform (EVE) is a tool for generating evidence, not a regulated device itself

**What FDA cares about:**
- Data integrity and audit trails
- Statistical rigor in clinical outcome analyses
- Reproducibility of results (same query, same data, same result — every time)
- Pre-specified analysis plans vs post-hoc data mining

**Impact on EVE product:**
- Lisa's use case (FDA submission support) is a growth opportunity
- Requires features EVE doesn't have today: data versioning, locked analysis snapshots, audit logs
- Product team is evaluating a "Regulatory Analytics" add-on for 2027

### HIPAA and Data Privacy

Every EVE customer interaction involves protected health information (PHI):

**EVE's compliance posture:**
- HIPAA BAA (Business Associate Agreement) signed with every customer
- SOC 2 Type II certified (achieved 2024)
- Data encrypted at rest (AES-256) and in transit (TLS 1.3)
- Role-based access control with audit logging
- Annual third-party penetration testing

**What this means for you as an analyst:**
- All data in your datasets is synthetic or de-identified — you're in a simulation
- But in the real EVE, every query is logged and every data access is auditable
- When you design dashboards, think about who should see what (a nurse shouldn't see actuarial pricing data)

---

## Using Personas in Your Work

When analyzing data or building dashboards, always ask:

**"Which persona is this for?"**
- Karen wants the 3 things to worry about — not a 50-row table
- Miguel wants SQL access and statistical rigor — not a simplified summary
- Lisa wants audit trails and reproducibility — not just a pretty chart
- Robert wants speed and accuracy at scale — not a dashboard that chokes on 2M rows

**"What decision does this enable?"**
- Karen: "Should I escalate this quality issue to the board?"
- Miguel: "Is this data anomaly real or an artifact of bad coding?"
- Lisa: "Does our evidence support an FDA submission?"
- Robert: "Should we investigate this provider for potential fraud?"

Tim will ask you these questions. Have answers ready.

---

**These are real people making real decisions that affect real patients. The data you analyze matters.**
