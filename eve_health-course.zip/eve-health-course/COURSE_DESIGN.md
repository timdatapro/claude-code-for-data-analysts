# EVE Health Course — Full Design Document

**Course Author:** Tim Fateev — [LinkedIn](https://www.linkedin.com/in/tim-datapro/)

---

## All Decisions (Finalized)

### Core Parameters

| Parameter | Decision |
|---|---|
| Course name | Claude Code for Data Analysts |
| Company | EVE Health Analytics, Inc. |
| Industry | Healthcare analytics, B2B SaaS |
| Student role | Product Analyst |
| Language | American English |
| Humor style | Warm self-aware |
| Levels | Junior (0–1yr), Middle (1–3yr), Senior (3+yr) |
| Level selection | Module 1.1, stored in CLAUDE.md |
| Level change mid-course | Yes, with warning |
| Tool choice (SQL/Python) | Junior & Middle choose per module; Senior does both |
| SQL execution | sqlite3 database created from CSV at module start |
| Teaching script format | Main CLAUDE.md (narrative) + separate tasks/ files per level |
| Data approach | One master CSV, modules filter themselves |
| Direct manager | Tim Fateev — Head of Data & Analytics |
| License | CC BY 4.0 (Creative Commons Attribution 4.0 International) |

### Tech Stack by Level

| Tool | Junior | Middle | Senior |
|---|---|---|---|
| SQL | SELECT, JOIN, GROUP BY, WHERE | Window functions, CTEs, subqueries | Complex CTEs, optimization, competing metrics |
| pandas | read_csv, groupby, basic filters | pivot_table, merge, method chaining | Multi-index, apply, performance |
| numpy | — | mean, std, percentile | Vectorized ops, statistical tests |
| matplotlib | — | Bar, line, basic styling | Publication-ready, subplots, annotations |
| seaborn | — | Heatmaps, boxplots | Advanced statistical viz |
| dbt | — | — | Models, tests, documentation |

### Module Duration

| Level | Typical | Hard modules |
|---|---|---|
| Junior | 15–30 min | 30 min max |
| Middle | 20–40 min | 45 min max |
| Senior | 30–60 min | 60 min max |

---

## Characters

### Data & Analytics Team (student's team)

| Name | Role | Personality |
|---|---|---|
| **Tim Fateev** | Head of Data & Analytics | Supportive, wise, data-driven. Gives clear context, trusts you to find the answer. Pings at 7:43 AM when something's urgent. |
| **You (student)** | Product Analyst | New hire, all three levels |
| **Marcus Webb** | Senior Data Scientist | Skeptic who demands statistical rigor. Won't accept a finding without a p-value. Dry humor. Respects you if you push back with evidence. |
| **Priya Nair** | Data Engineer | Pragmatic, fast-moving. Cares about pipeline reliability. Will tell you "that query will timeout in prod" without sugarcoating. |
| **Bob Okafor** | BI Engineer | Owns the dashboards. Protective of his Looker models. Happy to collaborate if you come with specs, not vague requests. |
| **Jamie Liu** | Junior Analyst | Eager, asks lots of questions, sometimes over-indexes on small details. Looks up to you even if you're also junior. Good heart. |

### Key Stakeholders

| Name | Role | Personality |
|---|---|---|
| **Alex Rivera** | VP of Product | Fast talker, wants insights yesterday. Appreciates brevity. Will cut you off mid-sentence if you're not getting to the point. |
| **David Park** | CTO | Technical, measured. Wants to see the methodology, not just the result. Asks "how confident are you in this number?" |
| **Rachel Moore** | CEO | Big-picture thinker. Cares about ARR, churn, and board narrative. Doesn't want to see SQL — wants the story. |
| **Nina Patel** | CFO | Numbers person. Will spot a rounding error in your deck from across the room. Respects precision. |

### User Personas (EVE Platform customers — in PERSONAS.md)

| Persona | Role | Context |
|---|---|---|
| **Dr. Karen Walsh** | CMO, Regional Hospital Network | Needs population health dashboards for board reporting |
| **Miguel Santos** | Clinical Data Lead, Academic Medical Center | Power user, builds custom reports, frustrated by EVE Explorer limitations |
| **Lisa Chang** | Digital Health PM, Health Tech Startup | Evaluating EVE for her company, comparing with competitors |
| **Robert Finch** | Actuary, Mid-Size Insurance Provider | Uses EVE Signals for claims anomaly detection, needs audit trail |

Plus: colleagues, stakeholders at customer orgs, insurance companies, FDA context.

### Competitors (4–5 in COMPETITIVE.md)

1. **Health Catalyst** — enterprise, expensive, deep clinical analytics
2. **Arcadia** — population health focus, strong with payers
3. **Tableau for Healthcare** — visualization powerhouse, weak on healthcare-specific workflows
4. **Epic Cogito** — built into Epic EHR, captive audience, limited flexibility
5. **Medidata** — clinical trials focus, different segment but overlapping customers

---

## Data Files

### Master Dataset
`company-context/data/eve_health_support_tickets.csv` — 2,672 customer support tickets, Jul 2025 – Jan 2026. Used across multiple modules.

### Additional Datasets (to be created)

| File | Purpose | Modules |
|---|---|---|
| `data/eve_platform_usage.csv` | User engagement: user_id, customer_id, session_date, module_used, actions_count, session_duration_min | 2.2, 2.4, engagement analysis |
| `data/eve_survey_results.csv` | NPS + product satisfaction survey responses | 2.2 |
| `1.4-*/batch/customers_batch_01.csv` through `_05.csv` | Batches for parallel agent processing | 1.4 |
| `1.3-*/meeting-notes/` | Data team standup + cross-functional sync notes | 1.3 |
| `1.3-*/communication-styles/` | Slack / Email / Notion templates for DA context | 1.3 |
| `2.2-*/interviews/` | User interview transcripts (healthcare professionals) | 2.2 |

---

## File Structure Per Module

```
lesson-modules/1-fundamentals/1.5-investigation/
├── CLAUDE.md                  ← narrative script (Say/Check/Action)
├── tasks/
│   ├── junior-sql.md          ← ready-made queries, guided
│   ├── junior-python.md       ← ready-made pandas code, guided
│   ├── middle-sql.md          ← goal + hints, write it yourself
│   ├── middle-python.md       ← goal + hints, write it yourself
│   └── senior.md              ← both SQL AND Python, hard constraints
└── [supporting data files if needed]
```

CLAUDE.md reads student level from project CLAUDE.md, then branches to the right task file.

---

## Course Plan — Module by Module

---

### BLOCK 1: FUNDAMENTALS (1.1 – 1.10)

---

#### Module 1.1 — First Day at EVE Health

**Time:** 10–15 min (all levels)

**Narrative:**
Your first day at EVE Health. Tim Fateev (Head of Data & Analytics) left you a Slack message: "Welcome to the team! We have a data review with Alex (VP Product) tomorrow at 10 AM. Before then, get familiar with our product, our customers, and the metrics we track. Everything you need is in company-context/. See you tomorrow."

**What happens:**
1. Student reads company-context/ files (COMPANY.md, PRODUCT.md, PERSONAS.md)
2. Meets the team through descriptions (Marcus, Priya, Bob, Jamie)
3. Learns how the course works (slash commands, modules)
4. **Chooses level** — Junior / Middle / Senior → stored in CLAUDE.md
5. Gets introduced to the support tickets CSV as "our main operational dataset"
6. Preview of what's coming

**Humor example:**
"Tim added you to 14 Slack channels. You'll eventually figure out which 3 actually matter."

**Level selection UX:**
```
What best describes your analytics experience?

1. "I'm getting started" — 0–1 year, learning SQL/Python basics
2. "I've been doing this" — 1–3 years, comfortable with analysis
3. "I run the analysis" — 3+ years, I design frameworks and mentor others
```

After selection:
"One more thing — you'll work with both SQL and Python in this course. Some tasks are better suited for SQL, others for Python. Junior and Middle analysts can pick their preferred tool for each task. Senior analysts do both — because that's the job."

**No task files needed** — this module is the same for all levels.

---

#### Module 1.2 — Workspace Setup

**Time:** 10–15 min (all levels)

**Narrative:**
Tim: "Before we get into anything — let's make sure your workspace is set up properly. You'll want to see your files side-by-side with the terminal. Trust me, trying to analyze data without seeing the output is like driving with your eyes closed."

**What happens:**
1. Set up editor (VS Code / Cursor) side-by-side with terminal
2. Navigate the project folder structure
3. Open a CSV in the editor — see the raw data
4. Run a simple command to verify everything works
5. Create the sqlite3 database from CSV (sets up SQL for future modules)

**Level-specific:**
- Junior: More hand-holding on terminal basics, explain what each step does
- Middle: Quick setup, focus on efficiency tips
- Senior: Speed run, mention advanced workspace configs (multiple terminals, tmux)

**Key setup action:**
```bash
sqlite3 eve_health.db < setup.sql
```
This creates the database students will query in SQL modules throughout the course.

---

#### Module 1.3 — The Monday Morning Digest

**Time:** Junior 20 min, Middle 25 min, Senior 35 min

**Narrative:**
Monday, 9:00 AM. Tim's Slack message:

> "Morning! I need the weekly analytics digest by 5 PM today. Here's what I need:
> 1. Summary of last week's team discussions (meeting notes are in the folder)
> 2. Key takeaways from the customer feedback data
> 3. Three versions: executive email for Rachel, Slack post for the team, Notion doc for the archive
> 4. Review the EVE Insights dashboard screenshot before the redesign meeting — does it tell the right story?
> 5. Find industry benchmarks for healthcare SaaS support response times
>
> Five items, nine hours. You've got this."

**Skills taught:**
1. @ file references — read meeting notes
2. Folder analysis — synthesize multiple files
3. Content transformation — same data, three audiences (Slack / Email / Notion)
4. Image analysis — dashboard screenshot review
5. Web search — industry benchmarks

**Supporting files needed:**
- `meeting-notes/data-team-standup.md` — weekly standup notes (messy, realistic)
- `meeting-notes/cross-functional-sync.md` — sync with Product + Engineering
- `meeting-notes/customer-escalation-review.md` — support escalation patterns
- `communication-styles/style-slack-update.md`
- `communication-styles/style-executive-email.md`
- `communication-styles/style-notion-doc.md`

**Task files:**

*Junior (SQL & Python same task):*
- Guided step-by-step: "First, let's read the meeting notes. Type: analyze @meeting-notes/"
- Structured prompts for each transformation
- Dashboard review: "What metrics do you see? What's missing?"

*Middle:*
- Less scaffolding: "Tim needs the digest. Meeting notes are in @meeting-notes/. You know the three formats. Go."
- Dashboard review: "Tim wants your opinion before the redesign meeting. What works, what doesn't?"

*Senior:*
- Minimal: "Digest. Five items. 5 PM. Meeting notes, customer data, three formats, dashboard review, benchmarks. You know what Tim expects."
- Dashboard review: "Write a one-page dashboard redesign recommendation with data hierarchy rationale"

**Humor:**
"Three versions of the same update for three different audiences. If you've ever wondered why analysts spend half their time 'communicating' — this is why."

---

#### Module 1.4 — Parallel Agents: Batch Processing

**Time:** Junior 15 min, Middle 25 min, Senior 40 min

**Narrative:**
Tim: "We just signed 5 new hospital network clients last month. Each sent us their historical support data for migration. I need a quality report for each — data completeness, anomalies, red flags. Marcus (DS) is busy with the churn model. Can you process all 5 in parallel?"

**Skills taught:**
- Running multiple Claude Code agents simultaneously
- Batch processing pattern
- Standardized output across parallel tasks

**Supporting files:**
- `batch/memorial_health_data.csv`
- `batch/bluecross_data.csv`
- `batch/mercy_hospital_data.csv`
- `batch/anthem_data.csv`
- `batch/kaiser_data.csv`

Each file: ~200 rows, slightly different schemas, some with quality issues (nulls, duplicates, date format inconsistencies).

**Task files:**

*Junior (SQL or Python):*
- SQL: Ready-made quality check queries, run on each file, compare results
- Python: Ready-made pandas profiling script, run on each file
- Learn the mechanic of parallel agents

*Middle (SQL or Python):*
- SQL: Write your own quality check queries, design the output format
- Python: Write a data profiling function, apply to all 5
- Identify which client's data needs the most cleanup

*Senior (both):*
- SQL: Design a data quality scoring framework (completeness, consistency, timeliness scores)
- Python: Build an automated report generator that outputs one summary per client + a comparative overview
- Write a memo to Tim recommending migration priority order based on data readiness

---

#### Module 1.5 — AI Team: Metric Spike Investigation

**Time:** Junior 20 min, Middle 30 min, Senior 50 min

**Narrative:**
Tim pings you at 7:43 AM (nothing good ever starts with a 7:43 AM ping):

> "Critical SLA breach rate jumped from 60% to 90% last month. Alex (VP Product) is asking questions. I need a root cause analysis by end of day. Use whatever tools you need — pull in Marcus for stats validation if needed."

**Skills taught:**
- Sub-agents with different roles (data-scientist, engineer, PM perspectives)
- Multi-perspective analysis
- Structured investigation methodology

**Agent roles in this module:**
- **Data Scientist agent (Marcus):** "Is this statistically significant or just variance? Run the test."
- **Engineer agent (Priya):** "Could this be a data collection issue? Check the pipeline logs."
- **Product Manager agent (Alex):** "What's the customer impact? Which accounts are affected?"

**Task files:**

*Junior (SQL or Python):*
- SQL: Guided queries — "First, let's check the trend by month. Run this query..."
- Python: Guided pandas code — groupby month, plot the trend
- Sub-agents are introduced as "let me check with Marcus on this"

*Middle (SQL or Python):*
- SQL: "Write a query to break down SLA breach by category, priority, and agent. Find the driver."
- Python: "Segment the data. Which dimension explains the spike? Build a visualization."
- Actively use sub-agents: ask Marcus to validate, ask Priya about pipeline

*Senior (both required):*
- SQL: "Write competing queries — one that supports 'agents are overloaded' and one that supports 'SLA targets are wrong.' Which story is true?"
- Python: "Run a chi-square test on breach rates across categories. Build a decomposition waterfall chart."
- Coordinate all three sub-agents, synthesize into a memo for Tim
- "Tim doesn't want a hunch. He wants proof."

**Data source:** `eve_health_support_tickets.csv` — filter and analyze

---

#### Module 1.6 — Memory & CLAUDE.md Handoff

**Time:** Junior 15 min, Middle 20 min, Senior 30 min

**Narrative:**
Tim: "Great work on the SLA investigation. Two things: First, I want you to document what you found so anyone can pick this up. Second — I'm assigning follow-up tasks based on this analysis."

**Skills taught:**
- CLAUDE.md as project memory
- Context handoff between team members
- Documentation for reproducibility

**Level-specific scenarios:**

*Junior & Middle:*
Handoff to Jamie (Junior Analyst). She'll run the weekly SLA monitoring report going forward. Write a CLAUDE.md that gives her everything she needs: what to look at, what queries to run, what "normal" looks like, when to escalate to Tim.

*Senior:*
Two handoffs:
1. To Jamie — weekly monitoring (same as above)
2. To Marcus (Senior DS) — you found a pattern that needs statistical modeling. Hand off the analysis context, your hypotheses, the data subset, and what you'd test if you had more time.

Write a CLAUDE.md that a different Claude Code instance could pick up and continue your work without any additional context.

**Humor:**
"Writing good documentation is like flossing — everyone knows they should do it, nobody wants to, and you'll regret skipping it exactly once."

---

#### Module 1.7 — Crisis: Pipeline Broke Before Board Meeting

**Time:** Junior 20 min, Middle 30 min, Senior 45 min

**Narrative:**
Thursday, 4:47 PM. Tim's Slack (marked urgent 🔴):

> "Data pipeline broke. The board meeting dashboard is showing last week's numbers. Rachel (CEO) presents in 36 hours. I need you to:
> 1. Figure out what's wrong with the data
> 2. Build a manual workaround so Rachel has accurate numbers
> 3. Write a post-mortem draft
>
> Priya (Data Engineer) is debugging the pipeline itself. You handle the analytics side."

**Skills taught:**
- Working under pressure with incomplete data
- Manual data validation and workarounds
- Post-mortem writing
- Cross-functional communication during crisis

**Supporting files:**
- `crisis/dashboard-snapshot-broken.md` — what the dashboard currently shows (wrong numbers)
- `crisis/last-known-good-data.csv` — last reliable data export
- `crisis/board-deck-template.md` — what Rachel needs filled in
- `crisis/priya-slack-thread.md` — Priya's debugging updates (pipeline context)

**Task files:**

*Junior (SQL or Python):*
- SQL: "Here's a query that pulls the key board metrics. Run it on the last known good data and compare with the dashboard numbers. Which ones are wrong?"
- Python: "Load the last known good export. Calculate these 5 metrics. Compare with the dashboard snapshot."
- Guided through each step, reassurance that pressure is normal

*Middle (SQL or Python):*
- SQL: "Rebuild the 4 key board metrics from raw data. Find the discrepancies. Fix them."
- Python: "Write a script that independently calculates all board metrics and flags any that differ from the dashboard by >5%."
- Write a Slack update to Tim with findings

*Senior (both required):*
- SQL: "Rebuild board metrics AND identify the exact breakpoint — which records are stale?"
- Python: "Build a data validation script that can run as a daily check going forward. Plot the data freshness timeline."
- Write the full post-mortem: timeline, root cause, impact, remediation, prevention
- "If this doesn't make you want to build automated data quality checks, nothing will."

**Humor:**
"The pipeline broke 36 hours before the board meeting. If you're thinking 'that's not enough time' — congratulations, you now understand the job."

---

#### Module 1.8 — Skills: Excel Reports + Slide Decks

**Time:** Junior 20 min, Middle 30 min, Senior 40 min

**Narrative:**
Tim: "Nina (CFO) asked for two things by Friday: an Excel report with support metrics broken down by customer type, and a 5-slide deck for the ops review. She's very particular about formatting. Don't ask me how I know."

**Skills taught:**
- Claude Code skills system (pptx, xlsx, pdf)
- Generating professional Excel reports with formulas and charts
- Building slide decks from data
- Formatting for executive audiences

**Task files:**

*Junior (SQL or Python):*
- SQL: Query the metrics, Claude builds the Excel report. Student reviews and adjusts.
- Python: pandas to calculate, openpyxl to format. Guided through the process.
- Simple 3-slide deck

*Middle (SQL or Python):*
- SQL: Design the report structure — which metrics, which breakdowns, which time periods?
- Python: Build a matplotlib chart suite, then package into xlsx + pptx
- 5-slide deck with charts and commentary

*Senior (both required):*
- SQL: Build a dynamic Excel model with formulas (not hardcoded values) that Nina can update herself
- Python: Automated report generation script — runs weekly, outputs xlsx + pptx
- "Nina will spot a rounding error from across the room. Triple-check your numbers."

---

#### Module 1.9 — Competitive Benchmarking

**Time:** Junior 15 min, Middle 25 min, Senior 35 min

**Narrative:**
Alex (VP Product): "We're presenting our competitive positioning at the all-hands next week. I need a benchmarking analysis: how does EVE Health compare to Health Catalyst, Arcadia, and the others on product capabilities, pricing, and market positioning? Tim said you could handle this."

**Skills taught:**
- Web search for competitive intelligence
- Structuring competitive analysis
- Product analytics benchmarking

**Task files:**

*Junior:*
- Guided: "Search for Health Catalyst pricing. Now search for Arcadia features. Let's build a comparison table."
- Fill in a pre-made template

*Middle:*
- "Build a competitive matrix: features, pricing, target market, strengths, weaknesses. Use web search. Deliver as a formatted markdown doc."

*Senior:*
- Full competitive analysis with strategic recommendations
- "Where should EVE Health invest to differentiate? What gaps in the market are underserved?"
- Include quantitative benchmarks where available (NPS, market share, ARR estimates)

---

#### Module 1.10 — Build Your Own Analysis Skill

**Time:** Junior 20 min, Middle 30 min, Senior 45 min

**Narrative:**
Tim: "You've been here a few weeks now. I want you to build something that makes your own life easier. Think about the repetitive tasks you've done — what would you automate?"

**Skills taught:**
- Custom Claude Code skill creation
- Turning repetitive analysis into reusable automation
- Thinking like a tool builder, not just a tool user

**Task files:**

*Junior (SQL or Python):*
- SQL: "Data Quality Checker" — skill that accepts a table name, runs standard checks (nulls, duplicates, value ranges), outputs a report
- Python: Same skill but with pandas profiling

*Middle (SQL or Python):*
- SQL: "Weekly Metrics Digest Generator" — skill that queries the DB, calculates KPIs, compares to targets, outputs a formatted summary
- Python: Same but with matplotlib charts included

*Senior (both required):*
- "Anomaly Investigation Framework" — skill that accepts a metric name and time period, automatically segments by all dimensions, finds the biggest driver, generates a memo with findings
- SQL for the investigation queries, Python for statistical validation and visualization
- Must be documented well enough for Jamie to use it

**Humor:**
"Every great analyst eventually realizes: the best analysis is the one you only have to build once."

---

### BLOCK 2: CORE DA WORK (2.1 – 2.4)

---

#### Module 2.1 — Analysis Brief: Frame the Question

**Time:** Junior 20 min, Middle 30 min, Senior 45 min

**Narrative:**
Tim: "Alex wants to know why EVE Explorer adoption is stuck at 41% when the target is 65%. Before you touch any data — I want an analysis brief. What's the question? What data do you need? What would change our decision? Frame the problem first."

**Skills taught:**
- Analysis brief methodology (question → hypothesis → data → decision)
- Avoiding "just look at the data" trap
- Stakeholder alignment before analysis

**Task files:**

*Junior (SQL or Python):*
- SQL: Guided exploration — "Let's look at adoption by customer type first. Write a query..."
- Python: Same with pandas
- Analysis brief template provided, fill in the blanks

*Middle (SQL or Python):*
- SQL: "Write the queries you'd need to test three hypotheses about low adoption"
- Python: "Build an EDA notebook that explores adoption patterns"
- Write the analysis brief from scratch

*Senior (both required):*
- SQL: "Design a measurement framework — how would you even define 'adoption' for Explorer? DAU? Feature usage depth? Time-to-value?"
- Python: "Prototype three different adoption metrics and show how each tells a different story"
- Write an analysis brief that Tim would approve AND present to Alex
- "The most dangerous analyst is one who answers the wrong question precisely."

---

#### Module 2.2 — Data Analysis: Surveys + Usage + Interviews

**Time:** Junior 25 min, Middle 40 min, Senior 60 min

**Narrative:**
Tim: "The adoption analysis surfaced some patterns, but we need the full picture. I've got three data sources for you:
1. NPS survey responses from last quarter (CSV)
2. Product usage data — session logs (CSV)
3. Three user interview transcripts from healthcare professionals

Synthesize everything. What's the real story behind Explorer adoption?"

**Skills taught:**
- Multi-source data synthesis (quantitative + qualitative)
- Survey analysis
- Usage data patterns
- Interview coding and theme extraction
- Triangulation — when sources agree and disagree

**Supporting files:**
- `data/eve_survey_results.csv` — NPS + satisfaction scores
- `data/eve_platform_usage.csv` — session-level usage logs
- `interviews/clinical-data-lead.md` — Miguel Santos interview
- `interviews/hospital-cmo.md` — Dr. Karen Walsh interview
- `interviews/insurance-actuary.md` — Robert Finch interview

**Task files:**

*Junior (SQL or Python):*
- SQL: Guided queries on survey data — "What's the average NPS by customer type?"
- Python: Guided pandas analysis — groupby, describe, basic visualization
- Read interviews, identify top 3 themes (with prompts)

*Middle (SQL or Python):*
- SQL: "Join survey responses with usage data. Is there a correlation between NPS and feature usage depth?"
- Python: "Run a correlation analysis between NPS, session frequency, and feature adoption. Build a visualization matrix."
- Synthesize all three sources into an insights memo

*Senior (both required):*
- SQL: "Build a user segmentation — cluster users by behavior and cross-reference with satisfaction"
- Python: "Run statistical tests: is the NPS difference between Explorer users and non-users significant? Build regression model of adoption drivers."
- Full synthesis report: quantitative findings + qualitative validation + recommendations
- "Three data sources telling three stories. Your job is to find the one story that's actually true."

---

#### Module 2.3 — Insights Deck: Present to Leadership

**Time:** Junior 20 min, Middle 35 min, Senior 50 min

**Narrative:**
Tim: "Rachel (CEO) has 15 minutes at the leadership offsite for the Explorer adoption story. Alex will present, but we build the deck. Seven slides max. Rachel hates bullet points — she wants charts that speak for themselves and a clear recommendation."

**Skills taught:**
- Data storytelling for executives
- Chart selection for impact (not just accuracy)
- Recommendation framing — what to do, not just what happened
- Slide deck building with Claude Code

**Task files:**

*Junior:*
- Template provided: title, problem, data, insight, recommendation, next steps
- Build 3–4 simple charts in matplotlib
- Fill in the narrative with guidance

*Middle:*
- Design the story arc: "What does Rachel need to believe by slide 7?"
- Build 5 publication-ready charts
- Write speaker notes for Alex

*Senior:*
- Full 7-slide deck with no template
- "Devil's advocate" exercise — build the strongest counterargument to your own recommendation
- Include an appendix with methodology for David (CTO) who will ask "how did you get this number?"
- "Rachel doesn't want to see SQL. She wants the story. David wants to see the SQL. Build for both."

---

#### Module 2.4 — Dashboard Spec + Prototype

**Time:** Junior 25 min, Middle 40 min, Senior 60 min

**Narrative:**
Tim: "Bob (BI Engineer) is rebuilding the EVE Insights dashboard from scratch. He needs a spec from us: which metrics, which filters, which views, which drill-downs. And Rachel wants a prototype visual before she signs off. This is our chance to get it right."

**Skills taught:**
- Dashboard specification writing
- Metric hierarchy design
- Visual prototyping with matplotlib
- Stakeholder requirements gathering

**Supporting files:**
- `dashboard-example.md` — example dashboard spec from HANDOFF
- `eve_health_support_tickets.csv` — main data source
- `eve_platform_usage.csv` — usage data source

**Task files:**

*Junior (SQL or Python):*
- SQL: "Query the top 5 metrics Bob needs. What filters make sense?"
- Python: "Build 3 matplotlib charts that could be dashboard panels"
- Fill in a dashboard spec template

*Middle (SQL or Python):*
- SQL: "Design the SQL views that would power each dashboard panel"
- Python: "Build a complete matplotlib dashboard mockup — 6 panels, one figure"
- Write the spec: metrics, dimensions, filters, interactions, user stories

*Senior (both required):*
- SQL: "Design the data model — which tables, which aggregations, which materialized views?"
- Python: "Build an interactive prototype (matplotlib + widgets or HTML)"
- Full spec + prototype + data freshness requirements + alerting thresholds
- dbt: "Sketch the dbt model lineage for this dashboard"
- "Bob is protective of his Looker models. Come with specs, not opinions."

---

### BLOCK 3: VISUAL CONTENT (3.1 – 3.2)

**Adapted from:** Original Block 3 (Visual Content / Gemini image gen)
**Two tracks:** Student chooses at block start — **Track A: Advanced Data Visualization** (matplotlib, seaborn, automated reports) or **Track B: AI Image Generation** (Gemini API). Senior does both.

**Requirements:** Track B requires Python 3 + Gemini API key (free tier).

---

#### Module 3.1 — Track A: Advanced Visualization Techniques / Track B: Intro to Image Generation

**Time:** Junior 25 min, Middle 40 min, Senior 60 min

**Track A — Advanced Data Visualization:**

**Narrative:**
Tim: "Alex wants us to level up our visual game. The current charts look like they were made in Excel 2003. He showed me what Health Catalyst puts in their reports — we need to match that quality. Time to learn some advanced viz techniques."

**Sub-modules:**

**3.1.1 — Chart Selection Framework**
When to use what: bar vs line vs scatter vs heatmap vs box. Decision tree for chart types based on data relationship (comparison, distribution, composition, relationship).

**3.1.2 — Publication-Ready Charts**
matplotlib styling: custom color palettes, typography, annotations, removing chartjunk. "Before and after" transformations of ugly charts.

**3.1.3 — Statistical Visualizations**
seaborn: heatmaps, pair plots, violin plots, regression plots. When statistical viz adds insight vs when it's showing off.

**3.1.4 — Dashboard Layouts**
Multi-panel figures, consistent styling, responsive design. Building a "chart library" for EVE Health with reusable style settings.

**Track B — AI Image Generation:**

**Narrative:**
Tim: "Marketing asked if we can help generate visuals for the EVE Health blog and sales materials. Turns out Claude Code + Gemini API can do this. Let's explore."

**Sub-modules (mirror original 3.1.x):**

**3.1.1 — Welcome to Image Gen**
Setup Gemini API, first generated image. Healthcare context: generate a hero image for EVE Health landing page.

**3.1.2 — Prompt Engineering for Images**
Basics of effective prompts. Generate visuals for: dashboard screenshots, team photos, healthcare settings.

**3.1.3 — Style Control**
Style references, consistency across images. Build a visual style guide for EVE Health marketing.

**3.1.4 — Style Library**
Reusable style database. Generate a set of consistent visuals for a sales deck.

---

#### Module 3.2 — Track A: DA Visualization Use Cases / Track B: DA Image Gen Use Cases

**Track A — DA Visualization Use Cases:**

**Sub-modules:**

**3.2.1 — Operational Analytics**
SLA performance heatmap, agent workload distribution, ticket volume trends. Real charts from eve_health_support_tickets.csv.

**3.2.2 — Strategic Visualization**
Funnel analysis charts, cohort retention curves, competitive positioning maps. Charts for board decks and strategy docs.

**3.2.3 — Automated Reporting**
Build a Python script that generates a weekly PDF report with charts, metrics, and commentary. Run it once, reuse forever.

**Track B — DA Image Gen Use Cases:**

**Sub-modules (mirror original 3.2.x):**

**3.2.1 — Product & User Visuals**
Generate user persona illustrations, product screenshots for docs, onboarding flow visuals.

**3.2.2 — Strategy & Architecture**
Generate architecture diagrams, data flow visuals, system maps for EVE Platform.

**3.2.3 — Marketing Materials**
Generate social media graphics, blog hero images, case study visuals for EVE Health.

**Senior requirement:** Complete both Track A and Track B.

---

### BLOCK 4: BUILD A PRODUCT (4.1 – 4.5)

**Build project:** EVE Health ROI Calculator
A web tool where prospects input their metrics (ticket volume, resolution time, FTEs) and get an estimated ROI from implementing EVE Platform.

---

#### Module 4.1 — Setup (Node.js, GitHub)

**Time:** 15 min (all levels)

**Narrative:**
Tim: "Sales team asked for a tool prospects can use to estimate their ROI from EVE. Alex loves the idea. David said we can build it as a simple web app. You're leading this — design and build it with Claude Code."

**What happens:**
- Install Node.js, set up GitHub repo
- Create project structure
- Same mechanic as original — tech setup

---

#### Module 4.2 — Plan the ROI Calculator

**Time:** Junior 15 min, Middle 25 min, Senior 40 min

**Task files:**

*Junior:*
- Pre-defined requirements: 5 input fields, 3 output metrics, simple formula
- Claude walks through the spec

*Middle:*
- Define requirements yourself: what inputs, what calculations, what output format
- Design the user flow

*Senior:*
- Full product spec: user personas for the calculator, edge cases, data validation
- Competitive research: what do Health Catalyst / Arcadia's ROI tools look like?
- "Build the business case for why this calculator will generate leads"

---

#### Module 4.3 — Build & Iterate

**Time:** Junior 30 min, Middle 45 min, Senior 60 min

Same mechanic as original — build with Claude Code, iterate on feedback.

Level differences in complexity of the calculator:
- Junior: Simple static calculator
- Middle: Dynamic with charts showing projections
- Senior: Full interactive tool with scenario comparison, PDF export, and input validation

---

#### Module 4.4 — GitHub Versioning

**Time:** 15–20 min (all levels)
Same mechanic as original — commit, push, branching basics.

---

#### Module 4.5 — Deploy to Vercel

**Time:** 15–20 min (all levels)
Same mechanic as original — deploy, get a live URL, share it.

---

### BLOCK 5: WHAT'S NEXT (5.1 – 5.2)

---

#### Module 5.1 — MCP Integrations for Analysts

**Time:** 20 min (all levels)

Connect Claude Code to real data sources:
- Google Sheets (live dashboards)
- Notion (documentation)
- Jira / Linear (ticket tracking)
- Database connections

Demo how MCP turns Claude Code from "analyze this file" to "analyze our live data."

---

#### Module 5.2 — Rolling Out Claude Code to Your Analytics Team

**Time:** 20 min (all levels)

**Narrative:**
Tim: "I've seen what you've built over these weeks. I want to roll Claude Code out to the whole analytics team. Help me build the case and the playbook."

**What happens:**
- Build an internal adoption plan
- Create a CLAUDE.md template for the team
- Design a "starter kit" for Jamie and other analysts
- ROI calculation: time saved across the team
- Present to Tim as a proposal

**Humor:**
"Congratulations. You've gone from 'what is Claude Code' to 'how do I get my whole team on this.' That's the real graduation moment."

**Course closing message (shown at end of 5.2):**

"You've completed Claude Code for Data Analysts.

You started as a new hire who didn't know where the CSV was. You're leaving as someone who can investigate metric spikes, build dashboards, automate reports, deploy products, and — most importantly — ask the right questions before touching the data.

Everything you built is real. The skills, the scripts, the frameworks — take them to your actual job.

This course was created by **Tim Fateev**. Connect on LinkedIn: https://www.linkedin.com/in/tim-datapro/

Now go make your data team wonder how you got so fast."

---

## Course Author Attribution

**Shown in two places:**
1. **Module 1.1 intro** — "This course was created by Tim Fateev ([LinkedIn](https://www.linkedin.com/in/tim-datapro/))"
2. **Module 5.2 closing** — full closing message with LinkedIn link (see above)
3. **README.md** — author credit with LinkedIn link

---

## Open Items / Notes

- TESTING.md checklist — create after all modules are written
- README.md — create last, once final structure is locked
- .gitignore — standard Python + Node.js ignores + .env
- Block 3 Track B requires Gemini API key (free tier) — instructions in module 3.1.1
