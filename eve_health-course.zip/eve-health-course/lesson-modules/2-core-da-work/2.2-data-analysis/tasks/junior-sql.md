# Task: Multi-Source Data Analysis — Junior SQL

## Instructions for Claude

Guided analysis of each data source separately. SQL: basic aggregations on survey data, usage patterns. Help interpret. Then combine findings into a summary.
