# Module 1.4: Parallel Agents — Batch Processing

**Teaching script for Claude Code**

> **Before starting:** Read `.claude/SCRIPT_INSTRUCTIONS.md` and project CLAUDE.md for ANALYST_LEVEL.

---

## Your Role

You're leading Module 1.4. Tim needs 5 new hospital client datasets quality-checked simultaneously. This module teaches parallel Claude Code agents through a real batch processing scenario.

---

## Learning Objectives
1. Run multiple Claude Code agents in parallel
2. Understand batch processing patterns
3. Standardize output across parallel tasks
4. Know when parallel work saves time vs adds complexity

---

## Lesson Flow

### Step 1: Tim's Request (2 min)

**Say:**

"Module 1.4 — Parallel Agents.

Tim's message:

---

*'We signed 5 new hospital network clients last month. Each sent their historical data for migration into EVE. I need a data quality report for each — completeness, anomalies, red flags. Marcus is swamped with the churn model. Can you process all 5 in parallel?*

*The batch files are in the lesson folder. Five datasets, five reports, by end of day.*

*— Tim'*

---

Five datasets. Doing them one by one: 2.5 hours. In parallel: 30 minutes. Let me show you how.

Say: **'Show me'**"

**Check:** Wait for student

---

### Step 2: Understanding the Data (3 min)

**Action:** List the batch files:
```bash
ls lesson-modules/1-fundamentals/1.4-parallel-work/batch/
```

**Say:**

"Five CSV files — one per hospital. Each has similar structure but different data quality issues:
- Some have missing fields
- Some have date format inconsistencies
- Some have duplicate records
- Some have values outside expected ranges

Open one in your editor — see the raw data. Don't read them all — that's what parallel agents are for.

Say: **'I see the files'**"

**Check:** Wait

---

### Step 3: Running Parallel Agents (10 min)

**Say:**

"Here's the key concept: **you can run multiple Claude Code instances simultaneously.**

In practice, you'd open 5 terminal tabs and run Claude in each. For this exercise, I'll show you the pattern and process them in sequence — but in real work, this runs in parallel.

**The pattern:**
1. Write a standardized prompt (the same for each dataset)
2. Run it against each file
3. Collect standardized outputs

Let me demonstrate with the first file, then you'll process the rest."

**Branch by level:**

#### [JUNIOR]
**Action:** AskUserQuestion "SQL or Python?"
Then read corresponding task file from `tasks/`.

#### [MIDDLE]
**Action:** AskUserQuestion "SQL or Python?"
Then read corresponding task file from `tasks/`.

#### [SENIOR]
Read `tasks/senior.md`.

---

### Step 4: Comparing Results (5 min)

**After all 5 files processed, say:**

"All five reports done. Now the real value: comparison.

Which client's data is cleanest? Which needs the most cleanup before migration? This is exactly what Tim needs to prioritize the migration order."

**Action:** Create a comparison summary table showing all 5 clients ranked by data quality score.

---

### Step 5: Wrap-Up (2 min)

**Say:**

"Here's what happened:
- ✅ Processed 5 datasets with standardized quality checks
- ✅ Generated 5 individual reports + 1 comparison summary
- ✅ Identified migration priority order

**Key technique:** Write the prompt once, run it N times. Parallel agents = multiplicative time savings.

**Time saved:** 2.5 hours → 30 minutes (and with real parallel execution, even faster)

**What's next: Module 1.5 — Metric Spike Investigation**

Tim pinged at 7:43 AM. Critical SLA breach jumped from 60% to 90%. You're investigating why — with help from sub-agents who bring different perspectives (data scientist, engineer, product).

When you're ready: `/start-1-5`"

---

## Success Criteria
- ✅ Understands parallel agent concept
- ✅ Can write standardized prompts for batch processing
- ✅ Produced quality reports for all 5 datasets
- ✅ Created comparison summary
