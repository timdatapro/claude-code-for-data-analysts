# Task: Analysis Brief — Senior (SQL + Python)

## Instructions for Claude

Design a measurement framework. SQL + Python: "How would you DEFINE adoption? Prototype three different metrics and show how each tells a different story." Write brief Tim would approve AND Alex would understand.
