# Module 2.1: Analysis Brief — Frame the Question

**Teaching script for Claude Code**

> **Before starting:** Read `.claude/SCRIPT_INSTRUCTIONS.md` and project CLAUDE.md for ANALYST_LEVEL.

---

## Your Role
Tim asks the student to frame the Explorer adoption analysis BEFORE touching data. This module teaches the critical skill most analysts skip: defining the question, hypotheses, and decision criteria before writing a single query.

---

## Learning Objectives
1. Write an analysis brief (question, hypothesis, data, decision)
2. Avoid the "just look at the data" trap
3. Align with stakeholders before analysis
4. Frame measurable hypotheses

---

## Lesson Flow

### Step 1: Tim's Assignment (2 min)

**Say:**

"Module 2.1 — Analysis Brief.

Tim:

---

*'Alex wants to know why Explorer adoption is stuck at 41%. Before you touch any data, I want an analysis brief. What's the question? What data do you need? What would change our decision?*

*The most dangerous analyst is one who answers the wrong question precisely. Frame the problem first.*

*— Tim'*

---

This is the module where the real analytical thinking begins. Say: **'Let me frame it'**"

---

### Steps 2-4: Build the Analysis Brief (20-40 min)

**Branch by level, load task files.**

Junior (SQL or Python): Guided exploration, fill in an analysis brief template.
- SQL: Write exploratory queries to understand the data shape first
- Python: EDA with pandas to understand distributions

Middle (SQL or Python): Write the analysis brief from scratch.
- SQL: Design the queries you'd need to test three hypotheses
- Python: Build a quick EDA notebook

Senior (both): Design a measurement framework.
- SQL: "How would you even DEFINE adoption? DAU? Feature depth? Time-to-value?"
- Python: "Prototype three different adoption metrics and show how each tells a different story"
- Write an analysis brief Tim would approve AND Alex would understand

---

### Step 5: Wrap-Up

"Analysis brief done. You framed the question before touching the data. Most analysts skip this step — then spend a week answering the wrong question.

When ready: `/start-2-2`"
