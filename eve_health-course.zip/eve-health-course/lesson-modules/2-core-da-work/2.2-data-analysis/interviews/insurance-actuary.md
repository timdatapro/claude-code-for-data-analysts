# User Interview: Robert Finch — VP Actuarial Analytics, Heartland Blue
**Date:** November 3, 2025
**Interviewer:** Product Research Team
**Duration:** 40 minutes

---

**Q: What's your primary use case for EVE?**

Robert: Claims anomaly detection. We process 8 million claims a year. Finding the needle in that haystack — the billing irregularities, the upcoding patterns, the fraud signals — that's what EVE Signals does for us. Before EVE, we'd discover these problems 45 days after the fact. Now we're catching them in under a week.

**Q: How much value has Signals generated?**

Robert: $4.2 million in avoided fraud and waste last year, directly attributable to Signals alerts. And that's conservative — I only count cases where we can prove the alert led to the recovery. The real number is probably higher.

**Q: What's your biggest frustration?**

Robert: False positives. 18% of alerts lead nowhere. That's 1 in 5. I have a team of 12 actuaries — I can't have them spending 20% of their investigation time on noise. I told Tim: fix the precision or I'll turn it off. I mean it.

The second issue is scale. Explorer chokes on queries over 2 million rows. Our claims table is 8 million. I can't use Explorer at all for ad-hoc claims analysis — I have to export to SAS or Python. For $144K a year, I expect the tool to handle my data volume.

**Q: Do you use Insights dashboards?**

Robert: Rarely. The pre-built healthcare dashboards are designed for hospitals, not insurers. I need IBNR calculations, completion factors, development triangles — standard actuarial stuff that EVE doesn't have. My team built our own dashboards in Looker for that. EVE is strictly a Signals + occasional Explorer tool for us.

**Q: What would increase your usage?**

Robert: Three things. First, bring the false positive rate under 10%. Second, let me set custom sensitivity thresholds by claim type — a $50 dental claim and a $50,000 cardiac surgery shouldn't trigger at the same deviation threshold. Third, give me an audit trail. State regulators need to see exactly what query I ran, on what data, on what date. Right now I can't prove that.

**Q: Would you renew?**

Robert: Yes, but only because of Signals. If Signals didn't exist, we'd cancel tomorrow. The $4.2M in savings justifies the cost 30x over. But they need to fix the precision issue before GA or they'll lose customers who have less patience than I do.
