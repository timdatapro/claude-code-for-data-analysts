# Task: Pipeline Crisis Workaround — Junior SQL

## Instructions for Claude

Provide ready-made SQL code to recalculate the 4 key board metrics from the CSV. Walk through each metric: "This query pulls total tickets resolved this month. Run it and compare with the dashboard number. Are they different?"
