# Task: Dashboard Spec + Prototype — Senior (SQL + Python)

## Instructions for Claude

SQL: design data model — tables, aggregations, materialized views. Python: build interactive prototype. dbt: sketch model lineage. Full spec + alerting thresholds. "Bob is protective of his Looker models. Come with specs, not opinions."
