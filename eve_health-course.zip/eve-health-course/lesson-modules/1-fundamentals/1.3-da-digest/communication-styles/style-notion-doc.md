# Communication Style: Notion Document

## When to use
Weekly digest archive, analysis documentation, project context, knowledge base entries.

## Format rules
- Clear title with date
- Table of contents (headers)
- Structured sections with H2/H3 headers
- Data tables where appropriate
- Include methodology notes (how was this calculated?)
- Link to source data and related docs
- Total length: 400-800 words

## Tone
- Thorough and objective
- Written for future readers who weren't in the room
- Include context that would be obvious today but forgotten in 3 months
- "The analysis showed..." not "I think..."
- Neutral — present findings, let the reader draw conclusions

## Example

# Weekly Analytics Digest — Jan 13-17, 2026

## Summary
This week's focus: support SLA performance, Snowflake migration progress, and Explorer adoption patterns. Three critical customer escalations required direct intervention.

## Key Metrics

| Metric | This Week | Last Week | Target | Status |
|--------|-----------|-----------|--------|--------|
| Total tickets | 142 | 128 | — | ↑ 11% |
| Critical SLA compliance | 10% | 12% | 70% | 🔴 |
| High SLA compliance | 47% | 45% | 70% | 🟡 |
| FCR rate | 58% | 56% | 60% | 🟡 |
| Mean resolution (hours) | 18.2 | 19.1 | varies | ↓ improving |

## Notable Events

### Customer Escalations
Three critical escalations occurred this week. See Customer Escalation Review (Jan 13) for full details. Pattern: connector issues during onboarding and Signals false positives continue to drive escalations.

### Snowflake Migration
Priya reports 80% completion. Staging tables migrated. Production models estimated 3 additional days. Timezone bug in Airflow DAG caused ~6 hours of data loss on Jan 8 (resolved).

### Explorer Adoption
Jamie identified inconsistencies in "active user" definition across tables. Documenting for Priya by Wednesday. This may affect previously reported adoption numbers.

## Action Items

| Action | Owner | Due | Status |
|--------|-------|-----|--------|
| Validate churn risk model | Marcus | Jan 24 | In progress |
| Complete Snowflake migration | Priya | Jan 16 | In progress |
| CFO financial dashboard | Bob | Jan 17 | In progress |
| Document active user definitions | Jamie | Jan 15 | New |
| SLA root cause analysis | New analyst | Jan 28 | Not started |

## Methodology
Ticket metrics pulled from `eve_health_support_tickets.csv` filtered for the reporting week (Jan 13-17). SLA compliance calculated as percentage of tickets resolved within `sla_target_hours` for each priority level.

---
*Source data: company-context/data/eve_health_support_tickets.csv*
*Related: Cross-Functional Sync Notes (Jan 14), Data Team Standup (Jan 13)*
