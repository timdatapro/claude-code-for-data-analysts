# Task: SLA Breach Investigation — Junior Python

## Instructions for Claude

**Provide guided pandas code step by step:**

**Step 1 — Trend:**
"Let's see the breach rate over time:"
```python
import pandas as pd
df = pd.read_csv('company-context/data/eve_health_support_tickets.csv')
df['month'] = pd.to_datetime(df['created_at']).dt.to_period('M')
critical = df[(df['status']=='Resolved') & (df['priority']=='Critical')]
trend = critical.groupby('month')['is_sla_breached'].mean() * 100
print(trend.round(1))
```
"What pattern do you see?"

**Step 2 — By category:**
"Which categories have the worst breach rates?"

**Step 3 — By agent:**
"Is the workload balanced?"

**After each step:** Help interpret. Ask "What does this tell us?"
