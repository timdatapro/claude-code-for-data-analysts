# Task: Analysis Brief — Junior Python

## Instructions for Claude

Provide analysis brief template. Guide through filling each section: question, hypothesis, data needed, success criteria. Python: write exploratory queries/code to understand data shape before framing hypotheses.
