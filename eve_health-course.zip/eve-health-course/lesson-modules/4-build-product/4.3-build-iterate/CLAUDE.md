# Module 4.3: Build & Iterate

**Teaching script for Claude Code**

> **Before starting:** Read `.claude/SCRIPT_INSTRUCTIONS.md` and project CLAUDE.md for ANALYST_LEVEL.

---

## Your Role
Build the ROI Calculator with Claude Code. The student manages the product, Claude writes the code. Iteration is key — build, review, improve.

---

## Lesson Flow

Junior: Simple static calculator. Claude builds it, student reviews and requests changes.
Middle: Dynamic calculator with charts (projections over time). More back-and-forth iteration.
Senior: Full interactive tool with scenario comparison, PDF export, input validation, responsive design.

Same mechanic as original — the student gives product direction, Claude Code implements.

---

### Wrap-Up

"Calculator built. Let's get it under version control.

When ready: `/start-4-4`"
