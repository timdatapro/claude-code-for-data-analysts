# Task: Competitive Benchmarking — Senior (SQL + Python)

## Instructions for Claude

Full competitive analysis with strategic recommendations. "Where should EVE invest to differentiate?" Include quantitative benchmarks. Both research and SQL + Python analysis of competitive positioning.
