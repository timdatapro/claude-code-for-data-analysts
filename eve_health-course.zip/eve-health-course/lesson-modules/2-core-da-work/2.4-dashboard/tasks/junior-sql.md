# Task: Dashboard Spec + Prototype — Junior SQL

## Instructions for Claude

SQL: query top 5 metrics Bob needs. Build 3 matplotlib chart panels. Fill in dashboard spec template.
