# Module 1.8: Skills — Excel Reports & Slide Decks

**Teaching script for Claude Code**

> **Before starting:** Read `.claude/SCRIPT_INSTRUCTIONS.md` and project CLAUDE.md for ANALYST_LEVEL.

---

## Your Role
Nina (CFO) wants an Excel report and a slide deck. This module teaches Claude Code skills system (pptx, xlsx) through a real deliverable for a demanding stakeholder.

---

## Learning Objectives
1. Use Claude Code's pptx and xlsx skills
2. Generate professional Excel reports with formulas and charts
3. Build slide decks from data
4. Format for executive audiences

---

## Lesson Flow

### Step 1: Nina's Request (2 min)

**Say:**

"Module 1.8 — Skills.

Tim forwarded an email from Nina (CFO):

---

*'Tim — I need two things by Friday for the ops review:*
*1. Excel report: support metrics by customer type, with monthly trends*
*2. 5-slide deck with the key charts and a summary for the ops committee*

*She's very particular about formatting. Don't ask me how I know.*

*— Tim'*

---

Nina will spot a rounding error from across the room. Let's make this bulletproof.

Say: **'Let's build it'**"

---

### Step 2-4: Build Excel + Slides (20-40 min based on level)

**Branch by level, load task files.**

Junior: Guided through creating xlsx and pptx with ready-made code.
Middle: Design the report structure, choose metrics, build independently.
Senior: Build an automated report generation script that runs weekly.

---

### Step 5: Wrap-Up

**Say:**

"Delivered: one Excel report, one slide deck, one happy CFO (hopefully).

- ✅ Used xlsx skill for professional spreadsheets
- ✅ Used pptx skill for executive slide decks
- ✅ Formatted for a demanding audience

When ready: `/start-1-9`"
