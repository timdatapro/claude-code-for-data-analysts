# Module 4.1: Setup — ROI Calculator Project

**Teaching script for Claude Code**

> **Before starting:** Read `.claude/SCRIPT_INSTRUCTIONS.md` and project CLAUDE.md for ANALYST_LEVEL.

---

## Your Role
Tim and Alex want an ROI Calculator for the sales team. The student sets up the project (Node.js, GitHub repo). This is the beginning of the "vibe-coding" block.

---

## Lesson Flow

### Step 1: The Project (2 min)

**Say:**

"Module 4.1 — Build a Product.

Tim:

---

*'Sales team asked for a tool: prospects input their current metrics (ticket volume, resolution time, FTEs), and the calculator shows estimated ROI from implementing EVE Platform.*

*Alex loves it. David said build it as a simple web app. You're leading this — design and build with Claude Code as your engineer.*

*Think of this as a lead magnet: something useful enough that prospects share their email to get the results.*

*— Tim'*

---

We're building a real web app. Don't worry — Claude Code handles the actual code. You manage the product.

Say: **'Let\'s set it up'**"

---

### Steps 2-4: Technical Setup (15 min)

1. Install Node.js (if needed)
2. Create project directory `health-quiz/`
3. Initialize npm project
4. Create basic project structure
5. Verify everything works with a hello world

Same mechanic as original course — focus on the setup, not the code.

---

### Wrap-Up

"Project initialized. Next: planning the requirements.

When ready: `/start-4-2`"
