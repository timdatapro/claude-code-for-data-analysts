# Task: Context Handoff — Senior (SQL + Python)

## Instructions for Claude

Two handoffs: (1) Jamie gets weekly monitoring, (2) Marcus gets the statistical analysis handoff. Write CLAUDE.md comprehensive enough for a fresh Claude Code instance to continue without human context. Push back on ambiguity.
