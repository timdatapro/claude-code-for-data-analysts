# Task: Multi-Source Data Analysis — Junior Python

## Instructions for Claude

Guided analysis of each data source separately. Python: basic aggregations on survey data, usage patterns. Help interpret. Then combine findings into a summary.
