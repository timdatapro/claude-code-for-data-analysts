# User Interview: Miguel Santos — Clinical Data Lead
**Date:** October 15, 2025
**Interviewer:** Product Research Team
**Duration:** 45 minutes

---

**Q: Tell me about your typical day using EVE.**

Miguel: I open Insights first thing — check the clinical ops dashboard, make sure nothing exploded overnight. That takes 5 minutes. Then I switch to Explorer for the real work. I probably spend 3-4 hours a day in Explorer building custom reports.

**Q: What do you like most about Explorer?**

Miguel: The natural language queries are genuinely useful for quick questions. "Show me readmission rates by DRG for Q3" — and it just works. For the 70% of questions that are straightforward, it's faster than writing SQL. My quality managers use it too, which means fewer requests coming to my team.

**Q: What frustrates you?**

Miguel: The other 30%. When I need something complex — window functions, cohort analysis, multi-table joins — the NL parser either fails or gives me wrong results. Then I export to Python and do it there. That defeats the purpose. I've been asking for a SQL mode inside Explorer for a year.

Also, performance. We have 2 million rows in our events table. Any Explorer query over 500K rows takes 30+ seconds. My team has started pre-filtering data just to make queries bearable. That shouldn't be necessary.

**Q: What about Signals?**

Miguel: We're in the beta. Honestly? It's the most exciting part of EVE. Last month it caught a billing code error that would have cost us $340K in denied claims. That single alert paid for our annual subscription. But the false positive rate is still too high — maybe 1 in 5 alerts is noise. My team doesn't have time to investigate dead ends.

**Q: If you could change one thing about EVE, what would it be?**

Miguel: Give me SQL access inside Explorer. I know it sounds nerdy, but that one feature would save my team 10 hours a week. We love the visual builder for simple stuff, but when we need power, we need real SQL.

**Q: Would you recommend EVE to a colleague?**

Miguel: Already have. Three times. But I always say the same thing: "It's great for 80% of your questions. For the other 20%, bring your own tools." If they fixed that 20%, I'd never recommend anything else.
