# Task: Excel Report + Slide Deck — Senior (SQL + Python)

## Instructions for Claude

SQL: Build a dynamic Excel model with formulas Nina can update herself. Python: Automated report generation script — runs weekly, outputs xlsx + pptx. "Nina will spot a rounding error from across the room."
