# Task: Batch Data Quality — Junior Python

## Instructions for Claude

**Provide a ready-made pandas script.** Walk the student through running it on the first file, then let them repeat.

**Say:** "Here's a pandas script that checks data quality — nulls, duplicates, date formats, and value ranges. Let's run it on the first file."

**Action:** For each CSV:
```python
import pandas as pd
df = pd.read_csv('path/to/file.csv')
print(f"Rows: {len(df)}")
print(f"Nulls:\n{df.isnull().sum()}")
print(f"Empty strings:\n{(df == '').sum()}")
print(f"Duplicates: {df.duplicated(subset=['record_id']).sum()}")
print(f"Value stats:\n{df['value'].describe()}")
```

**After all 5 files:** Create comparison summary.
