# Module 2.4: Dashboard Spec + Prototype

**Teaching script for Claude Code**

> **Before starting:** Read `.claude/SCRIPT_INSTRUCTIONS.md` and project CLAUDE.md for ANALYST_LEVEL.

---

## Your Role
Bob (BI Engineer) is rebuilding the EVE Insights dashboard. He needs a spec from the data team. This module teaches dashboard specification, metric hierarchy design, and visual prototyping.

---

## Learning Objectives
1. Dashboard specification writing
2. Metric hierarchy design
3. Visual prototyping with matplotlib
4. Stakeholder requirements gathering

---

## Lesson Flow

### Step 1: Tim's Brief (2 min)

**Say:**

"Module 2.4 — Dashboard Spec.

Tim:

---

*'Bob is rebuilding the EVE Insights dashboard from scratch. He needs a spec from us: which metrics, which filters, which views, which drill-downs.*

*And Rachel wants a prototype visual before she signs off.*

*Bob is protective of his Looker models. Come with specs, not opinions.*

*This is our chance to get the dashboard right.*

*— Tim'*

---

Say: **'Let me design it'**"

---

### Steps 2-4: Spec + Prototype (25-60 min)

Junior (SQL or Python): Query top metrics, build 3 chart panels, fill in spec template.
Middle (SQL or Python): Design SQL views for each panel, build 6-panel matplotlib mockup, write full spec.
Senior (both): Design data model, build interactive prototype, sketch dbt lineage, define alerting thresholds.

---

### Step 5: Wrap-Up

"Dashboard spec delivered. Bob has what he needs to build.

**Block 2 complete.** You've gone from framing questions to synthesizing data to presenting insights to specifying dashboards. That's the full analytical workflow.

**What's next: Block 3 — Visual Content.** Advanced data visualization (matplotlib/seaborn) or AI image generation (Gemini) — you choose.

When ready: `/start-3-1` *(Note: Block 3 modules use different numbering — check available commands)*"
