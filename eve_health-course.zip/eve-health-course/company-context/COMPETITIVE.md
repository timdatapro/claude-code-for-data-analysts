# EVE Health — Competitive Landscape

**Understanding our position in the healthcare analytics market**

---

## Market Overview

**Market:** Healthcare analytics and business intelligence (North America)
**TAM:** $12B (healthcare analytics broadly)
**SAM:** $2.1B (mid-market healthcare organizations)
**Growth:** 18% CAGR (accelerating due to value-based care mandates and AI adoption)

**Key trends:**
- Shift from fee-for-service to value-based care creates massive demand for analytics
- CMS quality reporting requirements getting stricter every year (MIPS, APMs)
- AI/ML adoption in healthcare analytics accelerating — anomaly detection, predictive models
- Self-serve analytics becoming expected, not optional (clinical staff want answers without filing IT tickets)
- Consolidation: big players (Epic, Oracle Health) building analytics into their EHR platforms
- Mid-market gap: too small for Health Catalyst, too complex for generic BI — this is our sweet spot
- Interoperability mandates (ONC, TEFCA) making data integration easier over time

---

## Competitive Matrix

| Competitor | Founded | Stage | Target | ACV | Strength | Weakness |
|---|---|---|---|---|---|---|
| **Health Catalyst** | 2008 | Public (HCAT) | Large health systems | $500K+ | Deep clinical analytics, data OS | Expensive, slow deployment |
| **Arcadia** | 2002 | Late growth | Payers, ACOs | $200–500K | Population health, payer analytics | Weak self-serve, complex setup |
| **Tableau for Healthcare** | 2003* | Public (CRM) | All sizes | $50–200K** | Viz power, brand familiarity | No healthcare context, heavy customization |
| **Epic Cogito** | 2010* | Private (Epic) | Epic customers | $100–300K add-on | Built into Epic, trusted | Epic-only, limited flexibility |
| **Medidata** | 1999 | Dassault Systèmes | Clinical trials | $300K+ | Clinical trials expertise | Different segment, expensive |
| **EVE Health (us)** | 2019 | Series B | Mid-market healthcare | $30–144K | Speed, price, self-serve | Young brand, fewer integrations |

*Approximate year analytics-specific product launched, not company founding
**Including implementation and customization costs

---

## Detailed Competitor Analysis

### 1. Health Catalyst (HCAT)

**Overview:**
- The 800-pound gorilla of healthcare analytics
- Public company (NYSE: HCAT), ~$300M revenue, 400+ health system clients
- Built the "Data Operating System" (DOS) concept — a comprehensive data platform for healthcare
- Acquired multiple companies to build full-stack analytics (KPI Ninja, Able Health, etc.)

**Target market:**
- Large health systems (5,000+ employees, 10+ facilities)
- Academic medical centers
- Integrated delivery networks

**Pricing:**
- Platform license: $500K–$2M/year
- Professional services: $200K–$500K/year (required for implementation)
- Total first-year cost: $700K–$2.5M
- Implementation timeline: 6–12 months

**Strengths:**
- Deep clinical data expertise — 15+ years of healthcare-specific data modeling
- Comprehensive data platform — ingests virtually any healthcare data source
- Strong professional services — on-site teams help build custom analytics
- Robust security and compliance — HITRUST certified, mature HIPAA program
- Research partnerships — published clinical outcomes studies

**Weaknesses:**
- Extremely expensive — mid-market organizations can't afford $1M+ first-year cost
- Slow implementation — 6–12 months before first dashboard goes live
- Over-reliance on professional services — customers can't self-serve without Health Catalyst consultants
- Complex platform — requires dedicated technical staff to maintain
- Stock price pressure — public company dynamics pushing for enterprise deals, ignoring mid-market

**How we win against Health Catalyst:**
- **Price:** 5–10x cheaper at comparable functionality for mid-market
- **Speed:** EVE deploys in 2 weeks, not 6 months
- **Self-serve:** EVE Explorer lets non-technical staff build reports; Health Catalyst requires analysts
- **When we lose:** Customer is a 15-hospital system with $500K+ budget and needs deep clinical modeling

**What their customers say about us:**
> "We evaluated Health Catalyst and EVE. Health Catalyst is like buying a Ferrari when you need a Honda Civic. EVE gives us 80% of the analytics at 20% of the cost." — CFO, 3-hospital network

---

### 2. Arcadia

**Overview:**
- Strong in population health and value-based care analytics
- ~$200M revenue, focused on payers and ACOs (Accountable Care Organizations)
- Recently raised $125M Series D — investing heavily in data platform capabilities
- Good at aggregating data across disparate sources (multiple EHRs, claims, HIE)

**Target market:**
- Health plans and insurance companies
- ACOs and CINs (Clinically Integrated Networks)
- Large physician groups

**Pricing:**
- Platform: $200K–$500K/year (PMPM pricing model for payers)
- Implementation: $100K–$200K
- Total first-year cost: $300K–$700K

**Strengths:**
- Best-in-class data aggregation across multiple EHR vendors
- Strong population health analytics (risk stratification, care gap identification)
- Good with payer customers — understands claims data deeply
- Solid HEDIS and quality measure reporting

**Weaknesses:**
- Weak self-serve capabilities — most reports require Arcadia's team to build
- Limited real-time analytics — designed for batch processing, not daily operational use
- User interface is functional but not intuitive — built for data analysts, not clinicians
- Limited anomaly detection — no equivalent to EVE Signals
- Pricing model (PMPM) gets expensive at scale for large payer populations

**How we win against Arcadia:**
- **Self-serve:** EVE Explorer is light-years ahead — Arcadia's self-serve is basically "email your analyst"
- **Real-time:** EVE refreshes daily (Signals: 15 min); Arcadia is typically weekly batch
- **Anomaly detection:** EVE Signals has no equivalent in Arcadia's product
- **When we lose:** Customer is a large payer needing deep claims aggregation across 50+ provider groups

**What their customers say about us:**
> "Arcadia's data aggregation is unmatched. But when we need to answer a quick question, EVE Explorer is what we use." — VP Analytics, regional health plan

---

### 3. Tableau for Healthcare

**Overview:**
- Salesforce-owned visualization powerhouse, dominant in general BI
- "Tableau for Healthcare" isn't a separate product — it's Tableau with healthcare-specific accelerators (pre-built dashboards, data models, connectors)
- Many healthcare orgs already have Tableau licenses through enterprise agreements

**Target market:**
- All sizes (leveraging existing Salesforce/Tableau enterprise licenses)
- Often IT-driven purchase, not clinical leadership

**Pricing:**
- Tableau licenses: $35–$70/user/month (often already paid through enterprise agreement)
- Healthcare accelerators: $50K–$100K one-time
- Implementation/customization: $100K–$300K (third-party consultants)
- Total first-year cost: $150K–$500K (or near-$0 if licenses already exist)

**Strengths:**
- Visualization capabilities are industry-leading — beautiful, interactive, flexible
- Huge talent pool — many analysts already know Tableau
- Enterprise licenses often already in place — "free" incremental cost perception
- Massive ecosystem — connectors, community, extensions
- Strong governance and security (Salesforce infrastructure)

**Weaknesses:**
- No healthcare-specific logic — you build everything from scratch (what's a "readmission"? Tableau doesn't know)
- Implementation requires expensive consultants to build healthcare data models
- No anomaly detection or predictive analytics out of the box
- Self-serve is possible but complex — non-technical users struggle without training
- Every hospital builds their own version — no standardization, no benchmarking

**How we win against Tableau:**
- **Healthcare context:** EVE understands "readmission rate" out of the box; Tableau needs custom development
- **Time to value:** 2 weeks vs 3–6 months of consultant-led Tableau implementation
- **Pre-built KPIs:** 200+ healthcare metrics ready to go; Tableau starts from zero
- **Benchmarking:** EVE compares your metrics to anonymized peers; Tableau can't
- **When we lose:** Customer has 50 Tableau power users, existing dashboards, and IT staff to maintain them

**What their customers say about us:**
> "We spent $400K building healthcare dashboards in Tableau. Then we plugged in EVE and had better dashboards in 2 weeks. I'm still explaining to the CFO why we did Tableau first." — CIO, community hospital

---

### 4. Epic Cogito

**Overview:**
- Epic's built-in analytics and reporting module
- Available to any organization running Epic EHR (which is ~38% of US hospitals)
- Deeply integrated with Epic clinical data — no ETL needed
- Caboodle (data warehouse) + Cogito (reporting) + SlicerDicer (self-serve) stack

**Target market:**
- Epic customers only (captive market)
- Typically large health systems that already invested heavily in Epic

**Pricing:**
- Cogito analytics: Included in Epic base license (or $100K–$300K add-on depending on contract)
- Caboodle data warehouse: $50K–$150K/year
- Implementation: $100K+ (Epic consultants at $250–$400/hour)

**Strengths:**
- Zero integration needed — data is already in Epic, Cogito reads it directly
- Trusted by clinical leadership — "it's Epic, it must be right"
- SlicerDicer is genuinely good for ad-hoc clinical questions
- HIPAA compliance inherited from Epic's infrastructure
- Epic has massive R&D budget and will keep improving Cogito

**Weaknesses:**
- Only works with Epic data — if you have Cerner, Meditech, or claims data, Cogito can't touch it
- Limited to clinical and operational data — no financial, no claims, no population health
- Customization is expensive — Epic consultants cost $250–$400/hour
- Reporting interface is functional but dated compared to modern BI tools
- No ML-powered anomaly detection — rule-based alerts only
- No cross-organization benchmarking

**How we win against Epic Cogito:**
- **Multi-source:** EVE works with ANY data source — Epic, Cerner, Meditech, claims, all in one platform
- **Financial + clinical:** Cogito does clinical well but can't connect to financial outcomes
- **Anomaly detection:** EVE Signals is ML-powered; Cogito uses static rules
- **Non-Epic organizations:** If you're not on Epic, Cogito doesn't exist for you
- **When we lose:** Large Epic-only health system that doesn't need cross-system analytics

**What their customers say about us:**
> "Cogito is great for our Epic data. But half our facilities are on Cerner. EVE is the only platform that shows us everything in one place." — CMO, 12-hospital system

---

### 5. Medidata (Dassault Systèmes)

**Overview:**
- Leader in clinical trials data and analytics
- Acquired by Dassault Systèmes for $5.8B in 2019
- Rave platform is the industry standard for clinical trial data management
- Different core market than EVE, but overlapping customers (Lisa Chang's use case)

**Target market:**
- Pharma and biotech (clinical trials)
- CROs (Contract Research Organizations)
- Digital health companies seeking FDA submissions

**Pricing:**
- Rave platform: $300K–$1M+/year
- Consulting services: $200K+/year
- Total: $500K–$1.5M/year

**Strengths:**
- Gold standard for clinical trial data management and regulatory analytics
- FDA trusts Medidata — their platform is accepted standard for submissions
- Deep expertise in regulatory statistical analysis (ITT, per-protocol)
- Massive dataset of historical clinical trials for benchmarking

**Weaknesses:**
- Built for clinical trials, not operational healthcare analytics
- Extremely expensive — $500K+ minimum
- Not designed for real-time operational dashboards
- Overkill for non-clinical-trial use cases
- Complex implementation requiring Medidata consultants

**How we win against Medidata:**
- **Different use case:** EVE for operational analytics, Medidata for trial data management
- **Price:** 10x cheaper for non-trial analytics needs
- **When we lose:** Customer's primary need is FDA submission support for a clinical trial
- **Opportunity:** Digital health companies like Wellspring need both — Medidata for trial data, EVE for outcomes analytics. We can coexist.

---

## Competitive Positioning Summary

### Where EVE Wins

| Scenario | Why EVE | Over whom |
|---|---|---|
| Mid-market hospital needs analytics fast | 2-week deployment, $30K ACV | Health Catalyst, Arcadia |
| Non-technical staff need self-serve reports | EVE Explorer with natural language | All competitors |
| Multi-EHR organization needs unified view | Source-agnostic platform | Epic Cogito |
| Organization needs anomaly detection | EVE Signals (ML-powered) | Tableau, Arcadia, Cogito |
| Budget-conscious organization | 5–10x cheaper than enterprise options | Health Catalyst, Medidata |

### Where EVE Loses

| Scenario | Why we lose | To whom |
|---|---|---|
| 15-hospital system, $1M+ budget, needs deep clinical modeling | We're not deep enough yet | Health Catalyst |
| Epic-only shop that only needs Epic data | Cogito is built-in, no integration needed | Epic Cogito |
| Large payer needing claims aggregation across 50+ provider groups | Arcadia's data aggregation is stronger | Arcadia |
| Team of 30 Tableau power users with existing dashboards | Migration cost outweighs EVE benefits | Tableau |
| FDA clinical trial submission | Not our domain | Medidata |

### Strategic Implications for Data Team

As a Product Analyst, competitive intelligence directly affects your work:

**Win rate analysis:** When you analyze churn or lost deals, look for competitive displacement patterns. Are we losing to Health Catalyst on depth? To Tableau on familiarity? To Cogito on "it's already here"?

**Feature gap analysis:** When Explorer adoption is low, is it because Tableau does it better? Or because Explorer doesn't have features competitors offer (like Cogito's SlicerDicer)?

**Pricing analysis:** When churn is high in small accounts, is it because our pricing isn't competitive? Or because the value isn't landing?

Tim will ask you to pull competitive data regularly. Know these competitors cold.

---

**Remember: We don't win by being better at everything. We win by being the best option for mid-market healthcare organizations that need answers fast, at a price they can afford, without hiring a team of data engineers. That's our lane. Own it.**
