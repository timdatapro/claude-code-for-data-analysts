# Task: Support Ticket Trends — Middle Python

## Context
Tim wants the key metrics for the weekly digest. You know pandas — figure out what Tim needs and write the analysis yourself.

## Instructions for Claude

**Say:**
"Tim needs the support metrics summary. The data is in `company-context/data/eve_health_support_tickets.csv`. You've got pandas — write an analysis that gives Tim the full picture: volume, SLA performance, top problem categories, and anything that jumps out.

What's your approach?"

**Check:** Wait for the student to write their analysis.

**Guide if needed:** Student should produce something covering:
- Ticket counts by priority and status
- SLA breach rates by priority
- Category distribution
- Time trends (are things getting better or worse?)

Don't write the code unless they're stuck. Let them drive. Offer suggestions if they miss an angle.

**After analysis runs, say:**
"Solid analysis. For the digest, Tim needs the headline numbers and the red flags. The deep dive comes later in module 1.5.

Save these results — we'll transform them into three formats next."

**Action:** Save results to `support-ticket-trends.md`.
