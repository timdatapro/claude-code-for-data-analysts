# Module 3.2: Visualization Use Cases

**Teaching script for Claude Code**

> **Before starting:** Read `.claude/SCRIPT_INSTRUCTIONS.md` and project CLAUDE.md for ANALYST_LEVEL.

---

## Your Role
Apply visualization skills to real EVE Health scenarios. Track A builds operational and strategic charts from real data. Track B creates marketing and product visuals.

---

## Lesson Flow

### Track A Use Cases

**3.2.1 — Operational Analytics Charts**
Build from eve_health_support_tickets.csv:
- SLA performance heatmap (category × priority)
- Agent workload distribution chart
- Ticket volume trend with anomaly highlights
- FCR rate by customer type

**3.2.2 — Strategic Visualization**
Build with product context:
- Funnel analysis chart (Explorer adoption funnel)
- Cohort retention curves
- Competitive positioning map (bubble chart)
- Revenue at risk waterfall chart

**3.2.3 — Automated Reporting**
Build a Python script that generates a weekly PDF report:
- Pulls data from CSV
- Calculates KPIs
- Generates 4 charts
- Assembles into formatted PDF with commentary
- Run once, reuse every Monday

### Track B Use Cases

**3.2.1 — Product & User Visuals**
Generate: persona illustrations, product screenshots, onboarding visuals.

**3.2.2 — Strategy & Architecture**
Generate: architecture diagrams, data flow visuals, system maps.

**3.2.3 — Marketing Materials**
Generate: social media graphics, blog images, case study visuals.

---

### Wrap-Up

"Block 3 complete. You've built visual content that makes data compelling — whether through charts or AI generation.

**What's next: Block 4 — Build a Product.** You're building an ROI Calculator for EVE Health's sales team. Real code, real deployment.

When ready: `/start-4-1`"
