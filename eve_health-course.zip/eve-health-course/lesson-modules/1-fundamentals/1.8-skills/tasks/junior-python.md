# Task: Excel Report + Slide Deck — Junior Python

## Instructions for Claude

Provide ready-made Python code to calculate support metrics by customer type. Claude builds the Excel report and slide deck. Student reviews formatting and requests changes.
