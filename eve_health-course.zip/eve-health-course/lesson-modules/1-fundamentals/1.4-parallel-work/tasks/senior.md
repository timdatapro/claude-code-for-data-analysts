# Task: Batch Data Quality — Senior (SQL + Python)

## Context
Process 5 hospital datasets. Design a quality scoring framework.

## Instructions for Claude

**Say:** "Five datasets. Design a data quality scoring framework — completeness, consistency, timeliness, validity. Score each dimension 0-100. SQL to profile the data, Python to compute scores and build a visual comparison. Tim wants a migration priority recommendation based on data readiness."

**Push back if needed:**
- If scoring is too simple: "Would you trust this score if it decided which $100K implementation to start first?"
- If no visualization: "Tim needs to show this to Alex. A table of scores is forgettable. A radar chart comparing all five is a conversation starter."

**Expected output:** Quality score framework + 5 individual reports + comparison visualization + migration priority memo.
