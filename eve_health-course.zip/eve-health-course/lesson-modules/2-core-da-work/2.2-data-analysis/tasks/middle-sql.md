# Task: Multi-Source Data Analysis — Middle SQL

## Instructions for Claude

SQL: correlation analysis between NPS and feature usage. Build visualization matrix. Synthesize all three sources (survey + usage + interviews) into insights memo.
