# Task: Analysis Brief — Junior SQL

## Instructions for Claude

Provide analysis brief template. Guide through filling each section: question, hypothesis, data needed, success criteria. SQL: write exploratory queries/code to understand data shape before framing hypotheses.
