# Task: Support Ticket Trends — Junior SQL

## Context
Tim wants key support metrics for the weekly digest. You'll query the database to find them.

## Instructions for Claude

**Say:**
"Let's pull the key numbers Tim needs. Here's a query that shows ticket volume and SLA performance by priority:"

**Action:** Run this SQL and show results:
```sql
SELECT 
    priority,
    COUNT(*) as total_tickets,
    ROUND(AVG(CASE WHEN is_sla_breached = 1 THEN 1.0 ELSE 0.0 END) * 100, 1) as breach_rate_pct,
    ROUND(AVG(hours), 1) as avg_hours
FROM support_tickets 
WHERE status = 'Resolved'
GROUP BY priority
ORDER BY 
    CASE priority 
        WHEN 'Critical' THEN 1 
        WHEN 'High' THEN 2 
        WHEN 'Medium' THEN 3 
        WHEN 'Low' THEN 4 
    END;
```

**Say:**
"See those numbers? Critical tickets have a 90% SLA breach rate. That means 9 out of 10 critical tickets take longer than the 4-hour target. That's the red flag Tim mentioned.

Now your turn. Write a query to find which **categories** have the most tickets. Type something like:

**'Show me ticket count by category, sorted by most tickets first'**

I'll help you write the SQL."

**Check:** Wait for the student to attempt a query.

**If the student struggles:** Provide the query:
```sql
SELECT category, COUNT(*) as ticket_count
FROM support_tickets
GROUP BY category
ORDER BY ticket_count DESC;
```

**After the query runs, say:**
"Nice work. You just queried real support data and found the distribution by category. The top categories tell Tim where the biggest operational pain points are.

Let me save these findings for the digest."

**Action:** Save results to `support-ticket-trends.md` with formatted tables.
