# Testing Checklist — EVE Health Course

**How to verify each module works correctly**

---

## Setup Verification

- [ ] Course folder unzips correctly
- [ ] `company-context/` files are readable
- [ ] CSV files load without encoding errors
- [ ] sqlite3 database creates from CSV (Module 1.2)
- [ ] Slash commands are recognized by Claude Code

---

## Module Testing Checklist

### Block 1 — Fundamentals

| Module | Test | Pass? |
|---|---|---|
| 1.1 | Level selection saves to CLAUDE.md | |
| 1.1 | All three experience levels produce different flows | |
| 1.2 | sqlite3 database creates successfully | |
| 1.2 | `SELECT COUNT(*) FROM support_tickets` returns 2672 | |
| 1.3 | Meeting notes files are readable | |
| 1.3 | Communication style templates produce correct output | |
| 1.3 | SQL and Python task files load correctly per level | |
| 1.4 | All 5 batch CSV files load without errors | |
| 1.4 | Each batch file has intentional quality issues | |
| 1.5 | Sub-agent files (.claude/agents/) are read correctly | |
| 1.5 | Investigation produces root cause memo | |
| 1.6 | CLAUDE.md handoff is written and testable | |
| 1.7 | Crisis files load correctly | |
| 1.7 | Manual metric calculation matches CSV data | |
| 1.8 | xlsx and pptx skills produce downloadable files | |
| 1.9 | Web search returns relevant competitor data | |
| 1.10 | Custom skill is created and documented | |

### Block 2 — Core DA Work

| Module | Test | Pass? |
|---|---|---|
| 2.1 | Analysis brief is structured and complete | |
| 2.2 | All three data sources load (survey, usage, interviews) | |
| 2.2 | Survey CSV has 320 rows with expected columns | |
| 2.2 | Usage CSV has 8000 rows with expected columns | |
| 2.2 | Interview transcripts are readable | |
| 2.3 | Slide deck is generated with charts | |
| 2.4 | Dashboard spec is complete with metrics and filters | |

### Block 3 — Visual Content

| Module | Test | Pass? |
|---|---|---|
| 3.1 | Track selection (A or B) works | |
| 3.1 | matplotlib charts render correctly | |
| 3.2 | Automated report script produces PDF | |

### Block 4 — Build a Product

| Module | Test | Pass? |
|---|---|---|
| 4.1 | Node.js project initializes | |
| 4.2 | Requirements document is created | |
| 4.3 | ROI Calculator runs locally | |
| 4.4 | GitHub repo is created and pushed | |
| 4.5 | Vercel deployment succeeds | |

### Block 5 — What's Next

| Module | Test | Pass? |
|---|---|---|
| 5.1 | MCP concept is explained clearly | |
| 5.2 | Rollout plan is actionable | |
| 5.2 | Course closing message displays with LinkedIn | |

---

## Multi-Level Testing

For each module with task files, verify all 6 variants:

| Variant | Test |
|---|---|
| Junior SQL | Task file loads, SQL code works |
| Junior Python | Task file loads, Python code works |
| Middle SQL | Task file loads, appropriate difficulty |
| Middle Python | Task file loads, appropriate difficulty |
| Senior | Both SQL and Python sections present |
| Level detection | ANALYST_LEVEL read correctly from CLAUDE.md |

---

## Data Integrity

- [ ] `eve_health_support_tickets.csv`: 2672 rows, 16 columns
- [ ] `eve_platform_usage.csv`: 8000 rows, 7 columns
- [ ] `eve_survey_results.csv`: 320 rows, 13 columns
- [ ] Batch files (5): 180-250 rows each with intentional issues
- [ ] No references to original course content in any file
- [ ] No Russian text in any file
- [ ] All names are English/American

---

## How to Report Issues

File issues or contact the author:
- Tim Fateev — [LinkedIn](https://www.linkedin.com/in/tim-datapro/)
