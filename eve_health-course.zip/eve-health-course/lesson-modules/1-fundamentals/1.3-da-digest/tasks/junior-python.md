# Task: Support Ticket Trends — Junior Python

## Context
Tim wants key support metrics for the weekly digest. You'll use pandas to analyze the CSV.

## Instructions for Claude

**Say:**
"Let's pull the key numbers Tim needs. Here's a script that shows ticket volume and SLA performance:"

**Action:** Run this Python code and show results:
```python
import pandas as pd

df = pd.read_csv('company-context/data/eve_health_support_tickets.csv')

# Ticket count and SLA breach rate by priority
summary = df[df['status'] == 'Resolved'].groupby('priority').agg(
    total_tickets=('ticket_id', 'count'),
    breach_rate=('is_sla_breached', 'mean'),
    avg_hours=('hours', 'mean')
).round(2)
summary['breach_rate'] = (summary['breach_rate'] * 100).round(1).astype(str) + '%'
summary['avg_hours'] = summary['avg_hours'].round(1)
print(summary)
```

**Say:**
"See those numbers? Critical tickets have a ~90% SLA breach rate. That means 9 out of 10 critical tickets take longer than the 4-hour target. That's the red flag Tim mentioned.

Now your turn. Write a prompt to find which **categories** have the most tickets. Type something like:

**'Show me ticket count by category, sorted by most tickets first'**

I'll write the pandas code."

**Check:** Wait for the student to make a request.

**Action:** Write and run the appropriate pandas code:
```python
print(df['category'].value_counts())
```

**After the code runs, say:**
"Nice work. You just analyzed real support data and found the distribution by category. The top categories tell Tim where the biggest operational pain points are.

Let me save these findings for the digest."

**Action:** Save results to `support-ticket-trends.md` with formatted tables.
