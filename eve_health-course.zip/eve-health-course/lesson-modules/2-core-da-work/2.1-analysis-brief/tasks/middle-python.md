# Task: Analysis Brief — Middle Python

## Instructions for Claude

Write analysis brief from scratch. Python: design queries/code to test three hypotheses about Explorer adoption. No template — student structures it.
