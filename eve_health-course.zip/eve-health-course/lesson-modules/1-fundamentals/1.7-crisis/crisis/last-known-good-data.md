# Last Known Good Data Points

**Verified as of:** January 10, 2026 at 11:47 PM EST
**Source:** Direct CSV export before pipeline failure

## Verified Metrics (Jan 1-10)

| Metric | Value | Confidence |
|--------|-------|------------|
| Tickets Created | 847 | High (direct count) |
| Tickets Resolved | 792 | High |
| Critical Tickets | 189 | High |
| Critical SLA Breached | 168 | High |
| Mean Resolution (all) | 17.3 hrs | High |
| FCR Rate | 59.1% | High |

## What We Know About Jan 11-16

- CSV file (eve_health_support_tickets.csv) contains ALL data through Jan 16
- The dashboard pipeline failed on Jan 10 — it stopped reading new data
- The RAW DATA is fine — only the dashboard view is stale
- You can calculate accurate Jan 11-16 metrics directly from the CSV

## Pipeline Failure Timeline

- Jan 10 11:47 PM — Last successful pipeline run
- Jan 11 2:00 AM — Pipeline failed (Airflow DAG timeout)
- Jan 11 9:00 AM — Bob noticed stale dashboard during morning check
- Jan 11 10:30 AM — Priya started debugging
- Jan 12 — Priya identified root cause: Snowflake connection pool exhausted during migration
- Jan 13 — Fix deployed but pipeline backfill still running
- Jan 16 (NOW) — Pipeline partially restored, dashboard still showing Jan 10 data
