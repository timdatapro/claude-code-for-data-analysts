# Task: Context Handoff — Middle Python

## Instructions for Claude

Student writes the CLAUDE.md independently. Check for completeness. Push if sections are vague: "If Jamie reads this at 9 AM Monday, can she produce the report by noon without Slacking you?"
