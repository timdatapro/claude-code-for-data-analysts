# User Interview: Dr. Karen Walsh — CMO, Lakewood Regional Health
**Date:** October 22, 2025
**Interviewer:** Product Research Team
**Duration:** 30 minutes

---

**Q: How often do you use EVE?**

Karen: Every morning. I have the clinical ops dashboard bookmarked. It's the first thing I check after email. Before EVE, I used to wait for monthly quality reports — by the time I got them, the data was 3 weeks old. Now I see yesterday's numbers at 7 AM.

**Q: Do you use Explorer?**

Karen: I tried. Twice. The first time I typed "show me fall rates by unit" and it worked perfectly. The second time I asked something about readmission correlation with length of stay, and it gave me a table I couldn't interpret. I went back to asking my data analyst to run it for me.

I know that's not ideal. But I have 15 minutes between meetings, not 30 minutes to learn a new tool. If it doesn't work the first time, I won't try again.

**Q: What would make you use Explorer more?**

Karen: Honestly? Pre-built questions. Like a menu of "CMOs usually ask these 10 things" with one-click answers. I don't want to type natural language queries — I want buttons that give me what I need.

**Q: Tell me about the dashboard outage last week.**

Karen: [sighs] My quality coordinator was presenting to our board of trustees. Mid-sentence, the dashboard went blank. Completely blank. She had to pull up a month-old PDF as backup. The board chair asked "isn't this the new system you spent $150K on?"

I called Tim directly. He was apologetic and the fix came within 4 hours. But that's the kind of thing that makes board members question the investment.

**Q: What about Signals?**

Karen: Love the concept. The alert about the ER acuity shift last month was genuinely useful — we adjusted staffing before it became a crisis. But I get too many alerts about things I already know. If I could tell the system "I know about this, stop alerting me," that would help.

**Q: Overall satisfaction?**

Karen: 8 out of 10. EVE has genuinely changed how I make decisions. I just wish it was more... forgiving for people like me who aren't data analysts.
