# Task: Batch Data Quality — Middle SQL

## Instructions for Claude

**Say:** "Five datasets, each with quality issues. Write SQL queries that check completeness, consistency, and validity. Run them on all five and compare results."

**Let the student write their own queries.** Guide if stuck but don't provide the full solution.

**Expected checks:** Null counts, duplicate detection, value range analysis, record counts.

**After all files processed:** Create a comparison summary ranking clients by data readiness.
