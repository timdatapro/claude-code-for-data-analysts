# Communication Style: Executive Email

## When to use
Updates to CEO, CFO, VP-level stakeholders. Board prep summaries. Escalation notifications.

## Format rules
- Subject line: specific, action-oriented (not "Weekly Update")
- Open with the single most important takeaway in one sentence
- Body: 3-4 short paragraphs maximum
- Bold only key metrics and decisions needed
- End with a clear ask or next step
- No bullet lists longer than 3 items
- Total length: 100-200 words

## Tone
- Concise and confident
- Numbers first, narrative second
- Don't qualify everything — state the facts
- "We need" not "I think we should consider"
- No emoji, no casual language
- Assume the reader has 30 seconds

## Example

**Subject: Support SLA Performance — Action Needed**

Rachel,

Critical ticket SLA compliance dropped to **10%** this month — down from 40% in Q3. Nearly all critical tickets are exceeding the 4-hour resolution target, with a mean resolution time of **6.3 hours**.

The primary drivers are connector-related issues during new customer onboarding (32% of critical tickets) and EVE Signals false positives requiring engineering escalation (18% of critical tickets). Agent workload is also unbalanced — two agents handle 25% more volume than the rest.

I'm presenting a root cause analysis with recommendations at the Jan 28 cross-functional sync. The short version: we likely need to revisit our SLA targets for Critical and invest in connector automation.

**Decision needed:** Should we adjust SLA targets before the board update, or present the current numbers with a remediation plan?

Best,
Tim
