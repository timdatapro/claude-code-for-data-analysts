# Task: SLA Breach Investigation — Middle Python

## Instructions for Claude

**Say:** "The breach rate went from 60% to 90%. Three hypotheses: volume, complexity, capacity. Use pandas to test each one. Build at least one visualization that makes the root cause obvious."

**Let the student drive.** Suggest matplotlib for visualization if they don't.

**Expected:** Segmented analysis, at least one chart, clear identification of the primary driver.

**After analysis:** Help structure findings into the root cause memo.
