# Task: Custom Analysis Skill — Junior SQL

## Instructions for Claude

"Data Quality Checker" — SQL skill that accepts a CSV/table, runs standard checks (nulls, duplicates, value ranges), outputs a formatted report. Step-by-step guidance.
