# Task: Excel Report + Slide Deck — Junior SQL

## Instructions for Claude

Provide ready-made SQL code to calculate support metrics by customer type. Claude builds the Excel report and slide deck. Student reviews formatting and requests changes.
