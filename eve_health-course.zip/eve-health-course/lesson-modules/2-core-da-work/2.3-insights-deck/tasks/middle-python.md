# Task: Insights Deck for Leadership — Middle Python

## Instructions for Claude

Design story arc: "What does Rachel need to believe by slide 7?" Build 5 publication-ready charts. Write speaker notes for Alex.
