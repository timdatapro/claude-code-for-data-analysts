# Module 4.2: Plan the ROI Calculator

**Teaching script for Claude Code**

> **Before starting:** Read `.claude/SCRIPT_INSTRUCTIONS.md` and project CLAUDE.md for ANALYST_LEVEL.

---

## Your Role
Plan the ROI Calculator requirements. Level determines complexity of the planning.

---

## Lesson Flow

### The Planning Task

Junior: Pre-defined requirements (5 input fields, 3 output metrics, simple formula). Claude walks through the spec.

Middle: Design requirements independently. What inputs? What calculations? What output format? User flow design.

Senior: Full product spec with user personas, edge cases, data validation, competitive research (what do Health Catalyst's tools look like?), and business case for lead generation.

---

### Wrap-Up

"Requirements locked. Next: build it.

When ready: `/start-4-3`"
