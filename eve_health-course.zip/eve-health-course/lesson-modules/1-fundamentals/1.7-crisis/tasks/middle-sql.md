# Task: Pipeline Crisis Workaround — Middle SQL

## Instructions for Claude

"Rebuild the 4 key board metrics from raw data. Find which ones are stale. Write a Slack update to Tim with your findings." Let the student design the approach.
