# Module 1.6: Memory & CLAUDE.md Handoff

**Teaching script for Claude Code**

> **Before starting:** Read `.claude/SCRIPT_INSTRUCTIONS.md` and project CLAUDE.md for ANALYST_LEVEL.

---

## Your Role
You're leading Module 1.6. The student is going on vacation for 2 weeks. Jamie (Junior Analyst) needs to pick up their work. The student must write a CLAUDE.md that transfers all context — the ultimate test of documentation.

---

## Learning Objectives
1. Understand CLAUDE.md as project memory
2. Write effective context handoff documents
3. Know what information Claude Code needs to continue work
4. Practice documentation as a professional skill

---

## Lesson Flow

### Step 1: Tim's Request (2 min)

**Say:**

"Module 1.6 — Memory & Handoff.

Tim's Slack:

---

*'Great work on the SLA investigation. You've earned a break — take two weeks. But before you go, I need you to document everything so Jamie can pick it up.*

*Think of CLAUDE.md as notes on the fridge for Jamie. If she has to Slack you every 10 minutes while you're on a beach, the documentation failed.*

*— Tim'*

---

Writing good documentation is like flossing — everyone knows they should do it, nobody wants to, and you'll regret skipping it exactly once.

Ready? Say: **'Let me document'**"

**Check:** Wait

---

### Step 2: Understanding CLAUDE.md (5 min)

**Say:**

"CLAUDE.md is the project memory file. When a new Claude Code session starts, it reads this file first. Think of it as instructions for a capable but context-free colleague.

A good CLAUDE.md has:
1. **Project context** — What are we working on? Why?
2. **Current status** — What's done? What's in progress? What's blocked?
3. **Key decisions** — What did we decide and why?
4. **Data sources** — Where's the data? What format? Any gotchas?
5. **Contacts** — Who to ask about what?
6. **Conventions** — File naming, folder structure, style preferences

Let me show you the current CLAUDE.md."

**Action:** Read and display the project CLAUDE.md (currently just has ANALYST_LEVEL).

**Say:** "Right now it just has your level. We're going to make it comprehensive."

---

### Step 3: Writing the Handoff (15 min)

**Branch by level:**

#### [JUNIOR & MIDDLE]
**Say:** "Jamie will run the weekly SLA monitoring report while you're gone. Write a CLAUDE.md that gives her everything she needs: what to look at, what queries to run, what 'normal' looks like, when to escalate to Tim.

I'll help you structure it. What's the first thing Jamie needs to know?"

Guide the student through writing each section. For Junior, provide more scaffolding.

#### [SENIOR]
**Say:** "Two handoffs. First: Jamie takes over weekly SLA monitoring. Second: Marcus continues your statistical analysis — you found a pattern that needs modeling. 

Write a CLAUDE.md that a different Claude Code instance could pick up and continue your work without any additional context. Both handoffs in one file."

Less guidance. Push back if documentation is vague.

---

### Step 4: Testing the Handoff (5 min)

**Say:**

"Let's test it. I'm going to pretend I'm a fresh Claude Code instance reading this CLAUDE.md for the first time. Can I understand what to do?"

**Action:** Read the CLAUDE.md the student wrote. Identify any gaps or ambiguities. Ask clarifying questions as if you were Jamie.

**Say:** "Here are the questions Jamie would ask: [list gaps]. Let's fix those."

---

### Step 5: Wrap-Up (2 min)

**Say:**

"Handoff complete. Here's what you built:
- ✅ Project context for anyone picking up your work
- ✅ Clear status of current tasks
- ✅ Data sources and conventions documented
- ✅ Specific instructions for Jamie's weekly report

**Key lesson:** CLAUDE.md isn't just for Claude — it's for your future self and your teammates. Every project should have one.

**What's next: Module 1.7 — Crisis Mode**

The data pipeline broke. The board meeting dashboard is showing last week's numbers. Rachel presents in 36 hours. Welcome to analytics.

When ready: `/start-1-7`"

---

## Success Criteria
- ✅ Wrote a comprehensive CLAUDE.md
- ✅ Included all essential sections
- ✅ Documentation passes the "Jamie test"
- ✅ Understands CLAUDE.md as living documentation
