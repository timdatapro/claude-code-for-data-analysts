# Module 1.10: Build Your Own Analysis Skill

**Teaching script for Claude Code**

> **Before starting:** Read `.claude/SCRIPT_INSTRUCTIONS.md` and project CLAUDE.md for ANALYST_LEVEL.

---

## Your Role
Tim wants the student to build a reusable automation — turning a repetitive task into a Claude Code skill. This is the capstone of Block 1.

---

## Learning Objectives
1. Create a custom Claude Code skill
2. Turn repetitive analysis into reusable automation
3. Think like a tool builder, not just a tool user
4. Document for team reuse

---

## Lesson Flow

### Step 1: Tim's Challenge (2 min)

**Say:**

"Module 1.10 — Build Your Own Skill.

Tim:

---

*'You've been here a few weeks. You've done weekly digests, investigations, batch processing, crisis recovery. Think about the repetitive parts. What would you automate?*

*Build a skill that makes your own life easier. Then document it so Jamie can use it too.*

*Every great analyst eventually realizes: the best analysis is the one you only have to build once.*

*— Tim'*

---

Say: **'I have an idea'**"

---

### Steps 2-4: Build the Skill (20-40 min)

**Branch by level, load task files.**

Junior (SQL or Python): "Data Quality Checker" — accepts a CSV, runs standard checks, outputs report.
Middle (SQL or Python): "Weekly Metrics Digest Generator" — queries DB, calculates KPIs, generates formatted summary.
Senior (both): "Anomaly Investigation Framework" — accepts a metric + time period, segments by all dimensions, finds the driver, generates memo.

---

### Step 5: Wrap-Up

"Block 1 complete. You started as a new hire who didn't know where the CSV was. Now you've built a reusable tool that the team can use.

**Block 1 recap — what you learned:**
- ✅ Navigate company context and data
- ✅ Analyze and transform data for different audiences
- ✅ Run parallel agents for batch processing
- ✅ Investigate metric spikes with sub-agents
- ✅ Write handoff documentation
- ✅ Handle crises with manual workarounds
- ✅ Build professional reports and decks
- ✅ Research competitors with web search
- ✅ Build reusable analysis tools

**What's next: Block 2 — Core DA Work.** The real analytical challenges begin. Module 2.1: Tim asks you to frame the question before touching the data. Most analysts skip this step. The best ones don't.

When ready: `/start-2-1`"
