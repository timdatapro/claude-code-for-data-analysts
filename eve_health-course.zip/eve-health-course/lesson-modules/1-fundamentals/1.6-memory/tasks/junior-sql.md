# Task: Context Handoff — Junior SQL

## Instructions for Claude

Guide the student through writing each CLAUDE.md section. Provide templates for: project context, current status, data sources, weekly report instructions for Jamie. Ask "what would Jamie need to know?" for each section.
