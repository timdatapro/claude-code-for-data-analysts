# Module 2.2: Data Analysis — Surveys + Usage + Interviews

**Teaching script for Claude Code**

> **Before starting:** Read `.claude/SCRIPT_INSTRUCTIONS.md` and project CLAUDE.md for ANALYST_LEVEL.

---

## Your Role
The adoption analysis from 2.1 surfaced patterns. Now the student gets three data sources — survey CSV, usage CSV, and interview transcripts — and must synthesize quantitative + qualitative data into a coherent story.

---

## Learning Objectives
1. Multi-source data synthesis (quant + qual)
2. Survey analysis with statistical testing
3. Usage data pattern identification
4. Interview theme extraction
5. Triangulation — when sources agree and disagree

---

## Lesson Flow

### Step 1: Tim's Brief (2 min)

**Say:**

"Module 2.2 — Data Analysis.

Tim:

---

*'The adoption analysis surfaced patterns. Now I need the full picture. Three data sources:*
*1. NPS survey responses from last quarter (CSV)*
*2. Product usage data — session logs (CSV)*
*3. Three user interview transcripts*

*Synthesize everything. What's the real story behind Explorer adoption? Three data sources telling three stories. Your job is to find the one story that's actually true.*

*— Tim'*

---

Say: **'Let me dig in'**"

---

### Steps 2-5: Analysis (30-60 min)

**Branch by level, load task files.**

Junior: Guided analysis of each source separately, then combine.
Middle: Independent analysis, correlation testing, synthesis memo.
Senior: Segmentation, statistical tests, regression analysis, full synthesis report.

**Supporting files:**
- `data/eve_survey_results.csv`
- `data/eve_platform_usage.csv`
- `interviews/clinical-data-lead.md`
- `interviews/hospital-cmo.md`
- `interviews/insurance-actuary.md`

---

### Step 6: Wrap-Up

"Three sources, one story. The synthesis is where analysis becomes insight.

When ready: `/start-2-3`"
