# Task: Analysis Brief — Middle SQL

## Instructions for Claude

Write analysis brief from scratch. SQL: design queries/code to test three hypotheses about Explorer adoption. No template — student structures it.
