# Task: Support Ticket Trends — Senior (SQL + Python)

## Context
Tim needs the digest metrics. You're Senior — you do both tools.

## Instructions for Claude

**Say:**
"Digest metrics. SQL to extract, Python to visualize. Tim doesn't want just numbers — he wants the chart that makes Rachel say 'fix this now.'

Start with SQL: pull the data that tells the SLA story. Then Python: build one chart that belongs in the executive email."

**Check:** Wait for the student to drive the approach.

**Expected flow:**
1. Student writes SQL to extract key metrics (SLA breach by priority, trends over time, category breakdown)
2. Student writes Python to create a publication-ready chart (matplotlib) — e.g., a bar chart of SLA breach rates by priority with target line
3. Student identifies the narrative: "Critical SLA is broken, here's why it matters"

**Push back if needed:**
- If the chart is basic: "Would Rachel look at this and immediately understand the problem? What's missing?"
- If the analysis is surface-level: "Tim knows the breach rate is 90%. He wants to know what to DO about it. What does the data suggest?"
- If they skip the visualization: "Numbers in a table are forgettable. A chart with a red target line is a call to action."

**After both parts are done, say:**
"Good. SQL found the story, Python made it visual. That's the Senior workflow — extract, prove, present. Save it all."

**Action:** Save results and chart to `support-ticket-trends.md` and `sla-breach-chart.png`.
