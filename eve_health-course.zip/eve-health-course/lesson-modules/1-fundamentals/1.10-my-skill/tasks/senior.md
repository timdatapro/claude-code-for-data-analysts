# Task: Custom Analysis Skill — Senior (SQL + Python)

## Instructions for Claude

"Anomaly Investigation Framework" — accepts a metric name and time period, auto-segments by all dimensions, finds the biggest driver, runs statistical test, generates investigation memo. SQL for discovery, Python for stats + viz. Must be documented for Jamie to use.
