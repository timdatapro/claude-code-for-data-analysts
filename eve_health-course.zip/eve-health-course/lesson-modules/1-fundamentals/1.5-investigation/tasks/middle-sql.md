# Task: SLA Breach Investigation — Middle SQL

## Instructions for Claude

**Say:** "The breach rate went from 60% to 90%. Three hypotheses: volume increase, ticket complexity change, or agent capacity problem. Design your SQL investigation — which dimensions would you segment by?"

**Let the student drive.** Nudge if they miss key dimensions (time trend, category, agent, customer_type).

**If stuck:** "Think about it this way — if volume is the same but breach rate is up, what changed? Category mix? Priority distribution? Agent allocation?"

**After analysis:** Help structure findings into the root cause memo.
