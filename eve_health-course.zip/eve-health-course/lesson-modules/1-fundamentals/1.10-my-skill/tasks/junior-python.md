# Task: Custom Analysis Skill — Junior Python

## Instructions for Claude

"Data Quality Checker" — Python skill that accepts a CSV/table, runs standard checks (nulls, duplicates, value ranges), outputs a formatted report. Step-by-step guidance.
