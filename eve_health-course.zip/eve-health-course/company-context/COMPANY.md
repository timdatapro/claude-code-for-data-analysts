# EVE Health Analytics — Company Overview

**Welcome to EVE Health!** You're joining a healthcare analytics company at a pivotal moment — growth is strong, but engagement and churn are keeping leadership up at night. Your job is to figure out why.

---

## About the Company

**Founded:** 2019
**Headquarters:** Austin, Texas (distributed team)
**Stage:** Series B ($18M raised)
**Employees:** 112

**What we do:** EVE Health builds a B2B analytics platform for mid-size hospital networks, insurance providers, and digital health companies. We turn messy healthcare data into dashboards, alerts, and insights that help organizations make better decisions — faster.

**The short version:** If a hospital CFO wants to know why readmission rates spiked last quarter, or an insurance analyst needs to spot anomalous claims before they become a $2M problem, they use EVE.

---

## Team Structure

**Data & Analytics (8 people) — your team:**
- Tim Fateev — Head of Data & Analytics (your manager)
- You — Product Analyst
- Marcus Webb — Senior Data Scientist
- Priya Nair — Data Engineer
- Bob Okafor — BI Engineer
- Jamie Liu — Junior Analyst
- 2 Analytics Engineers (contractors)

**Product (6 people):**
- Alex Rivera — VP of Product
- 2 Product Managers
- 2 Product Designers
- 1 UX Researcher

**Engineering (34 people):**
- David Park — CTO
- 4 Engineering Managers
- 29 Engineers (backend, frontend, data infrastructure, ML)

**Go-to-Market (42 people):**
- Sales: 18 people
- Marketing: 8 people
- Customer Success: 12 people
- Solutions Engineering: 4 people

**Operations (22 people):**
- Rachel Moore — CEO
- Nina Patel — CFO
- Head of People, Legal, Finance, IT, Office

---

## Mission and Values

**Mission:** Make healthcare data accessible to every decision-maker — not just the ones who know SQL.

**Vision:** Become the standard analytics layer for mid-market healthcare organizations in North America.

**Values:**
- **Patients first, always:** Every dashboard we build affects real patient outcomes. We don't forget that.
- **Data over opinions:** We're an analytics company. We eat our own cooking.
- **Clarity over complexity:** If a CMO can't understand it in 30 seconds, it's not ready.
- **Move fast, measure everything:** Ship weekly, instrument daily, review monthly.
- **Radical transparency:** Open metrics, open roadmap, open postmortems.

---

## Current Metrics (Q1 2026)

**Customers:**
- 84 active B2B customers
- 12 new customers last quarter
- Average customer size: 500–5,000 employees
- Mix: 45% hospital networks, 30% insurance providers, 25% digital health / other

**Revenue:**
- $6.2M ARR (Annual Recurring Revenue)
- $517K MRR (Monthly Recurring Revenue)
- Average contract value: $74K/year
- NRR (Net Revenue Retention): 112%

**Growth:**
- 18% quarterly revenue growth
- 14% quarterly customer growth
- Gross churn: 6.2% annually (target: <5%)

**Engagement:**
- DAU/MAU: 34% (target: 50%)
- EVE Explorer adoption: 41% of licensed seats (target: 65%)
- EVE Signals beta: 9 customers (target: 25 by EOY)

### Funding History

**Seed (2019):** $1.5M
- Lead: Lux Capital (health-tech focused fund)
- What it funded: MVP, first 5 pilot customers, founding team
- Milestone: Proved that mid-size hospitals would pay for self-serve analytics

**Series A (2022):** $6.5M
- Lead: Andreessen Horowitz (Bio + Health fund)
- What it funded: Engineering team scale-up, EVE Explorer launch, first enterprise deals
- Milestone: Crossed $2M ARR, 40 customers

**Series B (2024):** $10M
- Lead: General Catalyst
- What it funded: EVE Signals (ML product), sales team expansion, compliance certifications (HIPAA, SOC 2)
- Milestone: Crossed $5M ARR, 70 customers, HIPAA compliance achieved

---

## Market Position

### Target Segments

**Primary: Mid-size hospital networks (500–10,000 employees)**
- 3–15 facilities
- Have data but lack analytics infrastructure
- CMO or VP of Quality as champion
- Pain: drowning in reports but starving for insights

**Secondary: Regional insurance providers**
- $500M–$5B in premiums
- Need claims analytics, population health dashboards
- Actuary or VP of Analytics as champion
- Pain: legacy BI tools that require 6-month projects for every new report

**Emerging: Digital health companies (Series B+)**
- Need product analytics + clinical outcomes tracking
- VP of Data or Head of Product as champion
- Pain: building analytics in-house is expensive and slow

### Market Size

**TAM:** $12B
- Healthcare analytics and BI market (North America)

**SAM:** $2.1B
- Mid-market healthcare organizations (our sweet spot — too small for Epic Cogito, too complex for generic BI)

**SOM:** $180M
- Achievable share within 5 years at current trajectory

---

## Competitive Landscape (Summary)

**Health Catalyst:**
- Strengths: Deep clinical data expertise, enterprise relationships, $300M+ revenue
- Weaknesses: Expensive ($500K+ ACV), 12-month implementation, overkill for mid-market
- Our edge: 10x faster deployment, 5x lower price, self-serve for non-technical users

**Arcadia:**
- Strengths: Strong with payers, population health focus, good data integration
- Weaknesses: Weak self-serve, requires dedicated analysts, limited customization
- Our edge: EVE Explorer lets non-technical staff build their own reports

**Tableau / Power BI for Healthcare:**
- Strengths: Powerful visualization, familiar brand, existing enterprise licenses
- Weaknesses: No healthcare-specific logic, requires heavy customization, no clinical context
- Our edge: Pre-built healthcare KPIs, HIPAA-compliant out of the box, anomaly detection

**Epic Cogito:**
- Strengths: Built into Epic EHR, captive audience, trusted brand
- Weaknesses: Only works with Epic data, limited flexibility, expensive add-on
- Our edge: Works with ANY data source, not locked to one EHR vendor

*(Full competitive analysis in COMPETITIVE.md)*

---

## Product Philosophy

### Core Principles

**1. Every metric tells a patient story**
- We don't show numbers in isolation
- Every dashboard connects operational metrics to patient outcomes
- If a CMO sees readmission rates rising, they should see the contributing factors in the same view

**2. Self-serve or it doesn't count**
- If only the data team can run a report, it's not a product feature — it's a service
- EVE Explorer exists because analysts shouldn't be bottlenecks
- Target: 80% of ad-hoc questions answered without filing a ticket

**3. Anomalies before they become crises**
- EVE Signals detects patterns that humans miss
- A 3% shift in ER visit acuity mix doesn't make headlines — but it predicts a staffing crisis in 6 weeks
- Alert early, explain clearly, recommend action

**4. Healthcare is not generic B2B**
- HIPAA compliance is table stakes, not a feature
- Clinical terminology matters — "length of stay" is not "session duration"
- Our customers work in life-and-death contexts. Our UX respects that.

---

## Company Culture

### How We Work

**Distributed-first, Austin HQ:**
- Main office in Austin, TX (leadership + product team)
- Distributed team across US: NYC, SF, Seattle, Denver, Boston, Chicago
- Async communication by default
- Weekly all-hands (recorded and shared)
- Quarterly offsites (last one: Big Sky, Montana)

**Tools:**
- EVE Platform (we use our own product for internal analytics)
- Slack (communication)
- Notion (documentation)
- Figma (design)
- GitHub (code)
- Linear (project management)
- Looker (internal BI — Bob's domain)
- Snowflake (data warehouse)
- dbt (data transformation — Priya's domain)

### Team Norms

- **"Show the data" rule:** No decision meeting without data. If you have an opinion, bring evidence.
- **Blameless postmortems:** When things break (and they will), we fix forward.
- **Friday demos:** Every team shows what they shipped that week. 15 min max. No slides.
- **"Ask the analyst" Slack channel:** Anyone in the company can tag the data team. You'll be answering these.

---

## Strategic Priorities (2026)

### Focus Areas

**1. Engagement crisis: DAU/MAU from 34% → 50%**
- Customers buy EVE but don't use it daily
- Hypothesis: onboarding is too complex, time-to-first-insight is too long
- Your job: figure out what's actually going on and prove it with data

**2. EVE Explorer adoption: 41% → 65% of licensed seats**
- Self-serve analytics is the future of the product, but most users stick to pre-built Insights dashboards
- Hypothesis: Explorer is powerful but intimidating for non-technical users
- Your job: identify the adoption blockers and recommend fixes

**3. EVE Signals GA launch**
- Currently in beta with 9 customers
- ML-powered anomaly detection and predictive alerts
- Target: 25 customers on Signals by EOY
- Your job: analyze beta usage data, identify success patterns

**4. Reduce churn: 6.2% → <5%**
- Churn is concentrated in smaller accounts (< $50K ACV)
- Hypothesis: these customers never reach "aha moment"
- Your job: build the churn prediction model inputs for Marcus (DS)

### OKRs 2026

**Objective 1: Make EVE indispensable (engagement)**
- KR1: DAU/MAU: 34% → 50%
- KR2: Time-to-first-insight: 14 days → 5 days
- KR3: Support tickets per user/month: 2.3 → 1.5

**Objective 2: Own the mid-market (growth)**
- KR1: ARR: $6.2M → $10M
- KR2: New customers: 84 → 120
- KR3: NRR: 112% → 125%

**Objective 3: Prove the AI story (Signals)**
- KR1: Signals GA launch by Q3
- KR2: 25 customers on Signals by EOY
- KR3: At least 3 case studies with measurable ROI

---

## Your Role (Product Analyst)

### What You Own

**Analytics areas:**
- Product engagement and adoption metrics
- Customer health scoring (inputs for churn prediction)
- Support ticket analysis and operational KPIs
- EVE Explorer usage patterns and self-serve analytics adoption
- Ad-hoc analysis requests from leadership

**Your goals:**
- Understand why engagement is low and what drives it
- Build the analytics foundation for churn prevention
- Create dashboards and reports that leadership actually uses
- Be the person who can answer "why is this metric moving?" in under an hour

### Your Stakeholders

**Reports to:** Tim Fateev (Head of Data & Analytics)

**Works closely with:**
- Marcus Webb (Senior DS) — statistical validation, modeling
- Priya Nair (Data Engineer) — data pipelines, data quality
- Bob Okafor (BI Engineer) — dashboards, Looker, reporting infrastructure
- Jamie Liu (Junior Analyst) — mentoring, task delegation

**Interacts with:**
- Alex Rivera (VP Product) — product metrics, feature impact analysis
- David Park (CTO) — technical feasibility, data architecture
- Rachel Moore (CEO) — board metrics, strategic narratives
- Nina Patel (CFO) — financial metrics, unit economics
- Customer Success team — customer health data, churn signals

---

## Key Terminology

**EVE Platform:** The full product suite (Insights + Explorer + Signals)
**EVE Insights:** Pre-built dashboards for clinical and operational KPIs
**EVE Explorer:** Self-serve analytics tool for non-technical healthcare staff
**EVE Signals:** ML-powered anomaly detection and predictive alerts (currently beta)
**ACV:** Annual Contract Value — how much a customer pays per year
**ARR:** Annual Recurring Revenue — total recurring revenue across all customers
**NRR:** Net Revenue Retention — measures expansion vs churn (>100% = growing within existing customers)
**DAU/MAU:** Daily Active Users / Monthly Active Users — engagement ratio
**HIPAA:** Health Insurance Portability and Accountability Act — healthcare data privacy law
**EHR:** Electronic Health Records — clinical data systems (Epic, Cerner, etc.)
**SLA:** Service Level Agreement — response time commitments to customers

---

## About This Course

Throughout this course, you'll work on real tasks at EVE Health:
- Investigate metric spikes and anomalies in support and product data
- Build dashboards and reports for leadership
- Analyze user behavior to understand engagement and churn
- Present findings to executives who care about the story, not the SQL
- Automate your own workflows so you can focus on the hard problems

All the context is already here. You're joining a real company with real data, real stakeholders, and real deadlines.

**Let's make healthcare data work harder.**

---

*This course was created by Tim Fateev — [LinkedIn](https://www.linkedin.com/in/tim-datapro/)*
*Licensed under CC BY 4.0*
