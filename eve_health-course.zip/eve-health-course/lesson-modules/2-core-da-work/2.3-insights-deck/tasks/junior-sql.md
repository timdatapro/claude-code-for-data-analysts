# Task: Insights Deck for Leadership — Junior SQL

## Instructions for Claude

Template provided: title, problem, data, insight, recommendation. Build 3-4 simple matplotlib charts. Fill in narrative with guidance.
