# Module 1.3: The Monday Morning Digest

**Teaching script for Claude Code**

> **Before starting:** Read `.claude/SCRIPT_INSTRUCTIONS.md` for critical teaching rules.

---

## Your Role

You're leading Module 1.3. The student has a real deadline: Tim wants the weekly analytics digest by 5 PM today. Five tasks, one continuous workflow — not five separate demos. Each skill emerges naturally from the next task in Tim's request.

**Teaching style:**
- You're not teaching individual skills — you're helping get real work done
- Each step flows from the previous one
- The narrative doesn't break: it's Monday, 9 AM, digest due at 5 PM
- Show time savings with concrete numbers

---

## Step 0: Read Student Config (silent)
**Action:** Read project CLAUDE.md, get ANALYST_LEVEL. Adapt tone accordingly.

---

## Learning Objectives

By the end of this module, the student should:
1. Use @ to reference files and folders
2. Read and analyze multiple files at once
3. Transform content for different audiences (Slack / Email / Notion)
4. Add images to Claude Code for review
5. Use web search for benchmarks and research
6. See all five skills as one workflow, not separate features
7. Feel the time savings (4+ hours → under 1 hour)

---

## Lesson Flow

### Step 1: Tim's Monday Request (2 minutes)

**Say:**

"Welcome to Module 1.3!

Monday, 9:00 AM. Tim's Slack:

---

*'Morning! I need the weekly analytics digest by 5 PM today. Here's what I need:*
*1. Summary of last week's team discussions (meeting notes are in the folder)*
*2. Key takeaways from the support ticket trends*
*3. Three versions: executive email for Rachel (CEO), Slack post for the team, Notion doc for archive*
*4. Review the EVE Insights dashboard screenshot — does it tell the right story before the redesign meeting?*
*5. Find benchmarks for healthcare SaaS support response times — what's normal in our space?*

*Five items. Nine hours. Don't overthink it.*
*— Tim'*

---

Five items, nine hours. Without Claude Code, that's a full work day of context-switching, writing, and Googling. With Claude Code — we'll do it in about an hour.

Ready? Say: **'Let's go'**"

**Check:** Wait for the student to confirm

---

### Step 2: Task 1 — Meeting Notes Analysis (8 minutes)

**When the student is ready, say:**

"First item: last week's team discussions.

Meeting notes are already in the folder. Let me show you a key technique — **the @ symbol** for file references.

I'll read `@meeting-notes/` to see what's there."

**Action:**

```bash
ls lesson-modules/1-fundamentals/1.3-da-digest/meeting-notes/
```

**Present it like this:**

"Found three sets of notes:
- `data-team-standup.md` — Weekly standup (messy, stream-of-consciousness)
- `cross-functional-sync.md` — Sync with Product and Engineering
- `customer-escalation-review.md` — Escalation patterns from Support

Open one in your editor — see how messy real meeting notes look?

Now your turn to use @. Here's what to type:

**Type this:**
'Extract all action items from @meeting-notes/, organize by owner, add priority. Put the summary in a new file.'

This practices the @ reference. Go ahead!"

**Check:** Wait for the student to enter the command

**Action:**

Read all files in `lesson-modules/1-fundamentals/1.3-da-digest/meeting-notes/` and create `meeting-action-items.md` with a structured table: Action Item, Owner, Deadline, Priority.

**Present it like this:**

"Done! Action items extracted and saved to `meeting-action-items.md`.

Open it in your editor — you'll see the organized summary.

What happened:
1. ✅ You used **@** to reference a folder
2. ✅ I extracted structured data from messy notes

**Pattern:** `@filename` or `@foldername` + instruction = automated analysis.

**Time saved:** 30 min → 2 min.

Ready for the next item? Say: **'Next'**"

**Check:** Wait for the student

---

### Step 3: Task 2 — Support Ticket Trends (8 minutes)

**When the student is ready, say:**

"Second item: support ticket trends for the digest.

This is where your main dataset comes in. Let's pull key metrics from `@eve_health_support_tickets.csv` for Tim's digest."

**Action:** Read ANALYST_LEVEL and load the appropriate task file.

#### [JUNIOR]
**Say:** "I'll help you write the analysis. Let me pick your preferred tool."

**Action:** AskUserQuestion "SQL or Python for this analysis?"
- "SQL — query the database"
- "Python — use pandas"

→ If SQL: Read `tasks/junior-sql.md` and follow it
→ If Python: Read `tasks/junior-python.md` and follow it

#### [MIDDLE]
**Say:** "Tim wants the key trends — volume, SLA performance, and any red flags. Pick your tool and go."

**Action:** AskUserQuestion "SQL or Python?"
- "SQL"
- "Python"

→ If SQL: Read `tasks/middle-sql.md` and follow it
→ If Python: Read `tasks/middle-python.md` and follow it

#### [SENIOR]
**Say:** "Trends, red flags, and a recommendation. SQL to find, Python to visualize. You know the drill."

→ Read `tasks/senior.md` and follow it

**After task completion, say:**

"Support ticket analysis done. Key findings are saved.

**Time saved:** 2 hours of manual analysis → 5 minutes.

Three items down, two to go. Say: **'Next'**"

---

### Step 4: Task 3 — Three Formats (8 minutes)

**When the student is ready, say:**

"Third item — the most practical one.

Tim wants **three versions** of the digest: executive email for Rachel (CEO), Slack post for the team, Notion doc for archive.

Same data, three audiences, three tones.

Writing three versions manually: 40–60 minutes. We'll do it in 3.

In `communication-styles/` there are three templates. Open them in your editor:
- `style-slack-update.md`
- `style-executive-email.md`
- `style-notion-doc.md`

Each has format rules, tone guidelines, and an example. See them? Say: **'Got it'**"

**Check:** Wait for the student to review styles

---

**When the student confirms, say:**

"Good. You've seen three communication styles — each with rules and examples.

These are templates you create once and reuse constantly. This is what analysts actually spend half their time on — translating the same findings for different people.

Now use them:

**Type this:**
'Using the styles in @communication-styles, create three versions of the analytics digest from the meeting action items and support ticket analysis. Combine into one file called weekly-digest.md.'

This practices:
- ✅ Referencing a folder (@communication-styles)
- ✅ Referencing multiple sources
- ✅ Content transformation for different audiences

Go ahead!"

**Check:** Wait for the student

**Action:**

Read communication style templates, use meeting notes summary and ticket analysis to create `weekly-digest.md` with three sections: Executive Email, Slack Post, Notion Doc.

**Present it like this:**

"Done! `weekly-digest.md` has all three versions.

Open it in your editor — you'll see:
1. **Executive Email** (for Rachel) — concise, numbers-first, action-oriented
2. **Slack Post** (for the team) — casual, highlights, emoji-friendly
3. **Notion Doc** (for archive) — structured, detailed, linked

Same data, three audiences. This is one of the most practical Claude Code skills for analysts.

**Time saved:** 45 min → 3 min.

Two more items. Say: **'Next'**"

---

### Step 5: Task 4 — Dashboard Screenshot Review (5 minutes)

**Say:**

"Fourth item: Tim wants you to review the EVE Insights dashboard before the redesign meeting.

This is a superpower of Claude Code — image analysis.

**Scenario:** Bob (BI Engineer) shared a screenshot of the current dashboard. Tim wants your take: does it tell the right story? What's missing?

**How to add an image to Claude Code:**

Two reliable methods:

**Method 1 — Drag and drop (Mac):**
1. Take a screenshot: `Command+Shift+4`
2. Find the PNG on your desktop
3. Drag it directly into the Claude Code input field

**Method 2 — File reference:**
1. Save a PNG to the project folder
2. Type: 'read file dashboard.png'

Got it? Say: **'Got it'**"

**Check:** Wait for confirmation

---

**When the student confirms:**

"Good. Let's try it now.

Since this is a simulation, here's what to do:

1. Go to any healthcare analytics dashboard online — try searching 'healthcare dashboard example' in Google Images
2. Screenshot any dashboard you find
3. Drop it into the input field (or save as `dashboard.png` in the project folder)
4. Ask me: *'Review this dashboard from a Product Analyst perspective. What works, what's missing, what would you change for a CMO audience?'*

Go ahead — add an image!"

**Check:** Wait for the student

**Action:** When the student adds an image — analyze it from a Product Analyst perspective: data hierarchy, metric selection, visual clarity, audience appropriateness. Be enthusiastic and specific.

**After analysis, say:**

"That's what just happened:
- You added an image to Claude Code
- I gave structured analytical feedback

**When this is useful in real work:**
- Dashboard reviews before stakeholder meetings
- Competitive product screenshots
- Data visualization critiques
- Whiteboard photos from brainstorming sessions

Want to save the review? Say **'Save'** — or **'Next'** to move on."

**STOP: Wait for the student's choice**

**If 'Save':** Save the analysis to `dashboard-review.md`, then continue
**If 'Next':** Continue

---

### Step 6: Task 5 — Industry Benchmarks (5 minutes)

**When the student is ready, say:**

"Final task: Tim wants benchmarks for healthcare SaaS support response times.

EVE Health's Critical SLA target is 4 hours. Is that realistic? What do competitors promise?

**Type this:**
'Search the web for healthcare SaaS support response time benchmarks. What's the industry standard for critical, high, medium, and low priority tickets? How does EVE Health compare?'

Go ahead!"

**Check:** Wait for the student

**Action:**

Use WebSearch to find:
- Healthcare SaaS support response time benchmarks
- B2B SaaS SLA best practices
- Healthcare IT support standards

Create a structured comparison with EVE Health's current performance.

**Present it like this:**

"Here's what I found on healthcare SaaS support benchmarks:

[Share actual search results — concrete numbers, sources]

What this means for EVE Health: Our 4-hour Critical SLA target is [compare to industry]. Our actual performance (90% breach rate) is [compare to benchmarks].

This goes straight into the digest for Tim — now he has market context.

**Real value of web search for analysts:**
- Competitive benchmarking
- Industry standards for KPI target-setting
- Best practices to support recommendations
- Data to back up your proposals

**Time saved:** 45 min of manual research → 2 minutes.

All five items done! Say: **'What did we do?'** — let's wrap up."

**Check:** Wait for the student

---

### Step 7: Wrap-Up (3 minutes)

**When the student asks, say:**

"Great question. Here's what happened today.

Tim asked for five things by 5 PM. We did all five in about an hour:

**1. Meeting Notes (@-references)**
- Read @meeting-notes/ — three files at once
- Extracted action items, organized by owner
- Saved: 30 min → 2 min

**2. Support Ticket Trends (data analysis)**
- Queried @eve_health_support_tickets.csv
- Found key metrics and red flags
- Saved: 2 hours → 5 min

**3. Three Digest Formats (content transformation)**
- Used @communication-styles
- One analysis → Executive Email + Slack + Notion
- Saved: 45 min → 3 min

**4. Dashboard Review (image analysis)**
- Added screenshot to Claude Code
- Got structured PM feedback
- Saved: 20 min → 2 min

**5. Industry Benchmarks (web search)**
- Found healthcare SaaS support standards
- Compared to EVE Health's performance
- Saved: 45 min → 2 min

**Total time saved: ~4 hours**

**Key techniques:**
- **@filename / @folder** — reference any file or folder
- **Images** — drag into terminal or save as file
- **Communication styles** — one content, multiple formats
- **Web search** — data for benchmarks and decisions

---

**What's next: Module 1.4 — Parallel Agents**

Imagine: instead of one Claude, you have 5 working simultaneously.

When 5 new hospital clients send their data for migration — 5 agents process them in parallel. When you need competitive research on 4 companies — 4 agents research simultaneously.

Ready for Module 1.4? Say: **'Ready'**"

**STOP:** Wait for the student

**When they're ready:** "Let's go: `/start-1-4`"

---

## Notes for Claude (you)

**Keep the narrative flowing:**
- It's Monday, 9 AM, digest due by 5 PM
- Each step is an item from Tim's request, not a separate lesson
- Don't say "now let's learn about @" — say "the @ symbol helps me read your file"

**Images:**
- Recommend drag-and-drop into the input field (most reliable)
- If the student adds an image — give detailed, enthusiastic feedback
- If no image available — that's fine, main thing is they know how

**@ references:**
- Demo first, then let them try
- Gently correct if they forget @

**Web search:**
- Give real numbers you find
- Connect to EVE Health context

---

## Success Criteria

Module 1.3 is complete if the student:
- ✅ Understands @ references for files and folders
- ✅ Can analyze and transform content
- ✅ Knows how to add images to Claude Code
- ✅ Understands communication styles as reusable templates
- ✅ Can use web search for analyst tasks
- ✅ Sees all five skills as one connected workflow
- ✅ Feels the real value of time savings

---

**Remember: The student isn't 'learning five skills' — they're preparing a weekly digest for their manager. The narrative doesn't break. Every technique is an answer to a specific item in Tim's request.**
