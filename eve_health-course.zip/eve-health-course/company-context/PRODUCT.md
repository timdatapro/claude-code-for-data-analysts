# EVE Platform — Product Overview

**The complete guide to what EVE Health builds, how it works, and where it's going.**

---

## What Is EVE?

EVE is a B2B analytics platform purpose-built for healthcare organizations. Think of it as **"Tableau meets Health Catalyst, but faster and 5x cheaper"** — powerful enough for data teams, simple enough for a hospital CMO to use without training.

### Core Value Proposition

**For mid-size healthcare organizations drowning in reports but starving for insights,** EVE is an analytics platform **that turns messy clinical and operational data into actionable dashboards in days, not months.** Unlike Health Catalyst (enterprise-only, $500K+ ACV) and Tableau (no healthcare context), EVE **combines pre-built healthcare KPIs with self-serve analytics at a price mid-market can afford.**

---

## The Three Modules

### 1. EVE Insights — Pre-Built Dashboards

**What it does:**
Pre-built, ready-to-use dashboards for standard healthcare KPIs. A hospital plugs in their data, and within 48 hours they're looking at metrics that used to require a 3-month BI project.

**Key dashboards:**
- **Clinical Operations:** Length of stay, readmission rates, ED throughput, bed utilization
- **Financial Performance:** Revenue per case, payer mix, denial rates, A/R aging
- **Quality & Safety:** HCAHPS scores, fall rates, infection rates, mortality index
- **Workforce:** Staffing ratios, overtime trends, turnover by department
- **Population Health:** Risk stratification, chronic disease prevalence, care gap closure rates

**Who uses it:**
- CMOs and VPs of Quality (daily check-ins)
- CFOs and Revenue Cycle leaders (weekly reviews)
- Department heads and nurse managers (operational decisions)

**Current stats:**
- Used by 78 of 84 customers (93% adoption)
- Average 12 dashboards per customer
- Most viewed: Clinical Operations (38%), Financial (28%), Quality (22%)

**Our edge:**
- **Healthcare-native KPIs:** We don't make customers define "readmission rate" — it's built in with CMS methodology
- **48-hour deployment:** Connect data, get dashboards. No 6-month implementation project
- **Automatic benchmarking:** See how your metrics compare to similar-sized facilities (anonymized peer data)

---

### 2. EVE Explorer — Self-Serve Analytics

**What it does:**
A drag-and-drop analytics tool that lets non-technical healthcare staff build their own reports and analyses. The promise: "If you can ask a question in English, you can build a report in Explorer."

**Key capabilities:**
- **Natural language queries:** Type "show me readmission rates by diagnosis for Q4" and get a chart
- **Drag-and-drop report builder:** Dimensions, measures, filters — no SQL required
- **Saved reports and scheduled delivery:** Build once, get it in your inbox every Monday
- **Collaboration:** Share reports, add comments, create team workspaces
- **Data blending:** Combine clinical, financial, and operational data in one view

**Who uses it:**
- Clinical data analysts (power users — daily)
- Quality managers (weekly custom reports)
- Department heads (ad-hoc questions)
- Finance analysts (custom financial models)

**Current stats:**
- 41% of licensed seats actively use Explorer (target: 65%)
- Average 3.2 reports created per active user per month
- Power users (top 10%) create 18+ reports per month
- 67% of Explorer users are non-technical staff

**Our edge:**
- **Natural language:** No other healthcare analytics tool lets you type a question in plain English
- **Healthcare data model:** Explorer understands clinical terminology — "LOS" means length of stay, not a city
- **Governed self-serve:** IT sets data access rules, users explore freely within those boundaries

**The adoption problem:**
Explorer is the future of EVE's product strategy, but adoption is stuck at 41%. Hypotheses:
- Onboarding is too complex for non-technical users
- Natural language queries don't always return what users expect
- Users don't know Explorer exists — they only use Insights
- Power users love it, but casual users bounce after first attempt

*This is one of your primary investigation areas as Product Analyst.*

---

### 3. EVE Signals — ML-Powered Anomaly Detection (Beta)

**What it does:**
Automatically monitors hundreds of metrics and alerts users when something unusual happens — before it becomes a crisis. Machine learning models learn "normal" patterns for each facility and flag deviations.

**Key capabilities:**
- **Anomaly detection:** Flags unusual changes in any metric (e.g., "ER admissions are 23% above expected for this day of week")
- **Root cause suggestions:** When an anomaly fires, Signals suggests contributing factors
- **Predictive alerts:** "Based on current trends, bed utilization will exceed 95% within 72 hours"
- **Custom alert rules:** Users define thresholds and notification preferences
- **Alert fatigue management:** ML learns which alerts users act on, suppresses noise

**Who uses it:**
- Clinical operations leaders (real-time monitoring)
- Quality teams (early warning for safety metrics)
- Insurance analysts (claims anomaly detection)
- Finance teams (revenue cycle anomalies)

**Current stats:**
- Beta with 9 customers
- 47 active alert rules across beta cohort
- Average 3.2 actionable alerts per customer per week
- False positive rate: 18% (target: <10%)
- User satisfaction (beta NPS): +41

**Our edge:**
- **Healthcare-trained models:** Our ML understands seasonality in healthcare (flu season, holiday staffing, fiscal year patterns)
- **Explainable AI:** Every alert comes with "why this fired" in plain English — no black box
- **Time-to-action:** Average 12 minutes from alert to user viewing it (vs. discovering the problem in next month's report)

**The challenge:**
Signals is the highest-margin, highest-differentiation module. But GA launch requires:
- Reducing false positive rate from 18% to <10%
- Proving ROI with at least 3 documented case studies
- Building reliable onboarding (current setup requires data engineering support)

*Marcus (Senior DS) leads the ML side. Your role: analyze beta usage data, identify what makes Signals successful for some customers and not others.*

---

## Data Architecture

### What Data EVE Ingests

**Clinical data:**
- EHR extracts (Epic, Cerner, Meditech, Allscripts)
- ADT feeds (Admit-Discharge-Transfer)
- Lab results and imaging orders
- Clinical documentation metadata

**Financial data:**
- Claims and billing records
- Payer remittance files (835s)
- Charge master data
- Cost accounting feeds

**Operational data:**
- Scheduling and staffing data
- Supply chain and inventory
- Patient satisfaction surveys (HCAHPS, Press Ganey)
- IT support tickets (yes, including ours)

### Data Pipeline

```
Source Systems → EVE Connectors → Staging Layer → Transform (dbt) → 
Analytics Layer (Snowflake) → EVE Platform → Users
```

**Pipeline details:**
- **Connectors:** Pre-built for major EHRs (Epic, Cerner), SFTP for everything else
- **Refresh frequency:** Daily batch (standard), near-real-time for Signals customers (15-min intervals)
- **Data quality:** Automated checks at each stage, quality score per data source
- **HIPAA compliance:** All data encrypted at rest and in transit, role-based access, audit logging

**Priya (Data Engineer) owns the pipeline. When it breaks, you'll know — because Tim will know first.**

---

## Product Metrics

### North Star Metric

**Questions answered per user per week**

**Why this metric?**
- Measures real value delivered (not just logins)
- A "question answered" means a user looked at a dashboard OR ran a report OR received an alert AND took action
- Correlates with retention (r=0.74) and NRR (r=0.68)
- Leading indicator: customers who average 5+ questions/week churn at 2%; those below 2 churn at 14%

**Current value:** 3.1 questions/user/week (across all active users)
**Target (EOY 2026):** 5.0 questions/user/week

### Product Health Metrics

**Engagement (DAU/MAU):**
- Definition: Users who log in and perform at least one meaningful action
- Current: 34%
- Target: 50%
- Why it matters: Low engagement = shelfware = churn risk

**Time-to-first-insight (new customers):**
- Definition: Days from contract signing to first dashboard viewed by a non-admin user
- Current: 14 days (median)
- Target: 5 days
- Why it matters: Every day of delay is a day the champion's credibility erodes internally

**Explorer adoption rate:**
- Definition: % of licensed seats who use Explorer at least once per month
- Current: 41%
- Target: 65%
- Why it matters: Explorer is the stickiest module — Explorer users renew at 96% vs 81% for Insights-only users

**Signals alert accuracy:**
- Definition: % of alerts that result in user action (not dismissed)
- Current: 82% (beta)
- Target: 90%
- Why it matters: Alert fatigue kills the product. If users stop trusting alerts, Signals is dead.

**Support ticket resolution:**
- Definition: Mean time to resolve customer support tickets
- Current: See eve_health_support_tickets.csv (your main dataset)
- Target: <8 hours for High priority, <4 hours for Critical
- Why it matters: Bad support = churn. Critical SLA breach is currently at 90%. This is a crisis.

---

## Pricing & Plans

### Current Tiers

**Essentials ($2,500/month per facility):**
- EVE Insights (up to 10 dashboards)
- Up to 25 users
- Daily data refresh
- Email support (business hours)
- Standard connectors (Epic, Cerner)

**Professional ($5,500/month per facility):**
- Everything in Essentials, plus:
- EVE Explorer (unlimited reports)
- Up to 100 users
- Saved reports and scheduled delivery
- Priority support (8-hour SLA)
- Custom connectors
- API access

**Enterprise ($12,000+/month per facility):**
- Everything in Professional, plus:
- EVE Signals (anomaly detection)
- Unlimited users
- Near-real-time data refresh (15 min)
- Dedicated CSM
- Custom SLAs
- On-site training
- SSO and advanced security

### Competitive Pricing

| Product | Entry | Mid-tier | Enterprise |
|---------|-------|----------|------------|
| **EVE Health** | $2,500/mo | $5,500/mo | $12,000+/mo |
| Health Catalyst | N/A | N/A | $40,000+/mo |
| Arcadia | $5,000/mo | $15,000/mo | Custom |
| Tableau (healthcare setup) | $1,000/mo* | $5,000/mo* | $15,000+/mo* |
| Epic Cogito | Included* | $8,000/mo add-on | Custom |

*Tableau requires significant customization cost; Epic Cogito only works within Epic ecosystem

**Our strategy:** 3–5x cheaper than Health Catalyst with 80% of the functionality. Premium vs Tableau because we include healthcare context out of the box.

---

## Technology Stack

**Frontend:**
- React + TypeScript
- D3.js (custom visualizations)
- Tailwind CSS
- WebSockets (real-time Signals alerts)

**Backend:**
- Python + FastAPI (API and ML services)
- Node.js (real-time event processing)
- PostgreSQL (application database)
- Redis (caching, job queues)

**Data Infrastructure:**
- Snowflake (data warehouse — Priya's kingdom)
- dbt (data transformation — 200+ models)
- Airflow (orchestration)
- Great Expectations (data quality checks)

**ML/AI (Signals):**
- Python + scikit-learn + Prophet (time series)
- Custom anomaly detection models
- LLM integration for natural language queries (Explorer)

**Infrastructure:**
- AWS (us-east-1, us-west-2)
- Kubernetes (EKS)
- Terraform
- DataDog (monitoring)

---

## Your Projects This Quarter

As Product Analyst on the Data & Analytics team, you're working on:

**Project 1: Engagement deep dive**
- Goal: Understand why DAU/MAU is 34% and what drives it
- Deadline: End of Q2 2026
- Status: Analysis in progress — you just started
- Key question: Is it an onboarding problem, a product problem, or a customer fit problem?

**Project 2: Support operations analysis**
- Goal: Figure out why Critical SLA breach is 90% and recommend fixes
- Deadline: Ongoing (Tim reviews weekly)
- Status: Data available in eve_health_support_tickets.csv
- Key question: Are we understaffed, misallocating, or tracking the wrong metrics?

**Project 3: Explorer adoption investigation**
- Goal: Identify why 59% of licensed seats don't use Explorer
- Deadline: Q3 2026 (feeds into product roadmap)
- Status: Needs platform usage data analysis
- Key question: Is it awareness, complexity, or lack of need?

**Project 4: Signals beta analysis**
- Goal: Define success criteria for GA launch
- Deadline: Before Signals GA in Q3
- Status: Marcus leads ML, you lead usage analysis
- Key question: What separates customers who love Signals from those who ignore it?

---

**You have the data. You have the tools. Now go find the stories hiding in the numbers.**
