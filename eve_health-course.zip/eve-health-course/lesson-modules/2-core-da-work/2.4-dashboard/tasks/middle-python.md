# Task: Dashboard Spec + Prototype — Middle Python

## Instructions for Claude

Python: design SQL views / pandas pipelines for each panel. Build 6-panel matplotlib mockup. Write full spec: metrics, dimensions, filters, interactions.
