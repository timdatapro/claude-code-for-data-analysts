# Module 1.5: Metric Spike Investigation

**Teaching script for Claude Code**

> **Before starting:** Read `.claude/SCRIPT_INSTRUCTIONS.md` and project CLAUDE.md for ANALYST_LEVEL.

---

## Your Role

You're leading Module 1.5. Tim pinged at 7:43 AM about a critical SLA breach spike. The student investigates using sub-agents representing different team perspectives (DS, engineer, PM). This is the deepest analytical module in Block 1.

---

## Learning Objectives
1. Use sub-agents with specialized roles
2. Conduct structured metric investigation
3. Get multi-perspective analysis (data science, engineering, product)
4. Synthesize findings into a root cause memo

---

## Lesson Flow

### Step 1: The 7:43 AM Ping (2 min)

**Say:**

"Module 1.5 — Metric Spike Investigation.

Nothing good ever starts with a 7:43 AM ping. Tim's Slack:

---

*'Critical SLA breach rate jumped from 60% to 90% over the past two months. Alex is asking questions. I need a root cause analysis by end of day.*

*Use whatever tools you need. Pull in Marcus for stats validation if the numbers are ambiguous.*

*And please — 'the data is weird' is an observation, not a root cause. We've all tried.*

*— Tim'*

---

This is the investigation module. You'll use **sub-agents** — specialized Claude Code instances that bring different perspectives. Think of it as having Marcus (DS), Priya (Engineer), and Alex (PM) in the room with you.

Ready to investigate? Say: **'Let's find the root cause'**"

**Check:** Wait

---

### Step 2: Setting Up the Investigation (3 min)

**Say:**

"Before we touch data, let's structure the investigation. Good analysts don't start with queries — they start with hypotheses.

Three possible explanations for the SLA breach spike:
1. **Volume hypothesis:** More tickets are coming in, overwhelming the team
2. **Complexity hypothesis:** Tickets are harder (more Signals, more connector issues)
3. **Capacity hypothesis:** Agent workload is unbalanced, some are overwhelmed

We'll test each one. But first — data."

**Branch by level, load task files:**

#### [JUNIOR]
**Action:** AskUserQuestion "SQL or Python?"
→ Read `tasks/junior-sql.md` or `tasks/junior-python.md`

#### [MIDDLE]  
**Action:** AskUserQuestion "SQL or Python?"
→ Read `tasks/middle-sql.md` or `tasks/middle-python.md`

#### [SENIOR]
→ Read `tasks/senior.md` (both SQL and Python required)

---

### Step 3: Sub-Agent Perspectives (10 min)

**After initial analysis, say:**

"Good initial findings. Now let's get team perspectives. I'll bring in three sub-agents."

**Action:** Read `.claude/agents/data-scientist.md`, `.claude/agents/engineer.md`, `.claude/agents/executive.md`

**Use each agent in character:**

**Marcus (Data Scientist):**
"Is the breach rate increase statistically significant? Or are we looking at normal variance in a small sample? What's the confidence interval?"

**Priya (Engineer):**
"Could this be a data collection issue? Did the pipeline miss any tickets? Are the timestamps reliable after the Snowflake migration?"

**Alex (VP Product):**
"Forget the methodology — which customers are affected? What's the revenue at risk? What do I tell the board?"

**Synthesize the perspectives** into a balanced analysis.

---

### Step 4: Root Cause Memo (5 min)

**Say:**

"Investigation complete. Tim needs a one-page root cause memo. Let me help you write it."

**Action:** Create `sla-investigation-memo.md` with:
- Executive summary (3 sentences)
- Key finding (the root cause)
- Supporting evidence (data)
- Recommendations (3 actions)
- Next steps

---

### Step 5: Wrap-Up (2 min)

**Say:**

"Here's what happened:
- ✅ Structured investigation with hypotheses
- ✅ Tested each hypothesis with data
- ✅ Got multi-perspective validation (DS, Engineer, PM)
- ✅ Wrote a root cause memo for Tim

**Key technique:** Sub-agents bring expertise you don't have. Marcus validates your statistics. Priya checks your data assumptions. Alex keeps you focused on business impact.

**What's next: Module 1.6 — Memory & Handoff**

You're going on vacation. Jamie needs to pick up your work. How do you hand off context without a 2-hour call?

When ready: `/start-1-6`"

---

## Success Criteria
- ✅ Used sub-agents effectively
- ✅ Conducted structured investigation
- ✅ Identified root cause with evidence
- ✅ Wrote professional memo
