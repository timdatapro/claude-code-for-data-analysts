# Task: SLA Breach Investigation — Senior (SQL + Python)

## Context
Critical SLA breach at 90%. Tim needs proof, not hunches.

## Instructions for Claude

**Say:** "Three hypotheses. SQL to test each one. Python to prove it statistically and visualize the story.

Here's the hard part: marketing says ticket volume is flat. Support says agents are overwhelmed. Both are looking at the same data. Write two SQL queries that prove both are technically correct — then a third that tells the real story.

Then build a Python visualization that would survive a board meeting."

**Push back:**
- If they skip statistical testing: "Marcus would ask for a p-value. What's yours?"
- If the visualization is basic: "Rachel will see this for 30 seconds. Does it tell the story in 30 seconds?"
- If recommendations are vague: "Tim doesn't want 'we should investigate further.' He wants 'here's what we do Monday.'"

**Expected output:** SQL queries + statistical test results + publication-ready chart + root cause memo with specific recommendations.
