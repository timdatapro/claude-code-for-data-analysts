# Data Team Standup — Week of Jan 13, 2026

**Attendees:** Tim, Marcus, Priya, Bob, Jamie, You (absent — first week)

---

rough notes — Jamie's handwriting (she volunteered to take notes)

Tim opened with the SLA numbers. said "90% critical breach is not acceptable, we need to understand why before alex asks again". Marcus pushed back saying sample size on critical is small (434 tickets total, only ~400 with closed status) and we shouldn't panic without statistical context. Tim said "tell that to the customer whose dashboard was down for 12 hours."

Priya reported the snowflake migration is 80% done. staging tables are all moved, production models still running on the old warehouse. dbt models need updating — she's doing it this week. estimated 3 more days. Tim asked about the data freshness issue from last week — Priya said it was a timezone bug in the airflow DAG, fixed now but we lost ~6 hours of data on Jan 8th.

Bob demo'd the new Looker dashboard for customer health scoring. looks good but Marcus said the churn risk model behind it hasn't been validated yet — "we're showing customers a number we can't defend." Tim agreed, asked Marcus to validate by end of next week. Bob seemed annoyed but didn't argue.

Jamie asked about the explorer adoption analysis — she started pulling the numbers but found inconsistencies in how "active user" is defined across different tables. Tim said "good catch, document it and flag for Priya." ACTION: Jamie to document active user definition discrepancies, share with Priya by Wednesday.

Tim mentioned Rachel (CEO) wants a board-ready engagement story by end of Q1. He's assigning this to the new analyst (you). "Once they're onboarded, the DAU/MAU deep dive is their first big project."

Quick round:
- Marcus: finishing the prophet model for ticket volume forecasting. needs 2 more weeks of data. ETA: end of January
- Priya: snowflake migration + fixing the broken connector for Mercy Hospital (their HL7 feed changed format without telling us)
- Bob: Looker dashboard for Nina (CFO) — financial metrics view. Due friday
- Jamie: weekly SLA report (manual right now, wants to automate). also onboarding you

Tim closed with: "we're a small team doing big things. let's not burn out. take friday afternoon off if you need it."

---

action items from this meeting:
- Marcus: validate churn risk model (ETA: Jan 24)
- Priya: complete snowflake migration (ETA: Jan 16), fix Mercy Hospital connector
- Bob: CFO financial dashboard (ETA: Jan 17)
- Jamie: document active user definition issues (ETA: Jan 15)
- Tim: assign DAU/MAU analysis to new analyst (you)
- Tim: prepare response for Alex on SLA breach root cause
