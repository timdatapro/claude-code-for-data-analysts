# Priya's Debugging Thread — #data-eng-alerts

**Jan 11, 9:15 AM — Priya:**
Dashboard data is stale. Last successful refresh was Jan 10 11:47 PM. Investigating.

**Jan 11, 10:42 AM — Priya:**
Found it. Airflow DAG timed out at 2:00 AM. The `stg_support_tickets` model failed. Root cause: Snowflake connection pool hit max during the migration test run. The migration was using all available connections, so the nightly refresh couldn't get a slot.

**Jan 11, 11:15 AM — Tim:**
How long to fix?

**Jan 11, 11:18 AM — Priya:**
The fix is simple — increase connection pool limit. But I need to backfill 6 days of data. That takes 4-6 hours after the fix is deployed. Earliest full restoration: tomorrow morning.

**Jan 12, 8:30 AM — Priya:**
Fix deployed. Connection pool increased from 10 to 25. Backfill running now. ETA for full data: Jan 12 2:00 PM.

**Jan 12, 3:15 PM — Priya:**
Backfill hit a snag — 3 tables had schema changes from the migration. Fixing manually. New ETA: Jan 13 morning.

**Jan 13, 9:00 AM — Priya:**
Staging tables are current. Production models still building. Dashboard will show current data by tonight.

**Jan 16, 8:00 AM — Priya:**
Pipeline is running normally again. BUT: the dashboard cache hasn't been invalidated yet. Dashboard still shows Jan 10 data even though the underlying tables are current. Working on cache invalidation now. Should be fixed within 2 hours.

**Jan 16, 9:30 AM — Tim:**
Board meeting is in 36 hours. Can't wait for the cache fix. [Your name] — pull the numbers directly from the CSV and give Rachel what she needs manually.
