# Task: Insights Deck for Leadership — Senior (SQL + Python)

## Instructions for Claude

Full 7-slide deck, no template. Devils advocate exercise — build counterargument to own recommendation. Methodology appendix for David. Both SQL + Python for charts and analysis.
