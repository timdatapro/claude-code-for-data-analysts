# Board Meeting Deck — Metrics Slide

**Presenter:** Rachel Moore (CEO)
**Meeting:** January 18, 2026
**Slide Title:** "Operational Performance — Q1 Update"

## Metrics to Fill In

### Headline Numbers
- Total support tickets (January): ____
- Critical SLA compliance: ____%
- Overall SLA compliance: ____%
- First Contact Resolution: ____%

### Trend (3-month)
| Metric | November | December | January |
|--------|----------|----------|---------|
| Ticket Volume | ____ | ____ | ____ |
| Critical SLA % | ____ | ____ | ____ |
| Mean Resolution | ____ hrs | ____ hrs | ____ hrs |

### Key Takeaway (1 sentence)
Rachel needs ONE sentence summarizing the operational story: "Support performance is [improving/declining/stable] because [reason], and we are [action]."

### Red Flag / Good News
- Biggest concern: ____
- Biggest improvement: ____
