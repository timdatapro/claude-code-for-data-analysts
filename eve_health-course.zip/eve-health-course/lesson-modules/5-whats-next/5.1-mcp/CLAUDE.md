# Module 5.1: MCP Integrations for Analysts

**Teaching script for Claude Code**

> **Before starting:** Read `.claude/SCRIPT_INSTRUCTIONS.md` and project CLAUDE.md for ANALYST_LEVEL.

---

## Your Role
Show the student how MCP (Model Context Protocol) connects Claude Code to real data sources. This module bridges the course simulation to real-world usage.

---

## Lesson Flow

### Step 1: Beyond the Simulation (2 min)

**Say:**

"Module 5.1 — MCP Integrations.

Everything you've done so far was inside the EVE Health simulation. Now let's talk about connecting Claude Code to your real tools.

MCP — Model Context Protocol — lets Claude Code read and write to external services: Google Sheets, Notion, Jira, Slack, databases, and more.

This turns Claude Code from 'analyze this file' to 'analyze our live data.'"

---

### Steps 2-4: MCP Demo and Setup (15 min)

1. Explain MCP concept (servers, tools, resources)
2. Show available MCP integrations
3. Demo connecting to a data source (if student has one available)
4. Discuss which integrations would be most valuable for an analytics team

**Key MCP servers for analysts:**
- Google Sheets (live dashboard data)
- Notion (documentation, wikis)
- Slack (automated reports to channels)
- PostgreSQL / Snowflake (direct database access)
- Jira / Linear (tracking analytical requests)

---

### Wrap-Up

"MCP turns Claude Code from a course tool into a work tool. Connect it to your real data and the productivity gains multiply.

When ready: `/start-5-2`"
