# Module 3.1: Advanced Visualization Techniques

**Teaching script for Claude Code**

> **Before starting:** Read `.claude/SCRIPT_INSTRUCTIONS.md` and project CLAUDE.md for ANALYST_LEVEL.

---

## Your Role
Alex wants EVE Health's charts to look professional. This module teaches advanced matplotlib/seaborn techniques — or AI image generation with Gemini API. Student chooses track at the start.

---

## Lesson Flow

### Step 1: Track Selection (2 min)

**Say:**

"Module 3.1 — Visual Content.

Tim:

---

*'Alex wants us to level up our visuals. Two options for you:*

*Track A: Advanced Data Visualization — matplotlib, seaborn, publication-ready charts. This is core analyst skill.*

*Track B: AI Image Generation — use Gemini API to create visuals for marketing, decks, and product materials. Cool but optional.*

*Pick one. If you're Senior — you do both.*

*— Tim'*

---"

**Action:** AskUserQuestion "Which track?"
- "Track A — Data Visualization (matplotlib/seaborn)"
- "Track B — AI Image Generation (Gemini API)"

*(Senior gets both automatically)*

---

### Track A: Data Visualization

**Sub-modules taught in sequence:**

**3.1.1 — Chart Selection Framework**
When to use bar vs line vs scatter vs heatmap. Decision tree based on data relationship (comparison, distribution, composition, relationship). Practice with EVE Health data.

**3.1.2 — Publication-Ready Charts**
matplotlib styling: custom colors, typography, annotations, removing chartjunk. "Before and after" transformations. Build a chart that would survive Nina's scrutiny.

**3.1.3 — Statistical Visualizations**
seaborn: heatmaps for correlation, boxplots for distributions, violin plots, regression plots. When statistical viz adds insight vs when it's showing off.

**3.1.4 — Dashboard Layouts**
Multi-panel matplotlib figures. Consistent styling. Build a reusable "EVE Health chart style" configuration.

---

### Track B: AI Image Generation

**Sub-modules taught in sequence:**

**3.1.1 — Setup Gemini API**
Get API key (free tier), configure environment, generate first image. Healthcare context: hero image for EVE Health landing page.

**3.1.2 — Prompt Engineering for Images**
Effective prompts for healthcare visuals: dashboard screenshots, professional photos, clinical settings.

**3.1.3 — Style Control**
Style references, consistency. Build a visual style guide for EVE Health marketing.

**3.1.4 — Style Library**
Reusable style database. Generate consistent visuals for a sales deck.

---

### Wrap-Up

"Visual skills unlocked. Whether charts or images — you can now create professional visuals that make data (or marketing) compelling.

When ready: `/start-3-2` *(Note: not a numbered slash command — continue in the visual content block)*"
