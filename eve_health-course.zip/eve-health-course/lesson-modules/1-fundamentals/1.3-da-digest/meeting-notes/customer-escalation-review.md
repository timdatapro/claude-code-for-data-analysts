# Customer Escalation Review — Support Team
## January 13, 2026

**Attendees:** Tim, Emily Chen (Support Lead), Ana Gutierrez (Support), CS team lead

---

Emily opened with this week's escalation summary:

### Critical Escalations (3 this week)

**1. Lakewood Regional (Karen Walsh's org)**
- EVE Insights dashboard went blank for 4 hours on Wednesday
- Root cause: Priya's team found a stale cache issue after the Snowflake migration test
- Karen's quality coordinator was mid-presentation to the board when it happened
- Karen called Tim directly. Tim described it as "not a great call"
- Resolution: cache invalidation fix deployed, monitoring added
- Follow-up: Tim sending apology + postmortem to Karen personally

**2. Heartland Blue (Robert Finch's org)**
- Signals alert fired incorrectly — flagged a legitimate cardiology practice as anomalous
- Robert's team investigated for 2 days before realizing it was a false positive
- Robert's feedback: "I can't have my team chasing ghosts. Fix the precision or I'll turn it off."
- Marcus is reviewing the anomaly model — thinks the training data for specialty practices is too thin
- This is the 3rd false positive Robert reported in 6 weeks

**3. Memorial Health (new customer, onboarding)**
- Data connector failed during initial setup — HL7 feed incompatible
- Customer waited 5 days for resolution (SLA: 8 hours for High priority)
- Emily: "We're promising 48-hour deployment but our connector library doesn't cover their EHR version"
- CS team considering moving Memorial to manual data upload temporarily

### Patterns Emily noticed

"Three things keep coming up in escalations:
1. **Connector issues during onboarding** — we promise fast deployment but our connector coverage is spotty for smaller EHR vendors
2. **Signals false positives** — beta customers are losing patience
3. **Dashboard performance** — large accounts (2M+ rows) experience slow load times on Explorer. Miguel at UMC complained twice this month"

Tim asked for data: "How many of our total tickets are connector-related vs Signals vs performance?" Emily said she doesn't have easy access to that breakdown — it requires manual review of ticket categories.

Tim: "This is exactly what our new analyst will work on. We need to go from 'I noticed a pattern' to 'here's the data showing the pattern.'"

### Agent Workload Discussion

Emily raised that Marcus Rivera and Emily Chen (herself) are handling 25% more tickets than Tyler and Ana. "The routing isn't balanced. Signals tickets require more expertise and take longer, but they count the same in the queue."

Tim agreed this needs analysis: "Are some agents overloaded because of ticket complexity, or because of bad routing?"

ACTION: New analyst to analyze agent workload distribution (volume vs complexity vs resolution time)
ACTION: Emily to propose ticket routing improvements based on category expertise
ACTION: Tim to schedule Lakewood postmortem review
ACTION: Marcus (DS) to review Signals false positive rate for specialty practices
