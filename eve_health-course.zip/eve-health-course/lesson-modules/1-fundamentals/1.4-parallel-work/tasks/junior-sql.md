# Task: Batch Data Quality — Junior SQL

## Instructions for Claude

**Provide a ready-made SQL script.** Walk the student through running it on the first file, then let them repeat for the rest.

**Say:** "Here's a SQL approach to check data quality. I'll load each CSV into a temp table and run checks for: null values, duplicate records, and value ranges. Let's start with the first file."

**Action:** For each CSV file:
1. Import into sqlite3
2. Run: SELECT COUNT(*) total, SUM(CASE WHEN department='' THEN 1 ELSE 0 END) as missing_dept, SUM(CASE WHEN value='' THEN 1 ELSE 0 END) as missing_value FROM [table]
3. Check for duplicates: SELECT record_id, COUNT(*) FROM [table] GROUP BY record_id HAVING COUNT(*) > 1
4. Show results, explain what each check found

**After all 5 files:** Create comparison summary.
