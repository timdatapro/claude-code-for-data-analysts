# Task: Dashboard Spec + Prototype — Middle SQL

## Instructions for Claude

SQL: design SQL views / pandas pipelines for each panel. Build 6-panel matplotlib mockup. Write full spec: metrics, dimensions, filters, interactions.
