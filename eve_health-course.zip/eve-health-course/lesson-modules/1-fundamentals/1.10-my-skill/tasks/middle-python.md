# Task: Custom Analysis Skill — Middle Python

## Instructions for Claude

"Weekly Metrics Digest Generator" — Python skill that queries the data, calculates KPIs vs targets, generates a formatted summary ready for Slack. Student designs and builds.
